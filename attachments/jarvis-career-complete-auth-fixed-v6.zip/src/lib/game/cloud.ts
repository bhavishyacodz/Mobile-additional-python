import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import type { SaveState } from "@/lib/game/types";

function asPayload(raw: unknown): SaveState | null {
  if (!raw) return null;
  if (typeof raw === "string") {
    try {
      return JSON.parse(raw) as SaveState;
    } catch {
      return null;
    }
  }
  if (typeof raw === "object") return raw as SaveState;
  return null;
}

export const loadCareerSave = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{ payload: unknown }>`
      select payload from career_saves where user_id = ${context.userId} limit 1
    `;
    return asPayload(rows[0]?.payload);
  });

export const saveCareerSave = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: SaveState) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const payload = JSON.stringify(data);
    await sql.query(
      `insert into career_saves (user_id, payload, updated_at)
       values ($1, $2::jsonb, now())
       on conflict (user_id) do update set payload = excluded.payload, updated_at = now()`,
      [context.userId, payload],
    );
    return { ok: true as const };
  });
