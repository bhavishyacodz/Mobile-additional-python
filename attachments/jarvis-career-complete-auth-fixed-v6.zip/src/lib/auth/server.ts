/**
 * Self-hosted Better Auth for THIS app (server-only).
 *
 * Native Google OAuth via Better Auth `socialProviders.google`.
 * Does NOT use the Grok OAuth broker (`genericOAuth` / GROK_AUTH_*).
 *
 * Required production env:
 *   GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, BETTER_AUTH_SECRET,
 *   BETTER_AUTH_URL, DATABASE_URL, VITE_AUTH_ENABLED=true
 *
 * Google callback:
 *   {BETTER_AUTH_URL}/api/auth/callback/google
 */
import { betterAuth } from "better-auth";
import { bearer } from "better-auth/plugins";
import { tanstackStartCookies } from "better-auth/tanstack-start";
import { getCookie } from "@tanstack/react-start/server";
import { randomBytes } from "node:crypto";
import { Pool } from "pg";
import { ensureDbReady, getPglite } from "../db";
import { emailAndPasswordEnabled } from "./email-password";
import { GATE_PROVIDER_ID, gateIdentitySessions } from "./gate-session.server";
import { pgliteDialect } from "./pglite-dialect";
import { PREVIEW_ALLOWED_HOSTS } from "./preview";

void ensureDbReady();

const globalAuthRef = globalThis as typeof globalThis & {
  __grokAuthPreviewSecret__?: string;
};
function previewAuthSecret(): string {
  globalAuthRef.__grokAuthPreviewSecret__ ??= randomBytes(32).toString("hex");
  return globalAuthRef.__grokAuthPreviewSecret__;
}

/** Read an env var, treating empty/whitespace as unset. */
const env = (key: string): string | undefined => {
  const value = process.env[key]?.trim();
  return value ? value : undefined;
};

function withHttps(hostOrUrl: string): string {
  if (hostOrUrl.startsWith("http://") || hostOrUrl.startsWith("https://")) return hostOrUrl.replace(/\/$/, "");
  return `https://${hostOrUrl.replace(/\/$/, "")}`;
}

const authDisabled = env("VITE_AUTH_ENABLED") === "false";

const googleClientId = env("GOOGLE_CLIENT_ID");
const googleClientSecret = env("GOOGLE_CLIENT_SECRET");

export const googleOAuthConfigured = Boolean(googleClientId && googleClientSecret);
export const authSecretConfigured = Boolean(env("BETTER_AUTH_SECRET"));

/** True when federated Google sign-in is active (real auth is enforced). */
export const authConfigured = !authDisabled && googleOAuthConfigured;

const LOCAL_DEV_ORIGINS: string[] = [
  "http://localhost:8080",
  "http://127.0.0.1:8080",
  "http://[::1]:8080",
];

const KNOWN_PRODUCTION_ORIGIN =
  "https://mobile-additional-python-1hurn9mvd-bhavishyacodzs-projects.vercel.app";

const vercelOrigin = env("VERCEL_PROJECT_PRODUCTION_URL")
  ? withHttps(env("VERCEL_PROJECT_PRODUCTION_URL")!)
  : env("VERCEL_URL")
    ? withHttps(env("VERCEL_URL")!)
    : undefined;

const explicitBaseURL = env("BETTER_AUTH_URL") ? withHttps(env("BETTER_AUTH_URL")!) : vercelOrigin;

const previewAllowedHosts: string[] = [...PREVIEW_ALLOWED_HOSTS];

const baseURL = explicitBaseURL ?? {
  allowedHosts: [...previewAllowedHosts, "localhost", "127.0.0.1", "[::1]", "*.vercel.app"],
  protocol: "auto" as const,
  fallback: "http://localhost:8080",
};

const STATIC_TRUSTED_ORIGINS: string[] = [
  ...LOCAL_DEV_ORIGINS,
  KNOWN_PRODUCTION_ORIGIN,
  ...(explicitBaseURL ? [explicitBaseURL] : []),
  ...(vercelOrigin ? [vercelOrigin] : []),
  "https://*.vercel.app",
  "https://*.grok-sandbox.com",
  "http://*.grok-sandbox.com",
  ...previewAllowedHosts.flatMap((host) => [`https://${host}`, `http://${host}`]),
];

async function trustedOrigins(request?: Request): Promise<string[]> {
  const origins = new Set(STATIC_TRUSTED_ORIGINS);
  if (request) {
    try {
      origins.add(new URL(request.url).origin);
    } catch {
      /* ignore malformed */
    }
    const forwarded = (request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? "")
      .split(",")[0]
      ?.trim();
    if (forwarded) {
      const proto =
        request.headers.get("x-forwarded-proto") ??
        (forwarded.startsWith("localhost") || forwarded.startsWith("127.0.0.1") ? "http" : "https");
      origins.add(`${proto}://${forwarded}`);
    }
  }
  return [...origins].filter(Boolean);
}

const databaseUrl = env("DATABASE_URL");

const database = databaseUrl
  ? new Pool({ connectionString: databaseUrl })
  : { dialect: pgliteDialect(() => getPglite()), type: "postgres" as const };

/** Session token cookie name — also read by the live-preview popup completion page. */
export const SESSION_TOKEN_COOKIE = "__Host-jarvis-auth.session_token";

export const auth = betterAuth({
  baseURL,
  secret: env("BETTER_AUTH_SECRET") ?? previewAuthSecret(),
  database,

  ...(authConfigured
    ? {
        socialProviders: {
          google: {
            clientId: googleClientId as string,
            clientSecret: googleClientSecret as string,
            prompt: "select_account",
            accessType: "online",
            redirectURI: `${explicitBaseURL ?? KNOWN_PRODUCTION_ORIGIN}/api/auth/callback/google`,
          },
        },
      }
    : {}),

  trustedOrigins,

  account: {
    encryptOAuthTokens: true,
    accountLinking: {
      enabled: true,
      trustedProviders: ["google", GATE_PROVIDER_ID],
      requireLocalEmailVerified: false,
    },
  },

  session: {
    expiresIn: 60 * 60 * 24 * 30,
    updateAge: 60 * 60 * 24,
    // Keep the authoritative session in Neon/Postgres. The short-lived cookie cache
    // can make a newly-created OAuth session look anonymous after the callback.
    cookieCache: { enabled: false },
  },

  ...(emailAndPasswordEnabled ? { emailAndPassword: { enabled: true } } : {}),

  advanced: {
    useSecureCookies: true,
    defaultCookieAttributes: { secure: true, sameSite: "lax", path: "/", httpOnly: true },
    cookies: {
      session_token: { name: SESSION_TOKEN_COOKIE },
      session_data: { name: "__Host-jarvis-auth.session_data" },
      account_data: { name: "__Host-jarvis-auth.account_data" },
      dont_remember: { name: "__Host-jarvis-auth.dont_remember" },
    },
  },

  plugins: [gateIdentitySessions(), bearer(), tanstackStartCookies()],
});

export function readSessionToken(): string | null {
  return getCookie(SESSION_TOKEN_COOKIE) ?? null;
}

export { GROK_PROVIDERS } from "./providers";
