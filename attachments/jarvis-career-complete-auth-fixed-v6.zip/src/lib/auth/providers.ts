/**
 * Sign-in providers offered by this app.
 *
 * The deployed app uses Better Auth's built-in Google provider directly.
 * Keeping this small shared list lets the login UI and gate UI use the same
 * provider id without pulling server-only code into the browser.
 */
export type GrokProvider = {
  providerId: string;
  idp: string;
  label: string;
};

export const GROK_PROVIDERS: readonly GrokProvider[] = [
  { providerId: "google", idp: "google", label: "Google" },
];
