import { createAuthClient } from "better-auth/react";
import { GROK_PROVIDERS } from "./providers";

/**
 * Better Auth client for this React SPA (browser-side).
 *
 * Talks to this app's OWN Better Auth at same-origin `/api/auth/*`.
 * Native Google sign-in uses `authClient.signIn.social({ provider: "google" })`.
 * Deployed apps use the HttpOnly session cookie. Live preview may also attach
 * a bearer token when cookies are partitioned.
 */
export const authClient = createAuthClient({
  fetchOptions: {
    credentials: "include",
    onRequest(ctx) {
      const token = getBearerToken();
      if (token) ctx.headers.set("Authorization", `Bearer ${token}`);
      return ctx;
    },
  },
});

export const authEnabled = import.meta.env.VITE_AUTH_ENABLED !== "false";

/** The upstream providers to render sign-in buttons for. */
export { GROK_PROVIDERS };

const BEARER_KEY = "grok-auth.bearer-token";

export function getBearerToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage.getItem(BEARER_KEY);
  } catch {
    return null;
  }
}

function setBearerToken(token: string | null): void {
  if (typeof window === "undefined") return;
  try {
    if (token) window.sessionStorage.setItem(BEARER_KEY, token);
    else window.sessionStorage.removeItem(BEARER_KEY);
  } catch {
    /* storage unavailable — ignore */
  }
}

function inLivePreview(): boolean {
  return (
    typeof window !== "undefined" &&
    window.location.hostname.endsWith(".grok-sandbox.com")
  );
}

/**
 * Start native Better Auth Google OAuth.
 * Full-page redirect to Google, then back to `/api/auth/callback/google`.
 */
export async function signIn(
  providerId: string,
  opts: { callbackURL?: string; errorCallbackURL?: string } = {},
): Promise<void> {
  const callbackURL = opts.callbackURL ?? "/";
  const errorCallbackURL = opts.errorCallbackURL ?? "/login";

  const { error } = await authClient.signIn.social({
    provider: "google",
    callbackURL,
    errorCallbackURL,
    newUserCallbackURL: callbackURL,
    fetchOptions: { credentials: "include" },
  });

  if (error) {
    throw new Error(error.message ?? "Google sign-in failed");
  }
}

export async function signOut(redirectTo = "/"): Promise<void> {
  const { error } = await authClient.signOut({
    fetchOptions: {
      onSuccess: () => {
        window.location.href = redirectTo;
      },
    },
  });
  if (error) {
    throw new Error(error.message ?? "Sign-out failed");
  }
}
