//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-OAmqX-BG.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-CprI2F4C.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-BqmNhekO.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CprI2F4C.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DCoki7Ta.js", "/assets/use-current-user-D8fstKHt.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-B-BNQo5a.js", "/assets/use-current-user-D8fstKHt.js"]
	}
} });
//#endregion
export { tsrStartManifest };
