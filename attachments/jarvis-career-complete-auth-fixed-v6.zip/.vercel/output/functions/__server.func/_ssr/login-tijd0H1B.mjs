import { n as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-tijd0H1B.js
var getLoginStatus_createServerFn_handler = createServerRpc({
	id: "7cf6c1fd2b5f5da7e4e7dcd87105633d144a9ad869aa9b6673c1222185c10be2",
	name: "getLoginStatus",
	filename: "src/routes/login.tsx"
}, (opts) => getLoginStatus.__executeServer(opts));
var getLoginStatus = createServerFn({ method: "GET" }).handler(getLoginStatus_createServerFn_handler, async () => {
	const { authConfigured, authSecretConfigured, googleOAuthConfigured } = await import("./server-BgAnkcyZ.mjs").then((n) => n.r);
	return {
		googleConfigured: googleOAuthConfigured,
		authConfigured,
		persistSessions: authSecretConfigured || !process.env.DATABASE_URL?.trim()
	};
});
//#endregion
export { getLoginStatus_createServerFn_handler };
