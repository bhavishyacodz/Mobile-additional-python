import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as createServerFn } from "./ssr.mjs";
import { i as signOut, r as signIn } from "./client-CIsDoSCY.mjs";
import { t as authMiddleware } from "./middleware--Bh-fiPH.mjs";
import { a as useCurrentUserState, i as useCurrentUser, n as GROK_PROVIDERS, r as cn, t as Button } from "./use-current-user-BC3XEmPf.mjs";
import { t as createSsrRpc } from "./createSsrRpc-D75-wYbG.mjs";
import { a as hasGateSessionMarker } from "./server-BgAnkcyZ.mjs";
import { C as Check, D as ArrowLeft, E as Award, S as ChevronDown, T as BookOpen, _ as Gift, a as Trophy, b as CircleAlert, c as Star, d as RotateCcw, f as Play, g as House, h as Lightbulb, i as User, l as Smartphone, m as Lock, n as VolumeX, p as MessageSquare, r as Volume2, s as Timer, t as Wallet, u as Settings, v as FolderKanban, w as Briefcase, x as ChevronRight, y as Copy } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DLntKN5-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEYWORDS = /* @__PURE__ */ new Set([
	"if",
	"elif",
	"else",
	"for",
	"while",
	"def",
	"return",
	"in",
	"not",
	"and",
	"or",
	"True",
	"False",
	"None",
	"pass",
	"break",
	"continue",
	"is"
]);
function err(kind, message, line, hint, fix) {
	return {
		kind,
		message,
		line,
		hint,
		fix
	};
}
function tokenize(source) {
	const src = source.replace(/\r\n/g, "\n").replace(/\t/g, "    ");
	const tokens = [];
	const indents = [0];
	const lines = src.split("\n");
	for (let li = 0; li < lines.length; li++) {
		const lineNo = li + 1;
		const raw = lines[li];
		const trimmed = raw.trim();
		if (trimmed === "" || trimmed.startsWith("#")) continue;
		const indent = raw.match(/^ */)?.[0].length ?? 0;
		if (indent > indents[indents.length - 1]) {
			indents.push(indent);
			tokens.push({
				type: "INDENT",
				value: "",
				line: lineNo,
				col: 1
			});
		} else {
			while (indent < indents[indents.length - 1]) {
				indents.pop();
				tokens.push({
					type: "DEDENT",
					value: "",
					line: lineNo,
					col: 1
				});
			}
			if (indent !== indents[indents.length - 1]) throw err("IndentationError", "Indentation does not match any outer level.", lineNo, "Python uses spaces at the start of a line to group code. Keep the same number of spaces for lines in the same block.", "Use 4 spaces for each indent level. Do not mix random spacing.");
		}
		let i = indent;
		const line = raw;
		while (i < line.length) {
			const ch = line[i];
			if (ch === " ") {
				i++;
				continue;
			}
			if (ch === "#") break;
			if (ch === "\"" || ch === "'") {
				const quote = ch;
				let j = i + 1;
				let val = "";
				while (j < line.length) {
					if (line[j] === "\\") {
						const n = line[j + 1];
						if (n === "n") val += "\n";
						else if (n === "t") val += "	";
						else if (n === quote || n === "\\") val += n;
						else val += n ?? "";
						j += 2;
						continue;
					}
					if (line[j] === quote) break;
					val += line[j];
					j++;
				}
				if (j >= line.length || line[j] !== quote) throw err("SyntaxError", "String is missing a closing quote.", lineNo, "Every string must start and end with the same quote mark.", `Close the string: ${quote}your text${quote}`);
				tokens.push({
					type: "STRING",
					value: val,
					line: lineNo,
					col: i + 1
				});
				i = j + 1;
				continue;
			}
			if (/[0-9]/.test(ch) || ch === "." && /[0-9]/.test(line[i + 1] ?? "")) {
				const m = line.slice(i).match(/^[0-9]+(\.[0-9]+)?/);
				if (!m) throw err("SyntaxError", "Invalid number.", lineNo, "Numbers look like 10 or 3.14.", "Write a number such as 42.");
				tokens.push({
					type: "NUMBER",
					value: m[0],
					line: lineNo,
					col: i + 1
				});
				i += m[0].length;
				continue;
			}
			if (/[A-Za-z_]/.test(ch)) {
				const name = line.slice(i).match(/^[A-Za-z_][A-Za-z0-9_]*/)[0];
				tokens.push({
					type: KEYWORDS.has(name) ? name : "NAME",
					value: name,
					line: lineNo,
					col: i + 1
				});
				i += name.length;
				continue;
			}
			const two = line.slice(i, i + 2);
			if ([
				"==",
				"!=",
				"<=",
				">=",
				"+=",
				"-=",
				"*=",
				"/=",
				"//",
				"**"
			].includes(two)) {
				tokens.push({
					type: two,
					value: two,
					line: lineNo,
					col: i + 1
				});
				i += 2;
				continue;
			}
			const one = ch;
			if ("+-*/%=<>()[]{},:.".includes(one)) {
				tokens.push({
					type: one,
					value: one,
					line: lineNo,
					col: i + 1
				});
				i += 1;
				continue;
			}
			if (one === ";") {
				tokens.push({
					type: "NEWLINE",
					value: "",
					line: lineNo,
					col: i + 1
				});
				i += 1;
				continue;
			}
			throw err("SyntaxError", `Unexpected character '${ch}'.`, lineNo, "Python does not use that symbol here.", "Remove it, or check you didn't paste JavaScript / Java code.");
		}
		tokens.push({
			type: "NEWLINE",
			value: "",
			line: lineNo,
			col: line.length + 1
		});
	}
	while (indents.length > 1) {
		indents.pop();
		tokens.push({
			type: "DEDENT",
			value: "",
			line: lines.length,
			col: 1
		});
	}
	tokens.push({
		type: "EOF",
		value: "",
		line: lines.length,
		col: 1
	});
	return tokens;
}
var Parser = class {
	i = 0;
	toks;
	constructor(toks) {
		this.toks = toks;
	}
	peek() {
		return this.toks[this.i];
	}
	at(type) {
		return this.peek().type === type;
	}
	eat(type) {
		const t = this.peek();
		if (type && t.type !== type) throw err("SyntaxError", `Expected ${humanTok(type)}, found ${humanTok(t.type)}.`, t.line, hintForExpected(type, t), fixForExpected(type, t));
		this.i++;
		return t;
	}
	skipNewlines() {
		while (this.at("NEWLINE")) this.i++;
	}
	parse() {
		const body = [];
		this.skipNewlines();
		while (!this.at("EOF") && !this.at("DEDENT")) {
			body.push(this.stmt());
			this.skipNewlines();
		}
		return body;
	}
	stmt() {
		const t = this.peek();
		if (t.type === "if") return this.ifStmt();
		if (t.type === "for") return this.forStmt();
		if (t.type === "while") return this.whileStmt();
		if (t.type === "def") return this.defStmt();
		if (t.type === "return") {
			this.eat("return");
			if (this.at("NEWLINE") || this.at("DEDENT") || this.at("EOF")) {
				this.eat("NEWLINE");
				return {
					k: "return",
					e: null,
					line: t.line
				};
			}
			const e = this.expr();
			this.endline();
			return {
				k: "return",
				e,
				line: t.line
			};
		}
		if (t.type === "pass") {
			this.eat("pass");
			this.endline();
			return {
				k: "pass",
				line: t.line
			};
		}
		if (t.type === "break") {
			this.eat("break");
			this.endline();
			return {
				k: "break",
				line: t.line
			};
		}
		if (t.type === "continue") {
			this.eat("continue");
			this.endline();
			return {
				k: "continue",
				line: t.line
			};
		}
		if (t.type === "NAME" && (this.toks[this.i + 1]?.type === "=" || isAug(this.toks[this.i + 1]?.type))) {
			const name = this.eat("NAME").value;
			const op = this.eat().type;
			const e = this.expr();
			this.endline();
			return {
				k: "assign",
				name,
				e,
				op,
				line: t.line
			};
		}
		if (t.type === "NAME" && this.toks[this.i + 1]?.type === ",") {
			const names = [this.eat("NAME").value];
			while (this.at(",")) {
				this.eat(",");
				names.push(this.eat("NAME").value);
			}
			this.eat("=");
			const first = this.expr();
			let e = first;
			if (this.at(",")) {
				const items = [first];
				while (this.at(",")) {
					this.eat(",");
					if (this.at("NEWLINE") || this.at("EOF") || this.at("DEDENT")) break;
					items.push(this.expr());
				}
				e = {
					k: "list",
					items,
					line: t.line
				};
			}
			this.endline();
			return {
				k: "unpack",
				names,
				e,
				line: t.line
			};
		}
		const e = this.expr();
		if (this.at("=") && e.k === "index") {
			this.eat("=");
			const val = this.expr();
			this.endline();
			return {
				k: "setitem",
				target: e.target,
				index: e.index,
				e: val,
				line: t.line
			};
		}
		this.endline();
		return {
			k: "expr",
			e,
			line: t.line
		};
	}
	endline() {
		if (this.at("NEWLINE") || this.at("EOF") || this.at("DEDENT")) {
			if (this.at("NEWLINE")) this.eat("NEWLINE");
			return;
		}
		throw err("SyntaxError", "This line has extra code Python does not understand.", this.peek().line, "Each statement should be on its own line (or use a colon to start a block).", "Check for a missing colon, missing quote, or leftover character.");
	}
	suite() {
		if (!this.at("NEWLINE")) return [this.stmt()];
		this.eat("NEWLINE");
		this.skipNewlines();
		if (!this.at("INDENT")) throw err("IndentationError", "Expected an indented block.", this.peek().line, "After a colon (:) the next line must be indented with spaces.", "Press space four times before the next line, like:\n    print(\"hello\")");
		this.eat("INDENT");
		const body = [];
		this.skipNewlines();
		while (!this.at("DEDENT") && !this.at("EOF")) {
			body.push(this.stmt());
			this.skipNewlines();
		}
		if (this.at("DEDENT")) this.eat("DEDENT");
		if (body.length === 0) throw err("SyntaxError", "A block cannot be empty.", this.peek().line, "Every if / for / def needs at least one line inside it.", "Put a statement inside, or write pass.");
		return body;
	}
	ifStmt() {
		const line = this.peek().line;
		this.eat("if");
		const cond = this.expr();
		this.eat(":");
		const branches = [{
			cond,
			body: this.suite()
		}];
		while (this.at("elif")) {
			this.eat("elif");
			const c = this.expr();
			this.eat(":");
			branches.push({
				cond: c,
				body: this.suite()
			});
		}
		if (this.at("else")) {
			this.eat("else");
			this.eat(":");
			branches.push({
				cond: null,
				body: this.suite()
			});
		}
		return {
			k: "if",
			branches,
			line
		};
	}
	forStmt() {
		const line = this.peek().line;
		this.eat("for");
		const names = [this.eat("NAME").value];
		while (this.at(",")) {
			this.eat(",");
			names.push(this.eat("NAME").value);
		}
		this.eat("in");
		const iter = this.expr();
		this.eat(":");
		return {
			k: "for",
			names,
			iter,
			body: this.suite(),
			line
		};
	}
	whileStmt() {
		const line = this.peek().line;
		this.eat("while");
		const cond = this.expr();
		this.eat(":");
		return {
			k: "while",
			cond,
			body: this.suite(),
			line
		};
	}
	defStmt() {
		const line = this.peek().line;
		this.eat("def");
		const name = this.eat("NAME").value;
		this.eat("(");
		const params = [];
		if (!this.at(")")) {
			params.push(this.eat("NAME").value);
			while (this.at(",")) {
				this.eat(",");
				params.push(this.eat("NAME").value);
			}
		}
		this.eat(")");
		this.eat(":");
		return {
			k: "def",
			name,
			params,
			body: this.suite(),
			line
		};
	}
	expr() {
		const a = this.or();
		if (this.at("if")) {
			const line = this.peek().line;
			this.eat("if");
			const cond = this.or();
			this.eat("else");
			return {
				k: "ternary",
				cond,
				then: a,
				else: this.expr(),
				line
			};
		}
		return a;
	}
	or() {
		let a = this.and();
		while (this.at("or")) {
			const op = this.eat("or");
			a = {
				k: "bin",
				op: "or",
				a,
				b: this.and(),
				line: op.line
			};
		}
		return a;
	}
	and() {
		let a = this.not();
		while (this.at("and")) {
			const op = this.eat("and");
			a = {
				k: "bin",
				op: "and",
				a,
				b: this.not(),
				line: op.line
			};
		}
		return a;
	}
	not() {
		if (this.at("not")) {
			const op = this.eat("not");
			return {
				k: "unary",
				op: "not",
				x: this.not(),
				line: op.line
			};
		}
		return this.comparison();
	}
	comparison() {
		const first = this.arith();
		const ops = [];
		const items = [first];
		while ([
			"==",
			"!=",
			"<",
			">",
			"<=",
			">=",
			"in",
			"is"
		].includes(this.peek().type) || this.at("not") && this.toks[this.i + 1]?.type === "in") {
			if (this.at("is")) {
				this.eat("is");
				if (this.at("not")) {
					this.eat("not");
					ops.push("is not");
				} else ops.push("is");
			} else if (this.at("not")) {
				this.eat("not");
				this.eat("in");
				ops.push("not in");
			} else ops.push(this.eat().type);
			items.push(this.arith());
		}
		if (ops.length === 0) return first;
		return {
			k: "compare",
			ops,
			items,
			line: first.line
		};
	}
	arith() {
		let a = this.term();
		while (this.at("+") || this.at("-")) {
			const op = this.eat();
			a = {
				k: "bin",
				op: op.type,
				a,
				b: this.term(),
				line: op.line
			};
		}
		return a;
	}
	term() {
		let a = this.power();
		while (this.at("*") || this.at("/") || this.at("//") || this.at("%")) {
			const op = this.eat();
			a = {
				k: "bin",
				op: op.type,
				a,
				b: this.power(),
				line: op.line
			};
		}
		return a;
	}
	power() {
		const a = this.unary();
		if (this.at("**")) {
			const op = this.eat("**");
			return {
				k: "bin",
				op: "**",
				a,
				b: this.power(),
				line: op.line
			};
		}
		return a;
	}
	unary() {
		if (this.at("+") || this.at("-")) {
			const op = this.eat();
			return {
				k: "unary",
				op: op.type,
				x: this.unary(),
				line: op.line
			};
		}
		return this.trailer();
	}
	trailer() {
		let a = this.atom();
		while (true) if (this.at("(")) {
			const line = this.peek().line;
			this.eat("(");
			const args = [];
			if (!this.at(")")) {
				args.push(this.expr());
				while (this.at(",")) {
					this.eat(",");
					if (this.at(")")) break;
					args.push(this.expr());
				}
			}
			this.eat(")");
			a = {
				k: "call",
				fn: a,
				args,
				line
			};
		} else if (this.at("[")) {
			const line = this.peek().line;
			this.eat("[");
			if (this.at(":")) {
				this.eat(":");
				let end = null;
				let step = null;
				if (!this.at("]") && !this.at(":")) end = this.expr();
				if (this.at(":")) {
					this.eat(":");
					if (!this.at("]")) step = this.expr();
				}
				this.eat("]");
				a = {
					k: "slice",
					target: a,
					start: null,
					end,
					step,
					line
				};
			} else {
				const first = this.expr();
				if (this.at(":")) {
					this.eat(":");
					let end = null;
					let step = null;
					if (!this.at("]") && !this.at(":")) end = this.expr();
					if (this.at(":")) {
						this.eat(":");
						if (!this.at("]")) step = this.expr();
					}
					this.eat("]");
					a = {
						k: "slice",
						target: a,
						start: first,
						end,
						step,
						line
					};
				} else {
					this.eat("]");
					a = {
						k: "index",
						target: a,
						index: first,
						line
					};
				}
			}
		} else if (this.at(".")) {
			const line = this.peek().line;
			this.eat(".");
			const name = this.eat("NAME").value;
			a = {
				k: "attr",
				target: a,
				name,
				line
			};
		} else break;
		return a;
	}
	atom() {
		const t = this.peek();
		if (t.type === "NUMBER") {
			this.eat();
			return {
				k: "num",
				n: Number(t.value),
				line: t.line
			};
		}
		if (t.type === "STRING") {
			this.eat();
			return {
				k: "str",
				s: t.value,
				line: t.line
			};
		}
		if (t.type === "True" || t.type === "False") {
			this.eat();
			return {
				k: "const",
				v: t.type === "True",
				line: t.line
			};
		}
		if (t.type === "None") {
			this.eat();
			return {
				k: "const",
				v: null,
				line: t.line
			};
		}
		if (t.type === "NAME") {
			this.eat();
			return {
				k: "name",
				id: t.value,
				line: t.line
			};
		}
		if (t.type === "(") {
			this.eat("(");
			const e = this.expr();
			this.eat(")");
			return e;
		}
		if (t.type === "[") {
			this.eat("[");
			const items = [];
			if (!this.at("]")) {
				items.push(this.expr());
				while (this.at(",")) {
					this.eat(",");
					if (this.at("]")) break;
					items.push(this.expr());
				}
			}
			this.eat("]");
			return {
				k: "list",
				items,
				line: t.line
			};
		}
		if (t.type === "{") {
			this.eat("{");
			const keys = [];
			const vals = [];
			if (!this.at("}")) {
				keys.push(this.expr());
				this.eat(":");
				vals.push(this.expr());
				while (this.at(",")) {
					this.eat(",");
					if (this.at("}")) break;
					keys.push(this.expr());
					this.eat(":");
					vals.push(this.expr());
				}
			}
			this.eat("}");
			return {
				k: "dict",
				keys,
				vals,
				line: t.line
			};
		}
		throw err("SyntaxError", `Python did not expect ${humanTok(t.type)} here.`, t.line, "Check for a missing quote, missing parenthesis, or a word Python does not know.", "Look at the example in the briefing and match its shape.");
	}
};
function isAug(t) {
	return t === "+=" || t === "-=" || t === "*=" || t === "/=";
}
function humanTok(t) {
	return {
		NEWLINE: "end of line",
		INDENT: "indent",
		DEDENT: "dedent",
		EOF: "end of file",
		NAME: "a name",
		STRING: "a string",
		NUMBER: "a number",
		":": "a colon ':'",
		"(": "'('",
		")": "')'",
		"{": "'{'",
		"}": "'}'"
	}[t] ?? `'${t}'`;
}
function hintForExpected(expected, got) {
	if (expected === ":") return "if, for, while, def, and else lines must end with a colon (:). Dictionaries also use a colon between key and value.";
	if (expected === ")") return "Every '(' needs a matching ')'.";
	if (expected === "]") return "Every '[' needs a matching ']'.";
	if (expected === "}") return "Every '{' needs a matching '}'.";
	if (expected === "NAME") return "Python expected a variable name here.";
	if (got.type === "EOF") return "The line looks unfinished.";
	return `Python expected ${humanTok(expected)}.`;
}
function fixForExpected(expected, got) {
	if (expected === ":") return "Add a colon at the end, for example:\nif score >= 70:";
	if (expected === ")") return "Add the missing ')'.";
	if (expected === "NAME") return "Use a name like score or items — no quotes, no spaces.";
	return `Add ${humanTok(expected)}. Found ${humanTok(got.type)} instead.`;
}
var Env = class {
	map = /* @__PURE__ */ new Map();
	parent;
	constructor(parent = null) {
		this.parent = parent;
	}
	get(name) {
		if (this.map.has(name)) return this.map.get(name);
		return this.parent?.get(name);
	}
	set(name, v) {
		this.map.set(name, v);
	}
	hasLocal(name) {
		return this.map.has(name);
	}
};
var MAX_STEPS = 8e3;
var Interpreter = class Interpreter {
	stdout = [];
	steps = 0;
	env;
	constructor(env) {
		this.env = env;
	}
	tick(line) {
		this.steps++;
		if (this.steps > MAX_STEPS) throw err("RuntimeError", "This program ran too long (possible infinite loop).", line, "A while loop needs a condition that eventually becomes False.", "Make sure the loop variable changes, for example: i += 1");
	}
	run(body) {
		for (const s of body) {
			const r = this.exec(s);
			if (typeof r === "object") throw err("RuntimeError", "return used outside a function.", s.line, "return belongs in a function.", "Wrap the code in def, or remove return.");
			if (r === "break" || r === "continue") throw err("RuntimeError", `'${r}' used outside a loop.`, s.line, "break/continue belong in loops.", "Move it inside a for or while block.");
		}
	}
	exec(s) {
		this.tick(s.line);
		switch (s.k) {
			case "pass": return "ok";
			case "break": return "break";
			case "continue": return "continue";
			case "return": return { ret: s.e ? this.eval(s.e) : { t: "none" } };
			case "expr":
				this.eval(s.e);
				return "ok";
			case "assign": {
				const val = this.eval(s.e);
				if (s.op === "=") this.env.set(s.name, val);
				else {
					const cur = this.lookup(s.name, s.line);
					this.env.set(s.name, this.applyBin(s.op[0], cur, val, s.line));
				}
				return "ok";
			}
			case "unpack":
				this.unpack(s.names, this.eval(s.e), s.line);
				return "ok";
			case "setitem": {
				const target = this.eval(s.target);
				const index = this.eval(s.index);
				const val = this.eval(s.e);
				this.writeIndex(target, index, val, s.line);
				return "ok";
			}
			case "if":
				for (const b of s.branches) if (b.cond === null || isTruthy(this.eval(b.cond))) return this.execBlock(b.body);
				return "ok";
			case "for": {
				const iter = this.asList(this.eval(s.iter), s.line);
				for (const item of iter) {
					this.unpack(s.names, item, s.line);
					const r = this.execBlock(s.body);
					if (r === "break") break;
					if (r === "continue") continue;
					if (typeof r === "object") return r;
				}
				return "ok";
			}
			case "while":
				while (isTruthy(this.eval(s.cond))) {
					const r = this.execBlock(s.body);
					if (r === "break") break;
					if (r === "continue") continue;
					if (typeof r === "object") return r;
				}
				return "ok";
			case "def":
				this.env.set(s.name, {
					t: "fn",
					name: s.name,
					params: s.params,
					body: s.body,
					env: this.env
				});
				return "ok";
		}
	}
	unpack(names, item, line) {
		if (names.length === 1) {
			this.env.set(names[0], item);
			return;
		}
		const row = this.asList(item, line);
		if (row.length !== names.length) throw err("ValueError", `not enough values to unpack (expected ${names.length}, got ${row.length})`, line, "The number of names on the left of in must match each item.", "Example: for k, v in pairs:");
		names.forEach((n, i) => this.env.set(n, row[i]));
	}
	execBlock(body) {
		for (const s of body) {
			const r = this.exec(s);
			if (r !== "ok") return r;
		}
		return "ok";
	}
	lookup(name, line) {
		const v = this.env.get(name);
		if (v !== void 0) return v;
		const names = [];
		let e = this.env;
		while (e) {
			for (const k of e.map.keys()) names.push(k);
			e = e.parent;
		}
		const hint = suggest(name, names);
		throw err("NameError", `name '${name}' is not defined`, line, hint ? `Python does not know '${name}'. Did you mean '${hint}'? Names must be created before you use them.` : `Python does not know '${name}'. You must assign it first, for example: ${name} = 10`, hint ? `Replace '${name}' with '${hint}', or assign ${name} before using it.` : `Add a line above: ${name} = ...`);
	}
	eval(e) {
		this.tick(e.line);
		switch (e.k) {
			case "num": return {
				t: "num",
				v: e.n
			};
			case "str": return {
				t: "str",
				v: e.s
			};
			case "const":
				if (e.v === null) return { t: "none" };
				return {
					t: "bool",
					v: e.v
				};
			case "name": return this.lookup(e.id, e.line);
			case "list": return {
				t: "list",
				v: e.items.map((x) => this.eval(x))
			};
			case "dict": {
				const keys = [];
				const vals = [];
				for (let i = 0; i < e.keys.length; i++) {
					const key = this.eval(e.keys[i]);
					assertHashable(key, e.line);
					const val = this.eval(e.vals[i]);
					const existing = dictIndex(keys, key);
					if (existing >= 0) vals[existing] = val;
					else {
						keys.push(key);
						vals.push(val);
					}
				}
				return {
					t: "dict",
					keys,
					vals
				};
			}
			case "unary": {
				const x = this.eval(e.x);
				if (e.op === "not") return {
					t: "bool",
					v: !isTruthy(x)
				};
				if (e.op === "+") return asNum(x, e.line), x;
				if (e.op === "-") return {
					t: "num",
					v: -asNum(x, e.line)
				};
				throw err("SyntaxError", "Unknown unary operator.", e.line, "", "");
			}
			case "bin":
				if (e.op === "and") {
					const a = this.eval(e.a);
					return isTruthy(a) ? this.eval(e.b) : a;
				}
				if (e.op === "or") {
					const a = this.eval(e.a);
					return isTruthy(a) ? a : this.eval(e.b);
				}
				return this.applyBin(e.op, this.eval(e.a), this.eval(e.b), e.line);
			case "compare":
				for (let i = 0; i < e.ops.length; i++) if (!this.cmp(e.ops[i], this.eval(e.items[i]), this.eval(e.items[i + 1]), e.line)) return {
					t: "bool",
					v: false
				};
				return {
					t: "bool",
					v: true
				};
			case "ternary": return isTruthy(this.eval(e.cond)) ? this.eval(e.then) : this.eval(e.else);
			case "index": {
				const t = this.eval(e.target);
				const i = this.eval(e.index);
				return this.readIndex(t, i, e.line);
			}
			case "slice": {
				const t = this.eval(e.target);
				const start = e.start ? this.eval(e.start) : null;
				const end = e.end ? this.eval(e.end) : null;
				const step = e.step ? this.eval(e.step) : {
					t: "num",
					v: 1
				};
				return this.readSlice(t, start, end, step, e.line);
			}
			case "attr": throw err("TypeError", `'${e.name}' is a method — call it with parentheses.`, e.line, "Methods do nothing until you add (). print(text.upper) shows the method; print(text.upper()) runs it.", `Write ${e.name}() with parentheses.`);
			case "call": return this.call(e);
		}
	}
	readIndex(t, i, line) {
		if (t.t === "list") {
			const idx = asInt(i, line);
			const n = idx < 0 ? t.v.length + idx : idx;
			if (n < 0 || n >= t.v.length) throw err("IndexError", "list index out of range", line, "List indexes start at 0. The last item is len(list) - 1.", "Use a smaller index, or check len(your_list) first.");
			return t.v[n];
		}
		if (t.t === "str") {
			const idx = asInt(i, line);
			const n = idx < 0 ? t.v.length + idx : idx;
			if (n < 0 || n >= t.v.length) throw err("IndexError", "string index out of range", line, "String indexes start at 0.", "Use a smaller index.");
			return {
				t: "str",
				v: t.v[n]
			};
		}
		if (t.t === "dict") {
			const idx = dictIndex(t.keys, i);
			if (idx < 0) throw err("KeyError", `key ${reprVal(i)} is not in this dictionary`, line, "Dictionary keys must match exactly, including capitals.", "Check the key, or use .get(key) which returns None if missing.");
			return t.vals[idx];
		}
		throw err("TypeError", "This value cannot be indexed with [].", line, "[] is for lists, strings, and dictionaries.", "Index a list, for example items[0], or a dict like user[\"name\"].");
	}
	writeIndex(t, i, val, line) {
		if (t.t === "list") {
			const idx = asInt(i, line);
			const n = idx < 0 ? t.v.length + idx : idx;
			if (n < 0 || n >= t.v.length) throw err("IndexError", "list assignment index out of range", line, "You can only replace an index that already exists.", "Use append() to add a new item.");
			t.v[n] = val;
			return;
		}
		if (t.t === "dict") {
			assertHashable(i, line);
			const idx = dictIndex(t.keys, i);
			if (idx >= 0) t.vals[idx] = val;
			else {
				t.keys.push(i);
				t.vals.push(val);
			}
			return;
		}
		if (t.t === "str") throw err("TypeError", "strings cannot be changed in place", line, "Strings are immutable. Build a new string instead.", "Use replace() or concatenate with +.");
		throw err("TypeError", "This value does not support item assignment.", line, "Only lists and dictionaries can use name[key] = value.", "");
	}
	readSlice(t, start, end, stepV, line) {
		const step = asInt(stepV, line);
		if (step === 0) throw err("ValueError", "slice step cannot be zero", line, "A slice step of 0 never moves.", "Use 1, 2, or -1.");
		const len = t.t === "list" ? t.v.length : t.t === "str" ? t.v.length : -1;
		if (len < 0) throw err("TypeError", "This value cannot be sliced.", line, "Slicing with : works on lists and strings.", "Example: items[1:3]");
		const idx = sliceIndices(len, start ? asInt(start, line) : null, end ? asInt(end, line) : null, step);
		if (t.t === "str") {
			let out = "";
			for (const i of idx) out += t.v[i];
			return {
				t: "str",
				v: out
			};
		}
		if (t.t !== "list") throw err("TypeError", "This value cannot be sliced.", line, "Slicing with : works on lists and strings.", "Example: items[1:3]");
		return {
			t: "list",
			v: idx.map((i) => t.v[i])
		};
	}
	call(e) {
		if (e.fn.k === "attr") {
			const obj = this.eval(e.fn.target);
			const args = e.args.map((a) => this.eval(a));
			return this.method(obj, e.fn.name, args, e.line);
		}
		if (e.fn.k === "name") {
			const builtin = this.builtin(e.fn.id, e.args, e.line);
			if (builtin !== void 0) return builtin;
		}
		const fn = this.eval(e.fn);
		if (fn.t !== "fn") throw err("TypeError", "This value is not a function, so you cannot call it with ().", e.line, "Only functions (and tools like print, len) can be called.", "Check the name you are calling.");
		if (e.args.length !== fn.params.length) throw err("TypeError", `${fn.name}() takes ${fn.params.length} argument(s) but ${e.args.length} were given`, e.line, "The number of values inside the parentheses must match the function parameters.", `Call it like ${fn.name}(${fn.params.join(", ")})`);
		const local = new Env(fn.env);
		e.args.forEach((a, i) => local.set(fn.params[i], this.eval(a)));
		const inner = new Interpreter(local);
		inner.stdout = this.stdout;
		inner.steps = this.steps;
		const r = inner.execBlock(fn.body);
		this.steps = inner.steps;
		if (typeof r === "object") return r.ret;
		return { t: "none" };
	}
	method(obj, name, args, line) {
		if (obj.t === "str") return strMethod(obj.v, name, args, line);
		if (obj.t === "list") return listMethod(obj, name, args, line);
		if (obj.t === "dict") return dictMethod(obj, name, args, line);
		throw err("TypeError", `'${typeName(obj)}' has no method ${name}()`, line, "Methods belong to a type. Strings have upper/lower/strip. Lists have append/pop.", "Check the type of the value before the dot.");
	}
	builtin(name, args, line) {
		const evalArgs = () => args.map((a) => this.eval(a));
		switch (name) {
			case "print": {
				const vals = evalArgs();
				this.stdout.push(vals.map(strVal).join(" "));
				return { t: "none" };
			}
			case "len": {
				const [a] = need(evalArgs(), 1, "len", line);
				if (a.t === "list") return {
					t: "num",
					v: a.v.length
				};
				if (a.t === "str") return {
					t: "num",
					v: a.v.length
				};
				if (a.t === "dict") return {
					t: "num",
					v: a.keys.length
				};
				throw err("TypeError", "len() only works on lists, strings, and dictionaries.", line, "len tells you how many items / characters / keys.", "Use len on a list, string, or dict.");
			}
			case "str": {
				const [a] = need(evalArgs(), 1, "str", line);
				return {
					t: "str",
					v: strVal(a)
				};
			}
			case "int": {
				const [a] = need(evalArgs(), 1, "int", line);
				if (a.t === "num") return {
					t: "num",
					v: Math.trunc(a.v)
				};
				if (a.t === "bool") return {
					t: "num",
					v: a.v ? 1 : 0
				};
				if (a.t === "str") {
					const n = Number(a.v.trim());
					if (!Number.isFinite(n)) throw err("ValueError", `invalid literal for int(): '${a.v}'`, line, "int() needs digits like \"42\".", "Pass a numeric string or a number.");
					return {
						t: "num",
						v: Math.trunc(n)
					};
				}
				throw err("TypeError", "int() cannot convert this value.", line, "Use int on a number or a numeric string.", "Example: int(\"7\")");
			}
			case "range": {
				const a = evalArgs();
				let start = 0, stop = 0, step = 1;
				if (a.length === 1) stop = asInt(a[0], line);
				else if (a.length === 2) {
					start = asInt(a[0], line);
					stop = asInt(a[1], line);
				} else if (a.length === 3) {
					start = asInt(a[0], line);
					stop = asInt(a[1], line);
					step = asInt(a[2], line);
					if (step === 0) throw err("ValueError", "range() step cannot be zero.", line, "Step must be a non-zero integer.", "Use 1 or -1.");
				} else throw err("TypeError", "range() expected 1 to 3 arguments.", line, "range(stop) or range(start, stop).", "Example: range(3) → 0, 1, 2");
				const out = [];
				if (step > 0) for (let i = start; i < stop; i += step) out.push({
					t: "num",
					v: i
				});
				else for (let i = start; i > stop; i += step) out.push({
					t: "num",
					v: i
				});
				return {
					t: "list",
					v: out
				};
			}
			case "sum": {
				const [a] = need(evalArgs(), 1, "sum", line);
				if (a.t !== "list") throw err("TypeError", "sum() needs a list of numbers.", line, "Add numbers in a list.", "Example: sum([1, 2, 3])");
				let n = 0;
				for (const x of a.v) n += asNum(x, line);
				return {
					t: "num",
					v: n
				};
			}
			case "min":
			case "max": {
				const a = evalArgs();
				const nums = a.length === 1 && a[0].t === "list" ? a[0].v : a;
				if (nums.length === 0) throw err("ValueError", `${name}() of empty sequence`, line, "Give at least one number.", "");
				const vals = nums.map((x) => asNum(x, line));
				return {
					t: "num",
					v: name === "min" ? Math.min(...vals) : Math.max(...vals)
				};
			}
			case "abs": {
				const [a] = need(evalArgs(), 1, "abs", line);
				return {
					t: "num",
					v: Math.abs(asNum(a, line))
				};
			}
			case "type": {
				const [a] = need(evalArgs(), 1, "type", line);
				return {
					t: "str",
					v: a.t === "num" ? Number.isInteger(a.v) ? "int" : "float" : a.t === "str" ? "str" : a.t === "bool" ? "bool" : a.t === "list" ? "list" : a.t === "dict" ? "dict" : a.t === "fn" ? "function" : "NoneType"
				};
			}
			case "sorted": {
				const [a] = need(evalArgs(), 1, "sorted", line);
				const items = a.t === "list" ? [...a.v] : a.t === "str" ? [...a.v].map((c) => ({
					t: "str",
					v: c
				})) : a.t === "dict" ? [...a.keys] : null;
				if (!items) throw err("TypeError", "sorted() needs a list, string, or dict.", line, "sorted returns a new list in order.", "Example: sorted([3, 1, 2])");
				items.sort(cmpVals);
				return {
					t: "list",
					v: items
				};
			}
			case "list": {
				const a = evalArgs();
				if (a.length === 0) return {
					t: "list",
					v: []
				};
				const [x] = need(a, 1, "list", line);
				return {
					t: "list",
					v: [...this.asList(x, line)]
				};
			}
			case "enumerate": {
				const [a] = need(evalArgs(), 1, "enumerate", line);
				return {
					t: "list",
					v: this.asList(a, line).map((item, i) => ({
						t: "list",
						v: [{
							t: "num",
							v: i
						}, item]
					}))
				};
			}
			case "zip": {
				const seqs = evalArgs();
				if (seqs.length < 2) throw err("TypeError", "zip() expected at least 2 arguments.", line, "zip walks two lists in lockstep.", "zip(names, scores)");
				const lists = seqs.map((x) => this.asList(x, line));
				const n = Math.min(...lists.map((l) => l.length));
				const out = [];
				for (let i = 0; i < n; i++) out.push({
					t: "list",
					v: lists.map((l) => l[i])
				});
				return {
					t: "list",
					v: out
				};
			}
			case "any": {
				const [a] = need(evalArgs(), 1, "any", line);
				return {
					t: "bool",
					v: this.asList(a, line).some(isTruthy)
				};
			}
			case "all": {
				const [a] = need(evalArgs(), 1, "all", line);
				return {
					t: "bool",
					v: this.asList(a, line).every(isTruthy)
				};
			}
			case "round": {
				const a = evalArgs();
				if (a.length === 1) return {
					t: "num",
					v: Math.round(asNum(a[0], line))
				};
				if (a.length === 2) {
					const f = 10 ** asInt(a[1], line);
					return {
						t: "num",
						v: Math.round(asNum(a[0], line) * f) / f
					};
				}
				throw err("TypeError", "round() expected 1 or 2 arguments.", line, "round(n) or round(n, digits).", "round(3.7)");
			}
			case "float": {
				const [a] = need(evalArgs(), 1, "float", line);
				if (a.t === "num") return {
					t: "num",
					v: a.v
				};
				if (a.t === "bool") return {
					t: "num",
					v: a.v ? 1 : 0
				};
				if (a.t === "str") {
					const n = Number(a.v.trim());
					if (!Number.isFinite(n)) throw err("ValueError", `could not convert string to float: '${a.v}'`, line, "float() needs a numeric string.", "Example: float(\"3.5\")");
					return {
						t: "num",
						v: n
					};
				}
				throw err("TypeError", "float() cannot convert this value.", line, "Use float on a number or numeric string.", "float(\"2.5\")");
			}
			case "bool": {
				const [a] = need(evalArgs(), 1, "bool", line);
				return {
					t: "bool",
					v: isTruthy(a)
				};
			}
			case "reversed": {
				const [a] = need(evalArgs(), 1, "reversed", line);
				return {
					t: "list",
					v: [...this.asList(a, line)].reverse()
				};
			}
			case "ord": {
				const [a] = need(evalArgs(), 1, "ord", line);
				if (a.t !== "str" || a.v.length !== 1) throw err("TypeError", "ord() expected a string of length 1.", line, "ord turns one character into its number.", "ord(\"A\")");
				return {
					t: "num",
					v: a.v.charCodeAt(0)
				};
			}
			case "chr": {
				const [a] = need(evalArgs(), 1, "chr", line);
				const n = asInt(a, line);
				if (n < 0 || n > 1114111) throw err("ValueError", "chr() arg not in range.", line, "chr maps a number to a character.", "chr(65) is A");
				return {
					t: "str",
					v: String.fromCodePoint(n)
				};
			}
			default: return;
		}
	}
	asList(v, line) {
		if (v.t === "list") return v.v;
		if (v.t === "str") return [...v.v].map((c) => ({
			t: "str",
			v: c
		}));
		if (v.t === "dict") return v.keys;
		throw err("TypeError", "This value is not iterable.", line, "for x in ... needs a list, a string, a dict, or range(...).", "Use range(3) or a list like [1, 2, 3].");
	}
	applyBin(op, a, b, line) {
		if (op === "+") {
			if (a.t === "str" && b.t === "str") return {
				t: "str",
				v: a.v + b.v
			};
			if (a.t === "list" && b.t === "list") return {
				t: "list",
				v: [...a.v, ...b.v]
			};
			if (isNumeric(a) && isNumeric(b)) return {
				t: "num",
				v: num(a) + num(b)
			};
			throw err("TypeError", `cannot concatenate ${typeName(a)} and ${typeName(b)}`, line, "Use + with two numbers, two strings, or two lists — not mixed.", a.t === "str" || b.t === "str" ? "Convert the number with str(n), for example: \"Score: \" + str(10)" : "Make both sides numbers, or both strings.");
		}
		if (op === "*") {
			if (a.t === "str" && isNumeric(b)) return {
				t: "str",
				v: a.v.repeat(Math.max(0, Math.trunc(num(b))))
			};
			if (b.t === "str" && isNumeric(a)) return {
				t: "str",
				v: b.v.repeat(Math.max(0, Math.trunc(num(a))))
			};
			if (a.t === "list" && isNumeric(b)) return repeatList(a.v, Math.trunc(num(b)));
			if (b.t === "list" && isNumeric(a)) return repeatList(b.v, Math.trunc(num(a)));
			if (isNumeric(a) && isNumeric(b)) return {
				t: "num",
				v: num(a) * num(b)
			};
			throw err("TypeError", "Cannot multiply these values.", line, "* is for numbers, a string times a number, or a list times a number.", "Example: 3 * 4  or  \"ha\" * 3  or  [0] * 3");
		}
		if ([
			"-",
			"/",
			"//",
			"%",
			"**"
		].includes(op)) {
			const x = asNum(a, line);
			const y = asNum(b, line);
			if ((op === "/" || op === "//" || op === "%") && y === 0) throw err("RuntimeError", "division by zero", line, "You cannot divide by 0.", "Change the number on the right of / so it is not 0.");
			if (op === "-") return {
				t: "num",
				v: x - y
			};
			if (op === "/") return {
				t: "num",
				v: x / y
			};
			if (op === "//") return {
				t: "num",
				v: Math.floor(x / y)
			};
			if (op === "%") return {
				t: "num",
				v: x % y
			};
			if (op === "**") return {
				t: "num",
				v: x ** y
			};
		}
		throw err("TypeError", `Cannot use '${op}' on these values.`, line, "Check both sides of the operator.", "Use numbers with math operators.");
	}
	cmp(op, a, b, line) {
		if (op === "in" || op === "not in") {
			let found = false;
			if (b.t === "list") found = b.v.some((x) => eq(a, x));
			else if (b.t === "str" && a.t === "str") found = b.v.includes(a.v);
			else if (b.t === "dict") found = dictIndex(b.keys, a) >= 0;
			else throw err("TypeError", "'in' needs a list, string, or dictionary on the right.", line, "Example: \"a\" in \"cat\"  or  2 in [1, 2, 3]  or  \"name\" in user", "");
			return op === "in" ? found : !found;
		}
		if (op === "is" || op === "is not") {
			const same = identical(a, b);
			return op === "is" ? same : !same;
		}
		if (op === "==") return eq(a, b);
		if (op === "!=") return !eq(a, b);
		if (isNumeric(a) && isNumeric(b)) {
			const x = num(a), y = num(b);
			if (op === "<") return x < y;
			if (op === ">") return x > y;
			if (op === "<=") return x <= y;
			if (op === ">=") return x >= y;
		}
		if (a.t === "str" && b.t === "str") {
			if (op === "<") return a.v < b.v;
			if (op === ">") return a.v > b.v;
			if (op === "<=") return a.v <= b.v;
			if (op === ">=") return a.v >= b.v;
		}
		throw err("TypeError", `Cannot compare ${typeName(a)} and ${typeName(b)} with ${op}.`, line, "Compare the same kinds of values, like two numbers.", "Use == to check equality of any two values.");
	}
};
function strMethod(s, name, args, line) {
	switch (name) {
		case "upper":
			need(args, 0, "upper", line);
			return {
				t: "str",
				v: s.toUpperCase()
			};
		case "lower":
			need(args, 0, "lower", line);
			return {
				t: "str",
				v: s.toLowerCase()
			};
		case "strip":
			need(args, 0, "strip", line);
			return {
				t: "str",
				v: s.trim()
			};
		case "lstrip":
			need(args, 0, "lstrip", line);
			return {
				t: "str",
				v: s.replace(/^\s+/, "")
			};
		case "rstrip":
			need(args, 0, "rstrip", line);
			return {
				t: "str",
				v: s.replace(/\s+$/, "")
			};
		case "capitalize":
			need(args, 0, "capitalize", line);
			return {
				t: "str",
				v: s ? s[0].toUpperCase() + s.slice(1).toLowerCase() : ""
			};
		case "title":
			need(args, 0, "title", line);
			return {
				t: "str",
				v: s.toLowerCase().replace(/(^|[^A-Za-z])([A-Za-z])/g, (_, a, b) => a + b.toUpperCase())
			};
		case "split": {
			if (args.length === 0) return {
				t: "list",
				v: s.trim() ? s.trim().split(/\s+/).map((p) => ({
					t: "str",
					v: p
				})) : []
			};
			const [sep] = need(args, 1, "split", line);
			if (sep.t !== "str") throw err("TypeError", "split() separator must be a string.", line, "", "Example: text.split(\",\")");
			return {
				t: "list",
				v: s.split(sep.v).map((p) => ({
					t: "str",
					v: p
				}))
			};
		}
		case "join": {
			const [seq] = need(args, 1, "join", line);
			if (seq.t !== "list") throw err("TypeError", "join() needs a list of strings.", line, "The separator is the string before the dot.", "Example: \"-\".join([\"a\", \"b\"])");
			return {
				t: "str",
				v: seq.v.map((x) => {
					if (x.t !== "str") throw err("TypeError", "join() list items must be strings.", line, "Convert numbers with str() first.", "\"-\".join([str(1), str(2)])");
					return x.v;
				}).join(s)
			};
		}
		case "replace":
			if (args.length !== 2) throw err("TypeError", "replace() expected 2 arguments.", line, "old text, then new text.", "text.replace(\"a\", \"b\")");
			if (args[0].t !== "str" || args[1].t !== "str") throw err("TypeError", "replace() needs two strings.", line, "", "");
			return {
				t: "str",
				v: s.split(args[0].v).join(args[1].v)
			};
		case "find": {
			const [sub] = need(args, 1, "find", line);
			if (sub.t !== "str") throw err("TypeError", "find() needs a string.", line, "", "");
			return {
				t: "num",
				v: s.indexOf(sub.v)
			};
		}
		case "count": {
			const [sub] = need(args, 1, "count", line);
			if (sub.t !== "str") throw err("TypeError", "count() needs a string.", line, "", "");
			if (!sub.v) return {
				t: "num",
				v: s.length + 1
			};
			let n = 0;
			let i = 0;
			while (true) {
				const j = s.indexOf(sub.v, i);
				if (j < 0) break;
				n++;
				i = j + sub.v.length;
			}
			return {
				t: "num",
				v: n
			};
		}
		case "startswith": {
			const [sub] = need(args, 1, "startswith", line);
			if (sub.t !== "str") throw err("TypeError", "startswith() needs a string.", line, "", "");
			return {
				t: "bool",
				v: s.startsWith(sub.v)
			};
		}
		case "endswith": {
			const [sub] = need(args, 1, "endswith", line);
			if (sub.t !== "str") throw err("TypeError", "endswith() needs a string.", line, "", "");
			return {
				t: "bool",
				v: s.endsWith(sub.v)
			};
		}
		case "isdigit":
			need(args, 0, "isdigit", line);
			return {
				t: "bool",
				v: s.length > 0 && /^[0-9]+$/.test(s)
			};
		case "isalpha":
			need(args, 0, "isalpha", line);
			return {
				t: "bool",
				v: s.length > 0 && /^[A-Za-z]+$/.test(s)
			};
		case "islower":
			need(args, 0, "islower", line);
			return {
				t: "bool",
				v: s.length > 0 && s === s.toLowerCase() && /[A-Za-z]/.test(s)
			};
		case "isupper":
			need(args, 0, "isupper", line);
			return {
				t: "bool",
				v: s.length > 0 && s === s.toUpperCase() && /[A-Za-z]/.test(s)
			};
		case "isspace":
			need(args, 0, "isspace", line);
			return {
				t: "bool",
				v: s.length > 0 && /^\s+$/.test(s)
			};
		default: throw err("TypeError", `str has no method ${name}()`, line, "Common string methods: upper, lower, strip, split, join, replace, find, startswith.", `Check the spelling of ${name}.`);
	}
}
function listMethod(obj, name, args, line) {
	switch (name) {
		case "append": {
			const [x] = need(args, 1, "append", line);
			obj.v.push(x);
			return { t: "none" };
		}
		case "pop": {
			if (obj.v.length === 0) throw err("IndexError", "pop from empty list", line, "The list has no items left.", "Check len(list) first.");
			if (args.length === 0) return obj.v.pop();
			const [i] = need(args, 1, "pop", line);
			const idx = asInt(i, line);
			const n = idx < 0 ? obj.v.length + idx : idx;
			if (n < 0 || n >= obj.v.length) throw err("IndexError", "pop index out of range", line, "", "");
			return obj.v.splice(n, 1)[0];
		}
		case "insert": {
			const [i, x] = args.length === 2 ? args : need(args, 2, "insert", line);
			if (args.length !== 2) throw err("TypeError", "insert() expected 2 arguments.", line, "index, then value.", "items.insert(0, \"Ada\")");
			let n = asInt(i, line);
			if (n < 0) n = 0;
			if (n > obj.v.length) n = obj.v.length;
			obj.v.splice(n, 0, x);
			return { t: "none" };
		}
		case "remove": {
			const [x] = need(args, 1, "remove", line);
			const idx = obj.v.findIndex((v) => eq(v, x));
			if (idx < 0) throw err("ValueError", "list.remove(x): x not in list", line, "remove deletes the first matching item.", "Check the value exists first.");
			obj.v.splice(idx, 1);
			return { t: "none" };
		}
		case "extend": {
			const [seq] = need(args, 1, "extend", line);
			if (seq.t !== "list") throw err("TypeError", "extend() needs a list.", line, "", "items.extend([1, 2])");
			obj.v.push(...seq.v);
			return { t: "none" };
		}
		case "clear":
			need(args, 0, "clear", line);
			obj.v.length = 0;
			return { t: "none" };
		case "copy":
			need(args, 0, "copy", line);
			return {
				t: "list",
				v: [...obj.v]
			};
		case "reverse":
			need(args, 0, "reverse", line);
			obj.v.reverse();
			return { t: "none" };
		case "sort":
			need(args, 0, "sort", line);
			obj.v.sort(cmpVals);
			return { t: "none" };
		case "count": {
			const [x] = need(args, 1, "count", line);
			return {
				t: "num",
				v: obj.v.filter((v) => eq(v, x)).length
			};
		}
		case "index": {
			const [x] = need(args, 1, "index", line);
			const idx = obj.v.findIndex((v) => eq(v, x));
			if (idx < 0) throw err("ValueError", `${reprVal(x)} is not in list`, line, "index finds the first position.", "Check the value, or use `x in items` first.");
			return {
				t: "num",
				v: idx
			};
		}
		default: throw err("TypeError", `list has no method ${name}()`, line, "Common list methods: append, pop, insert, remove, sort, reverse.", `Check the spelling of ${name}.`);
	}
}
function dictMethod(obj, name, args, line) {
	switch (name) {
		case "get": {
			if (args.length < 1 || args.length > 2) throw err("TypeError", "get() expected 1 or 2 arguments.", line, "key, and optional default.", "user.get(\"name\")");
			const idx = dictIndex(obj.keys, args[0]);
			if (idx >= 0) return obj.vals[idx];
			return args[1] ?? { t: "none" };
		}
		case "keys":
			need(args, 0, "keys", line);
			return {
				t: "list",
				v: [...obj.keys]
			};
		case "values":
			need(args, 0, "values", line);
			return {
				t: "list",
				v: [...obj.vals]
			};
		case "items":
			need(args, 0, "items", line);
			return {
				t: "list",
				v: obj.keys.map((k, i) => ({
					t: "list",
					v: [k, obj.vals[i]]
				}))
			};
		case "pop": {
			const [key] = need(args, 1, "pop", line);
			const idx = dictIndex(obj.keys, key);
			if (idx < 0) throw err("KeyError", `key ${reprVal(key)} is not in this dictionary`, line, "", "");
			const val = obj.vals[idx];
			obj.keys.splice(idx, 1);
			obj.vals.splice(idx, 1);
			return val;
		}
		case "clear":
			need(args, 0, "clear", line);
			obj.keys.length = 0;
			obj.vals.length = 0;
			return { t: "none" };
		case "update": {
			const [other] = need(args, 1, "update", line);
			if (other.t !== "dict") throw err("TypeError", "update() needs a dictionary.", line, "Merge another dict into this one.", "user.update({\"role\": \"lead\"})");
			for (let i = 0; i < other.keys.length; i++) {
				const idx = dictIndex(obj.keys, other.keys[i]);
				if (idx >= 0) obj.vals[idx] = other.vals[i];
				else {
					obj.keys.push(other.keys[i]);
					obj.vals.push(other.vals[i]);
				}
			}
			return { t: "none" };
		}
		case "setdefault": {
			if (args.length < 1 || args.length > 2) throw err("TypeError", "setdefault() expected 1 or 2 arguments.", line, "key, and optional default.", "freq.setdefault(ch, 0)");
			const key = args[0];
			const def = args[1] ?? { t: "none" };
			const idx = dictIndex(obj.keys, key);
			if (idx >= 0) return obj.vals[idx];
			assertHashable(key, line);
			obj.keys.push(key);
			obj.vals.push(def);
			return def;
		}
		default: throw err("TypeError", `dict has no method ${name}()`, line, "Common dict methods: get, keys, values, items.", `Check the spelling of ${name}.`);
	}
}
function need(args, n, name, line) {
	if (args.length !== n) throw err("TypeError", `${name}() expected ${n} argument(s).`, line, "Check the parentheses.", `Example: ${name}(...)`);
	return args;
}
function isNumeric(v) {
	return v.t === "num" || v.t === "bool";
}
function repeatList(items, times) {
	const n = Math.max(0, times);
	const out = [];
	for (let i = 0; i < n; i++) out.push(...items);
	return {
		t: "list",
		v: out
	};
}
function identical(a, b) {
	if (a.t === "none" && b.t === "none") return true;
	if (a.t === "bool" && b.t === "bool") return a.v === b.v;
	if (a.t === "num" && b.t === "num") return a.v === b.v;
	if (a.t === "str" && b.t === "str") return a.v === b.v;
	return a === b;
}
function num(v) {
	if (v.t === "num") return v.v;
	if (v.t === "bool") return v.v ? 1 : 0;
	return 0;
}
function asNum(v, line) {
	if (!isNumeric(v)) throw err("TypeError", `${typeName(v)} is not a number.`, line, "Math operators need numbers.", "Remove quotes if you meant a number: 10 not \"10\".");
	return num(v);
}
function asInt(v, line) {
	return Math.trunc(asNum(v, line));
}
function isTruthy(v) {
	if (v.t === "none") return false;
	if (v.t === "bool") return v.v;
	if (v.t === "num") return v.v !== 0;
	if (v.t === "str") return v.v.length > 0;
	if (v.t === "list") return v.v.length > 0;
	if (v.t === "dict") return v.keys.length > 0;
	return true;
}
function eq(a, b) {
	if (a.t !== b.t) {
		if (isNumeric(a) && isNumeric(b)) return num(a) === num(b);
		return false;
	}
	if (a.t === "none") return true;
	if (a.t === "num" && b.t === "num") return a.v === b.v;
	if (a.t === "str" && b.t === "str") return a.v === b.v;
	if (a.t === "bool" && b.t === "bool") return a.v === b.v;
	if (a.t === "list" && b.t === "list") return a.v.length === b.v.length && a.v.every((x, i) => eq(x, b.v[i]));
	if (a.t === "dict" && b.t === "dict") {
		if (a.keys.length !== b.keys.length) return false;
		return a.keys.every((k, i) => {
			const j = dictIndex(b.keys, k);
			return j >= 0 && eq(a.vals[i], b.vals[j]);
		});
	}
	return false;
}
function typeName(v) {
	if (v.t === "num") return Number.isInteger(v.v) ? "int" : "float";
	if (v.t === "str") return "str";
	if (v.t === "bool") return "bool";
	if (v.t === "list") return "list";
	if (v.t === "dict") return "dict";
	if (v.t === "fn") return "function";
	return "NoneType";
}
function strVal(v) {
	if (v.t === "none") return "None";
	if (v.t === "bool") return v.v ? "True" : "False";
	if (v.t === "num") return Number.isInteger(v.v) ? String(v.v) : String(v.v);
	if (v.t === "str") return v.v;
	if (v.t === "fn") return `<function ${v.name}>`;
	if (v.t === "dict") {
		if (v.keys.length === 0) return "{}";
		return "{" + v.keys.map((k, i) => `${reprVal(k)}: ${reprVal(v.vals[i])}`).join(", ") + "}";
	}
	return "[" + v.v.map(reprVal).join(", ") + "]";
}
function reprVal(v) {
	if (v.t === "str") return "'" + v.v.replace(/'/g, "\\'") + "'";
	return strVal(v);
}
function dictIndex(keys, key) {
	return keys.findIndex((k) => eq(k, key));
}
function assertHashable(key, line) {
	if (key.t === "list" || key.t === "dict" || key.t === "fn") throw err("TypeError", "unhashable type: '" + typeName(key) + "'", line, "Dictionary keys must be simple values — strings, numbers, or True/False.", "Use a string key, for example user[\"name\"].");
}
function sliceIndices(length, start, stop, step) {
	let s;
	let e;
	if (step > 0) {
		s = start === null ? 0 : start;
		e = stop === null ? length : stop;
		if (s < 0) s += length;
		if (e < 0) e += length;
		if (s < 0) s = 0;
		if (e < 0) e = 0;
		if (s > length) s = length;
		if (e > length) e = length;
	} else {
		s = start === null ? length - 1 : start;
		e = stop === null ? -1 : stop;
		if (start !== null) {
			if (s < 0) s += length;
			if (s < 0) s = -1;
			if (s >= length) s = length - 1;
		}
		if (stop !== null) {
			if (e < 0) e += length;
			if (e < -1) e = -1;
			if (e >= length) e = length;
		}
	}
	const out = [];
	if (step > 0) for (let i = s; i < e; i += step) out.push(i);
	else for (let i = s; i > e; i += step) out.push(i);
	return out;
}
function cmpVals(a, b) {
	if (isNumeric(a) && isNumeric(b)) return num(a) - num(b);
	if (a.t === "str" && b.t === "str") return a.v < b.v ? -1 : a.v > b.v ? 1 : 0;
	return typeName(a).localeCompare(typeName(b));
}
function suggest(name, names) {
	let best = null;
	let bestD = 3;
	for (const n of names) {
		const d = levenshtein(name, n);
		if (d < bestD) {
			bestD = d;
			best = n;
		}
	}
	return best;
}
function levenshtein(a, b) {
	const m = [];
	for (let i = 0; i <= a.length; i++) {
		m[i] = [i];
		for (let j = 1; j <= b.length; j++) if (i === 0) m[0][j] = j;
		else m[i][j] = Math.min(m[i - 1][j] + 1, m[i][j - 1] + 1, m[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
	}
	return m[a.length][b.length];
}
var BUILTIN_NAMES = [
	"print",
	"len",
	"str",
	"int",
	"range",
	"sum",
	"min",
	"max",
	"abs",
	"type",
	"sorted",
	"list",
	"enumerate"
];
function builtinsEnv() {
	const e = new Env(null);
	for (const n of BUILTIN_NAMES) e.set(n, {
		t: "fn",
		name: n,
		params: [],
		body: [],
		env: e
	});
	return e;
}
function runPython(source) {
	try {
		if (typeof source !== "string") return {
			ok: false,
			stdout: "",
			error: err("RuntimeError", "No code provided.", 1, "Type some Python in the editor.", "Start with print(\"Hello\")")
		};
		if (!source.trim()) return {
			ok: false,
			stdout: "",
			error: err("SyntaxError", "Your editor is empty.", 1, "Python needs at least one instruction.", "Type: print(\"Hello, Jarvis\")")
		};
		const ast = new Parser(tokenize(source)).parse();
		const interp = new Interpreter(new Env(builtinsEnv()));
		interp.run(ast);
		return {
			ok: true,
			stdout: interp.stdout.join("\n") + (interp.stdout.length ? "\n" : "")
		};
	} catch (e) {
		if (e && typeof e === "object" && "kind" in e) return {
			ok: false,
			stdout: "",
			error: e
		};
		return {
			ok: false,
			stdout: "",
			error: err("RuntimeError", e instanceof Error ? e.message : "Unknown error", 1, "Something unexpected happened.", "Try simplifying your code.")
		};
	}
}
function normalizeOutput(s) {
	return s.replace(/\r\n/g, "\n").replace(/[ \t]+$/gm, "").replace(/\n+$/, "");
}
function outputsMatch(got, expected) {
	return normalizeOutput(got) === normalizeOutput(expected);
}
var HABITS = [
	{
		re: /\bconsole\.log\b/,
		title: "That's JavaScript",
		what: "You used console.log — that's JavaScript, not Python.",
		why: "Python talks to the screen with the print() function.",
		fix: "Replace console.log with print.",
		example: "print(\"Hello\")"
	},
	{
		re: /\bSystem\.out\.print/,
		title: "That's Java",
		what: "System.out.println is Java.",
		why: "Python uses print().",
		fix: "Write print(\"...\") instead.",
		example: "print(\"Hello\")"
	},
	{
		re: /\b(let|const|var)\s+[A-Za-z_]/,
		title: "That's JavaScript",
		what: "let / const / var are JavaScript keywords.",
		why: "In Python you just write the name, then =, then the value.",
		fix: "Drop let/const/var. Use: name = value",
		example: "score = 10"
	},
	{
		re: /\bfunction\s+[A-Za-z_]/,
		title: "That's JavaScript",
		what: "function is how JavaScript defines functions.",
		why: "Python uses def, a colon, then an indented body.",
		fix: "Write: def name(args):",
		example: "def greet(name):\n    return \"Hi \" + name"
	},
	{
		re: /^\s*print\s+["'].+["']\s*$/m,
		title: "Python 3 needs parentheses",
		what: "You wrote a Python 2 print statement.",
		why: "In Python 3, print is a function, so it needs parentheses.",
		fix: "Wrap the text in print(...)",
		example: "print(\"Hello, Jarvis\")"
	},
	{
		re: /\b(if|for|while|elif|else|def|function)\b[^\n]*\{/,
		title: "Python does not use { } for blocks",
		what: "Curly braces after if/for/while look like JavaScript or Java.",
		why: "Python groups code with indentation (spaces) after a colon. { } are only for dictionaries, like {\"name\": \"Ada\"}.",
		fix: "Use a colon and indent the next line with 4 spaces.",
		example: "if score >= 70:\n    print(\"PASS\")"
	}
];
function preScanHabits(source) {
	for (const h of HABITS) if (h.re.test(source)) return {
		status: "error",
		title: h.title,
		what: h.what,
		why: h.why,
		fix: h.fix,
		example: h.example
	};
	return null;
}
function analyzeRun(source, expected) {
	const habit = preScanHabits(source);
	const result = runPython(source);
	if (habit && !result.ok) return {
		result,
		feedback: {
			...habit,
			line: result.error?.line
		}
	};
	if (!result.ok && result.error) return {
		result,
		feedback: fromError(source, result.error)
	};
	if (outputsMatch(result.stdout, expected)) return {
		result,
		feedback: {
			status: "success",
			title: "Correct",
			what: "Your program produced the expected output.",
			why: "Python ran each line from top to bottom and print() showed the result.",
			fix: "On to the next task."
		}
	};
	return {
		result,
		feedback: fromMismatch(source, result.stdout, expected)
	};
}
function fromError(source, error) {
	const extra = extraHints(source, error);
	return {
		status: "error",
		title: error.kind,
		what: error.message,
		why: extra.why || error.hint,
		fix: extra.fix || error.fix,
		example: extra.example,
		line: error.line
	};
}
function extraHints(source, error) {
	const line = source.split("\n")[error.line - 1] ?? "";
	if (error.kind === "NameError") {
		const name = error.message.match(/'([^']+)'/)?.[1];
		if (name && new RegExp(`print\\(\\s*${name}\\s*\\)`).test(source) && !source.includes(`${name} =`) && !source.includes(`"${name}"`) && !source.includes(`'${name}'`)) return {
			why: `Python thinks ${name} is a variable, because it has no quotes. Variables must be created with = first. Text you want to show as-is is a string and needs quotes.`,
			fix: `If you meant to show the word ${name}, wrap it in quotes. If you meant a variable, assign it first.`,
			example: `print("${name}")\n# or\n${name} = "Ada"\nprint(${name})`
		};
	}
	if (error.kind === "SyntaxError" && /if |for |while |def |else/.test(line) && !line.includes(":")) return {
		why: "This kind of line starts a block. Python needs a colon at the end so it knows the next indented lines belong to it.",
		fix: "Add : at the end of the line.",
		example: line.trimEnd() + ":"
	};
	if (error.kind === "TypeError" && /concatenate|str.*int|int.*str/.test(error.message + error.hint)) return {
		why: "Python will not silently mix text and numbers with +.",
		fix: "Wrap the number in str(...) so it becomes text.",
		example: "print(\"Score: \" + str(10))"
	};
	if (error.kind === "IndentationError") return {
		why: "Spaces at the start of a line are part of the language, not decoration.",
		fix: "Use exactly 4 spaces per level. Keep lines in the same block lined up.",
		example: "if True:\n    print(\"indented\")"
	};
	return {};
}
function fromMismatch(source, got, expected) {
	const g = stripEnd(got);
	const e = stripEnd(expected);
	const gq = g.replace(/^['"]|['"]$/g, "");
	const eq = e.replace(/^['"]|['"]$/g, "");
	if (g === `"${e}"` || g === `'${e}'`) return {
		status: "wrong",
		title: "Extra quotes",
		what: "Your program printed quote marks around the text.",
		why: "print already shows the string. If you write extra quotes inside the string, they become part of the output.",
		fix: "Print the text without extra quote characters inside.",
		example: `print("${e}")`,
		got: g,
		expected: e
	};
	if (g.toLowerCase() === e.toLowerCase() && g !== e) return {
		status: "wrong",
		title: "Capital letters matter",
		what: "The letters are right but the capitalization is not.",
		why: "Python treats Hello and hello as different text.",
		fix: "Match the expected text exactly, including capitals.",
		got: g,
		expected: e
	};
	if (gq === e || g === eq) return {
		status: "wrong",
		title: "Almost — check quotes",
		what: "The words are close, but the quotes in the output do not match.",
		why: "Only characters inside print(...) that are part of the string appear. The wrapping quotes of the code do not print — unless you added extra ones.",
		fix: "Copy the expected text exactly inside one pair of quotes.",
		got: g,
		expected: e
	};
	if (g.replace(/\s+/g, "") === e.replace(/\s+/g, "")) return {
		status: "wrong",
		title: "Spacing does not match",
		what: "The words are right, the spaces are not.",
		why: "Python prints exactly the spaces you give it. Extra or missing spaces count as wrong.",
		fix: "Match spaces and line breaks exactly.",
		got: g,
		expected: e
	};
	if (!g) return {
		status: "wrong",
		title: "Nothing was printed",
		what: "The program ran, but print() never showed the required text.",
		why: "Assignments like name = \"Ada\" store a value. They do not show it. print() is what writes to the screen.",
		fix: "Call print(...) with the value you want to show.",
		example: source.includes("=") ? "After you assign, add: print(your_variable)" : `print("${e.split("\n")[0]}")`,
		got: g,
		expected: e
	};
	const gl = g.split("\n");
	const el = e.split("\n");
	if (gl.length !== el.length) return {
		status: "wrong",
		title: gl.length > el.length ? "Extra lines" : "Missing lines",
		what: `Python printed ${gl.length} line(s). The mission expected ${el.length}.`,
		why: "Each print() usually adds one line. A loop prints once per item.",
		fix: gl.length > el.length ? "Remove extra print() calls." : "Add the missing print() so every required line appears.",
		got: g,
		expected: e
	};
	return {
		status: "wrong",
		title: "Output does not match",
		what: "The program ran, but it printed something different from the mission.",
		why: "Read the task again. print() shows exactly what you pass it — numbers calculate, quotes stay as text.",
		fix: "Compare your output with the expected output line by line, then adjust the print() or the calculation.",
		got: g,
		expected: e
	};
}
function stripEnd(s) {
	return s.replace(/\r\n/g, "\n").replace(/[ \t]+$/gm, "").replace(/\n+$/, "");
}
function formatOutput(s) {
	if (!s) return "(empty)";
	return s.replace(/\n+$/, "");
}
var bus = null;
var muted = false;
function getBus() {
	if (typeof window === "undefined") return null;
	if (bus) return bus;
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return null;
	const ctx = new AC({ latencyHint: "interactive" });
	const master = ctx.createGain();
	const sfx = ctx.createGain();
	sfx.gain.value = .28;
	master.gain.value = muted ? 0 : 1;
	sfx.connect(master);
	master.connect(ctx.destination);
	bus = {
		ctx,
		master,
		sfx
	};
	return bus;
}
function resume() {
	const b = getBus();
	if (!b) return;
	if (b.ctx.state === "suspended") b.ctx.resume();
}
function beep(opts) {
	if (muted) return;
	const b = getBus();
	if (!b) return;
	resume();
	const t0 = b.ctx.currentTime + (opts.delay ?? 0);
	const osc = b.ctx.createOscillator();
	const g = b.ctx.createGain();
	osc.type = opts.type ?? "sine";
	osc.frequency.setValueAtTime(opts.freq, t0);
	if (opts.slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, opts.slide), t0 + opts.dur);
	const vol = opts.gain ?? .22;
	g.gain.setValueAtTime(1e-4, t0);
	g.gain.exponentialRampToValueAtTime(vol, t0 + .012);
	g.gain.exponentialRampToValueAtTime(1e-4, t0 + opts.dur);
	osc.connect(g);
	g.connect(b.sfx);
	osc.start(t0);
	osc.stop(t0 + opts.dur + .02);
	osc.onended = () => {
		osc.disconnect();
		g.disconnect();
	};
}
var audio = {
	unlock() {
		resume();
	},
	setMuted(v) {
		muted = v;
		if (bus) bus.master.gain.setTargetAtTime(v ? 0 : 1, bus.ctx.currentTime, .02);
	},
	click() {
		beep({
			freq: 720,
			dur: .05,
			type: "square",
			gain: .08
		});
	},
	success() {
		beep({
			freq: 523,
			dur: .09,
			type: "triangle",
			gain: .16
		});
		beep({
			freq: 784,
			dur: .12,
			type: "triangle",
			gain: .14,
			delay: .07
		});
	},
	fail() {
		beep({
			freq: 220,
			dur: .16,
			type: "sawtooth",
			gain: .1,
			slide: 110
		});
	},
	complete() {
		beep({
			freq: 392,
			dur: .12,
			type: "triangle",
			gain: .14
		});
		beep({
			freq: 523,
			dur: .12,
			type: "triangle",
			gain: .14,
			delay: .1
		});
		beep({
			freq: 659,
			dur: .18,
			type: "triangle",
			gain: .16,
			delay: .2
		});
	},
	levelup() {
		beep({
			freq: 440,
			dur: .1,
			type: "square",
			gain: .1
		});
		beep({
			freq: 554,
			dur: .1,
			type: "square",
			gain: .1,
			delay: .09
		});
		beep({
			freq: 659,
			dur: .1,
			type: "square",
			gain: .1,
			delay: .18
		});
		beep({
			freq: 880,
			dur: .2,
			type: "triangle",
			gain: .14,
			delay: .28
		});
	},
	unlockReward() {
		beep({
			freq: 330,
			dur: .16,
			type: "sine",
			gain: .14
		});
		beep({
			freq: 495,
			dur: .16,
			type: "sine",
			gain: .12,
			delay: .12
		});
		beep({
			freq: 660,
			dur: .28,
			type: "triangle",
			gain: .16,
			delay: .24
		});
	},
	go() {
		beep({
			freq: 880,
			dur: .14,
			type: "square",
			gain: .12
		});
	}
};
if (typeof window !== "undefined") {
	window.addEventListener("pointerdown", () => audio.unlock(), { once: true });
	window.addEventListener("keydown", () => audio.unlock(), { once: true });
	document.addEventListener("visibilitychange", () => {
		if (document.visibilityState === "visible") audio.unlock();
	});
}
function CodeEditor({ challenge, onPass, onFail, disabled, fileName = "mission.py" }) {
	const [code, setCode] = (0, import_react.useState)(challenge.starter);
	const [feedback, setFeedback] = (0, import_react.useState)(null);
	const [attempts, setAttempts] = (0, import_react.useState)(0);
	const [hintN, setHintN] = (0, import_react.useState)(0);
	const [showSol, setShowSol] = (0, import_react.useState)(false);
	const [passed, setPassed] = (0, import_react.useState)(false);
	const ta = (0, import_react.useRef)(null);
	const startedAt = (0, import_react.useRef)(Date.now());
	(0, import_react.useEffect)(() => {
		setCode(challenge.starter);
		setFeedback(null);
		setAttempts(0);
		setHintN(0);
		setShowSol(false);
		setPassed(false);
		startedAt.current = Date.now();
	}, [challenge.id, challenge.starter]);
	function run() {
		if (disabled || passed) return;
		const { feedback: fb } = analyzeRun(code, challenge.expected);
		setFeedback(fb);
		const nextAttempts = attempts + 1;
		setAttempts(nextAttempts);
		if (fb.status === "success") {
			audio.success();
			setPassed(true);
			const stats = {
				attempts: nextAttempts,
				hintsUsed: hintN,
				showedSolution: showSol,
				elapsedMs: Date.now() - startedAt.current
			};
			window.setTimeout(() => onPass(stats), 550);
		} else {
			audio.fail();
			onFail?.();
		}
	}
	function onKey(e) {
		if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
			e.preventDefault();
			run();
			return;
		}
		if (e.key === "Tab") {
			e.preventDefault();
			const el = e.currentTarget;
			const start = el.selectionStart;
			const end = el.selectionEnd;
			const next = code.slice(0, start) + "    " + code.slice(end);
			setCode(next);
			requestAnimationFrame(() => {
				el.selectionStart = el.selectionEnd = start + 4;
			});
		}
	}
	const lines = Math.max(6, code.split("\n").length);
	const nums = Array.from({ length: lines }, (_, i) => i + 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-card)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
						children: challenge.concept
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 text-lg font-semibold leading-snug text-fg",
						children: challenge.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: challenge.prompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "mt-3 rounded-md bg-bg-elevated px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
								className: "cursor-pointer text-sm font-medium text-fg",
								children: "Python briefing"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: challenge.briefing
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-2 overflow-x-auto font-mono text-xs leading-relaxed text-accent",
								children: challenge.example
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("overflow-hidden rounded-xl bg-bg-elevated shadow-[var(--shadow-card)]", feedback?.line && feedback.status !== "success" && "ring-1 ring-danger/60"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-[11px] uppercase tracking-[0.12em] text-subtle",
						children: fileName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-subtle",
						children: "Tab indents · Ctrl+Enter runs"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-36",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "select-none bg-bg py-3 pl-3 pr-2 font-mono text-xs leading-6 text-subtle tabular",
						children: nums.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("text-right", feedback?.line === n && "text-danger"),
							children: n
						}, n))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						ref: ta,
						value: code,
						onChange: (e) => setCode(e.target.value),
						onKeyDown: onKey,
						spellCheck: false,
						autoCapitalize: "off",
						autoCorrect: "off",
						disabled: disabled || passed,
						"aria-label": "Python editor",
						className: "min-h-36 w-full resize-y bg-transparent px-3 py-3 font-mono text-[16px] leading-6 text-fg outline-none md:text-sm"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: run,
					disabled: disabled || passed,
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 translate-x-px" }), passed ? "Passed" : "Run code"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					onClick: () => {
						audio.click();
						setCode(challenge.starter);
						setFeedback(null);
						setPassed(false);
					},
					disabled,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					disabled: hintN >= challenge.hints.length,
					onClick: () => {
						audio.click();
						setHintN((n) => Math.min(challenge.hints.length, n + 1));
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-4" }),
						"Hint ",
						hintN > 0 ? `${hintN}/${challenge.hints.length}` : ""
					]
				}), attempts >= 2 && !passed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => {
						audio.click();
						setShowSol(true);
					},
					children: "Show working code"
				})]
			}),
			hintN > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 rounded-lg bg-surface px-3 py-2 text-sm text-muted",
				children: challenge.hints.slice(0, hintN).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: h }, h))
			}),
			showSol && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "overflow-x-auto rounded-lg bg-surface-2 p-3 font-mono text-xs text-accent",
				children: challenge.solution
			}),
			feedback && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedbackCard, { fb: feedback })
		]
	});
}
function FeedbackCard({ fb }) {
	const ok = fb.status === "success";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("animate-rise rounded-xl p-4 shadow-[var(--shadow-card)]", ok ? "bg-success/10" : "bg-surface"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5 text-success" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-5 text-warn" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-fg",
						children: fb.title
					}),
					fb.line ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto font-mono text-xs text-subtle",
						children: ["line ", fb.line]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-fg",
				children: fb.what
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-fg",
					children: "Why. "
				}), fb.why]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-fg",
					children: "Fix. "
				}), fb.fix]
			}),
			fb.example && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-3 overflow-x-auto rounded-md bg-bg p-3 font-mono text-xs text-accent",
				children: fb.example
			}),
			(fb.got !== void 0 || fb.expected !== void 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-2 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutBlock, {
					label: "Yours",
					value: formatOutput(fb.got ?? ""),
					bad: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutBlock, {
					label: "Expected",
					value: formatOutput(fb.expected ?? "")
				})]
			})
		]
	});
}
function OutBlock({ label, value, bad }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-bg p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.12em] text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: cn("mt-1 whitespace-pre-wrap font-mono text-xs", bad ? "text-danger" : "text-success"),
			children: value
		})]
	});
}
var LEVELS_PLUS = [
	{
		id: 26,
		title: "Remainder Seal",
		job: "Legend",
		difficulty: "Medium",
		description: "The % operator is leftover after division. Even numbers leave 0.",
		objective: "Print remainders and spot an even number.",
		rewardCoins: 2800,
		rewardXp: 900,
		unlockRewardId: "remainder-seal",
		unlockReward: "Remainder Seal",
		careerUnlock: "master",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Leftover, not the quotient",
				body: "17 % 5 is 2 because 5 fits into 17 three times and 2 is left. n % 2 == 0 means n is even. The % sign is not a percentage here — it is remainder.",
				example: "print(17 % 5)  # 2\nprint(8 % 2)   # 0"
			},
			{
				type: "choice",
				concept: "even test",
				question: "Which check is True when n is even?",
				options: [
					{
						id: "a",
						label: "n % 2 == 1",
						correct: false,
						explain: "A remainder of 1 means odd: 7 % 2 is 1."
					},
					{
						id: "b",
						label: "n % 2 == 0",
						correct: true,
						explain: "Even numbers divide by 2 with nothing left."
					},
					{
						id: "c",
						label: "n / 2 == 0",
						correct: false,
						explain: "Division gives a size, not a leftover. 8 / 2 is 4, not 0."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l26-mod",
					title: "Leftover",
					concept: "% remainder",
					prompt: "Print 17 % 5, then print 8 % 2, each on its own line.",
					briefing: "Do not quote the numbers. % is math.",
					example: "print(17 % 5)",
					starter: "",
					expected: "2\n0\n",
					solution: "print(17 % 5)\nprint(8 % 2)",
					hints: [
						"print(17 % 5)",
						"print(8 % 2)",
						"Two print calls."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l26-even",
					title: "Parity stamp",
					concept: "if + %",
					prompt: "n is 14. If n is even print EVEN, otherwise print ODD.",
					briefing: "if n % 2 == 0:",
					example: "if n % 2 == 0:\n    print(\"EVEN\")",
					starter: "n = 14\n",
					expected: "EVEN\n",
					solution: "n = 14\nif n % 2 == 0:\n    print(\"EVEN\")\nelse:\n    print(\"ODD\")",
					hints: [
						"if n % 2 == 0:",
						"print(\"EVEN\")",
						"else: print(\"ODD\")"
					]
				}
			}
		]
	},
	{
		id: 27,
		title: "Power Cell",
		job: "Legend",
		difficulty: "Medium",
		description: "** raises a number. // divides and throws away the decimal.",
		objective: "Print a square and an integer division.",
		rewardCoins: 2900,
		rewardXp: 950,
		unlockRewardId: "power-cell",
		unlockReward: "Power Cell",
		careerUnlock: "master",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Two division signs",
				body: "2 ** 5 is 32. 7 / 2 is 3.5. 7 // 2 is 3 — the floor. Use // when you want a whole number of groups.",
				example: "print(2 ** 5)\nprint(7 // 2)"
			},
			{
				type: "code",
				challenge: {
					id: "l27-pow",
					title: "Square",
					concept: "**",
					prompt: "Print 6 raised to the power of 2 using **.",
					briefing: "6 ** 2 is 36, not 12.",
					example: "print(6 ** 2)",
					starter: "",
					expected: "36\n",
					solution: "print(6 ** 2)",
					hints: [
						"Use ** not *",
						"print(6 ** 2)",
						"The answer is 36."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l27-floor",
					title: "Whole groups",
					concept: "//",
					prompt: "Print 17 // 5. That is how many full groups of 5 fit into 17.",
					briefing: "// drops the leftover. 17 // 5 is 3, not 3.4.",
					example: "print(17 // 5)",
					starter: "",
					expected: "3\n",
					solution: "print(17 // 5)",
					hints: [
						"Use // not /",
						"print(17 // 5)",
						"The leftover 2 is discarded."
					]
				}
			}
		]
	},
	{
		id: 28,
		title: "Repeat Tape",
		job: "Legend",
		difficulty: "Easy / Medium",
		description: "A string times an integer repeats the text.",
		objective: "Print a repeated signal and a dashed rule.",
		rewardCoins: 3e3,
		rewardXp: 1e3,
		unlockRewardId: "repeat-tape",
		unlockReward: "Repeat Tape",
		careerUnlock: "master",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Text × number",
				body: "\"go\" * 3 is gogogo. The number must be an integer. A space string times 4 is four spaces. This is how you draw a rule without typing it by hand.",
				example: "print(\"go\" * 3)\nprint(\"-\" * 5)"
			},
			{
				type: "code",
				challenge: {
					id: "l28-go",
					title: "Call three times",
					concept: "str * int",
					prompt: "Print go repeated exactly three times, no spaces: gogogo.",
					briefing: "\"go\" * 3",
					example: "print(\"go\" * 3)",
					starter: "",
					expected: "gogogo\n",
					solution: "print(\"go\" * 3)",
					hints: [
						"\"go\" * 3",
						"No extra spaces.",
						"Wrap in print."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l28-rule",
					title: "Rule line",
					concept: "str * int",
					prompt: "Print a line of exactly 8 dashes using *.",
					briefing: "\"-\" * 8",
					example: "print(\"-\" * 8)",
					starter: "",
					expected: "--------\n",
					solution: "print(\"-\" * 8)",
					hints: [
						"\"-\" * 8",
						"Eight dashes, no spaces.",
						"print that."
					]
				}
			}
		]
	},
	{
		id: 29,
		title: "Member Pass",
		job: "Legend",
		difficulty: "Medium",
		description: "in asks whether something lives inside a string, list, or dict.",
		objective: "Test membership and print True or False.",
		rewardCoins: 3100,
		rewardXp: 1050,
		unlockRewardId: "member-pass",
		unlockReward: "Member Pass",
		careerUnlock: "legend",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Present or absent",
				body: "\"th\" in \"Python\" is True. 9 in [1, 2, 3] is False. \"name\" in user checks keys, not values. not in is the opposite.",
				example: "print(\"th\" in \"Python\")\nprint(9 not in [1, 2, 3])"
			},
			{
				type: "choice",
				concept: "in on dict",
				question: "For user = {\"name\": \"Ada\"}, what does \"Ada\" in user check?",
				options: [
					{
						id: "a",
						label: "Whether Ada is a value",
						correct: false,
						explain: "in on a dict checks keys only. The key is name, the value is Ada."
					},
					{
						id: "b",
						label: "Whether Ada is a key",
						correct: true,
						explain: "\"Ada\" in user is False because the key is \"name\"."
					},
					{
						id: "c",
						label: "Whether the dict is named Ada",
						correct: false,
						explain: "The dict is named user. in looks inside it."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l29-str",
					title: "Substring",
					concept: "in str",
					prompt: "Print whether th is inside the string Python.",
					briefing: "print(\"th\" in \"Python\") shows True.",
					example: "print(\"th\" in \"Python\")",
					starter: "",
					expected: "True\n",
					solution: "print(\"th\" in \"Python\")",
					hints: [
						"\"th\" in \"Python\"",
						"Print the comparison.",
						"True has a capital T."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l29-list",
					title: "Missing seat",
					concept: "not in",
					prompt: "Print whether 9 is not in the list [1, 2, 3].",
					briefing: "9 not in [1, 2, 3] is True.",
					example: "print(9 not in [1, 2, 3])",
					starter: "",
					expected: "True\n",
					solution: "print(9 not in [1, 2, 3])",
					hints: [
						"Use not in",
						"print(9 not in [1, 2, 3])",
						"True — 9 is missing."
					]
				}
			}
		]
	},
	{
		id: 30,
		title: "Chain Gate",
		job: "Oracle",
		difficulty: "Medium",
		description: "Python lets you write 1 < n < 10 the way math class does.",
		objective: "Print chained comparisons.",
		rewardCoins: 3200,
		rewardXp: 1100,
		unlockRewardId: "chain-gate",
		unlockReward: "Chain Gate",
		careerUnlock: "legend",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Both sides at once",
				body: "1 < n < 10 is True only if n is greater than 1 and less than 10. You do not need and. Both comparisons must hold.",
				example: "n = 7\nprint(1 < n < 10)"
			},
			{
				type: "code",
				challenge: {
					id: "l30-in",
					title: "Inside the band",
					concept: "chained compare",
					prompt: "n is 7. Print the result of 1 < n < 10.",
					briefing: "7 is between 1 and 10, so True.",
					example: "print(1 < n < 10)",
					starter: "n = 7\n",
					expected: "True\n",
					solution: "n = 7\nprint(1 < n < 10)",
					hints: [
						"print(1 < n < 10)",
						"No and needed.",
						"True."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l30-out",
					title: "Outside",
					concept: "chained compare",
					prompt: "n is 10. Print 1 < n < 10. Think carefully: is 10 less than 10?",
					briefing: "The right side is strict. 10 < 10 is False, so the chain is False.",
					example: "print(1 < n < 10)",
					starter: "n = 10\n",
					expected: "False\n",
					solution: "n = 10\nprint(1 < n < 10)",
					hints: [
						"10 is not less than 10.",
						"print(1 < n < 10)",
						"False."
					]
				}
			}
		]
	},
	{
		id: 31,
		title: "None Watch",
		job: "Oracle",
		difficulty: "Medium",
		description: "None is a real value that means “nothing here”.",
		objective: "Print None and branch when a box is empty.",
		rewardCoins: 3300,
		rewardXp: 1150,
		unlockRewardId: "none-watch",
		unlockReward: "None Watch",
		careerUnlock: "legend",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Capital N",
				body: "None is a keyword, not a string. print(None) shows None. if x is None is the usual test, but == None also works here. Do not quote it.",
				example: "x = None\nprint(x)"
			},
			{
				type: "code",
				challenge: {
					id: "l31-print",
					title: "Empty box",
					concept: "None",
					prompt: "Assign x = None, then print x.",
					briefing: "No quotes around None.",
					example: "x = None\nprint(x)",
					starter: "",
					expected: "None\n",
					solution: "x = None\nprint(x)",
					hints: [
						"x = None",
						"No quotes.",
						"print(x)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l31-if",
					title: "Missing file",
					concept: "None branch",
					prompt: "note is None. If note equals None print MISSING, otherwise print note.",
					briefing: "if note == None:",
					example: "if note == None:\n    print(\"MISSING\")",
					starter: "note = None\n",
					expected: "MISSING\n",
					solution: "note = None\nif note == None:\n    print(\"MISSING\")\nelse:\n    print(note)",
					hints: [
						"if note == None:",
						"print(\"MISSING\")",
						"else: print(note)"
					]
				}
			}
		]
	},
	{
		id: 32,
		title: "Truth Lens",
		job: "Oracle",
		difficulty: "Medium / Hard",
		description: "Empty lists and empty strings are False in an if.",
		objective: "Branch on emptiness.",
		rewardCoins: 3400,
		rewardXp: 1200,
		unlockRewardId: "truth-lens",
		unlockReward: "Truth Lens",
		careerUnlock: "legend",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Empty is False",
				body: "if box: is False when box is []. if text: is False when text is \"\". Non-empty values are True. This saves you writing len(box) > 0.",
				example: "if box:\n    print(\"full\")\nelse:\n    print(\"empty\")"
			},
			{
				type: "choice",
				concept: "truthiness",
				question: "What does if \"\": print(\"yes\") do?",
				options: [
					{
						id: "a",
						label: "Prints yes",
						correct: false,
						explain: "An empty string is False, so the block is skipped."
					},
					{
						id: "b",
						label: "Prints nothing",
						correct: true,
						explain: "Empty string is False. The print never runs."
					},
					{
						id: "c",
						label: "Crashes",
						correct: false,
						explain: "Empty strings are legal. They are just False in a condition."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l32-list",
					title: "Empty crate",
					concept: "list truthiness",
					prompt: "box is []. If box is non-empty print full, otherwise print empty.",
					briefing: "if box: else.",
					example: "if box:\n    print(\"full\")\nelse:\n    print(\"empty\")",
					starter: "box = []\n",
					expected: "empty\n",
					solution: "box = []\nif box:\n    print(\"full\")\nelse:\n    print(\"empty\")",
					hints: [
						"if box:",
						"else: print(\"empty\")",
						"[] is False."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l32-str",
					title: "Named",
					concept: "str truthiness",
					prompt: "name is Ada. If name is non-empty print READY, otherwise print WAIT.",
					briefing: "A non-empty string is True.",
					example: "if name:\n    print(\"READY\")",
					starter: "name = \"Ada\"\n",
					expected: "READY\n",
					solution: "name = \"Ada\"\nif name:\n    print(\"READY\")\nelse:\n    print(\"WAIT\")",
					hints: [
						"if name:",
						"print(\"READY\")",
						"Ada is non-empty."
					]
				}
			}
		]
	},
	{
		id: 33,
		title: "Swap File",
		job: "Sage",
		difficulty: "Medium",
		description: "replace rewrites text. find returns an index or -1.",
		objective: "Rewrite a callsign and locate a letter.",
		rewardCoins: 3500,
		rewardXp: 1250,
		unlockRewardId: "swap-file",
		unlockReward: "Swap File",
		careerUnlock: "oracle",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "New string, old unchanged",
				body: "text.replace(\"a\", \"o\") returns a new string. find returns the first index, or -1 if missing. Remember the parentheses on methods.",
				example: "print(\"cat\".replace(\"a\", \"o\"))\nprint(\"Python\".find(\"t\"))"
			},
			{
				type: "code",
				challenge: {
					id: "l33-replace",
					title: "Rewrite",
					concept: "replace",
					prompt: "Print cat with a replaced by o, so the output is cot.",
					briefing: "\"cat\".replace(\"a\", \"o\")",
					example: "print(\"cat\".replace(\"a\", \"o\"))",
					starter: "",
					expected: "cot\n",
					solution: "print(\"cat\".replace(\"a\", \"o\"))",
					hints: [
						"replace(\"a\", \"o\")",
						"Call it on \"cat\".",
						"Print the result."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l33-find",
					title: "First t",
					concept: "find",
					prompt: "Print the index of the first t in Python using find.",
					briefing: "P=0, y=1, t=2. find returns 2.",
					example: "print(\"Python\".find(\"t\"))",
					starter: "",
					expected: "2\n",
					solution: "print(\"Python\".find(\"t\"))",
					hints: [
						"\"Python\".find(\"t\")",
						"Indexes start at 0.",
						"The first t is 2."
					]
				}
			}
		]
	},
	{
		id: 34,
		title: "Prefix Badge",
		job: "Sage",
		difficulty: "Medium",
		description: "startswith and endswith check the edges of a string.",
		objective: "Print True/False for a prefix and a suffix.",
		rewardCoins: 3600,
		rewardXp: 1300,
		unlockRewardId: "prefix-badge",
		unlockReward: "Prefix Badge",
		careerUnlock: "oracle",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "Edges only",
				body: "\"hello\".startswith(\"he\") is True. \"hello\".endswith(\"HE\") is False — capitals matter. These methods return booleans, so you can print them or use them in if.",
				example: "print(\"hello\".startswith(\"he\"))\nprint(\"file.py\".endswith(\".py\"))"
			},
			{
				type: "code",
				challenge: {
					id: "l34-start",
					title: "Opens with",
					concept: "startswith",
					prompt: "Print whether hello starts with he.",
					briefing: "startswith returns True or False.",
					example: "print(\"hello\".startswith(\"he\"))",
					starter: "",
					expected: "True\n",
					solution: "print(\"hello\".startswith(\"he\"))",
					hints: [
						"\"hello\".startswith(\"he\")",
						"Print it.",
						"True."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l34-end",
					title: "Python file",
					concept: "endswith",
					prompt: "name is mission.py. Print whether it ends with .py.",
					briefing: "The dot is part of the suffix string.",
					example: "print(name.endswith(\".py\"))",
					starter: "name = \"mission.py\"\n",
					expected: "True\n",
					solution: "name = \"mission.py\"\nprint(name.endswith(\".py\"))",
					hints: [
						"name.endswith(\".py\")",
						"Include the dot.",
						"Print the boolean."
					]
				}
			}
		]
	},
	{
		id: 35,
		title: "Digit Gate",
		job: "Sage",
		difficulty: "Medium",
		description: "isdigit and isalpha classify a whole string.",
		objective: "Print whether tokens are digits or letters.",
		rewardCoins: 3700,
		rewardXp: 1350,
		unlockRewardId: "digit-gate",
		unlockReward: "Digit Gate",
		careerUnlock: "oracle",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "The whole string",
				body: "\"42\".isdigit() is True. \"4a\".isdigit() is False — every character must be a digit. isalpha is the letter version. Empty strings are False.",
				example: "print(\"42\".isdigit())\nprint(\"Ada\".isalpha())"
			},
			{
				type: "code",
				challenge: {
					id: "l35-digit",
					title: "Numeric token",
					concept: "isdigit",
					prompt: "Print whether 42 (as a string) is all digits, then whether 4a is all digits.",
					briefing: "Two lines: True then False.",
					example: "print(\"42\".isdigit())\nprint(\"4a\".isdigit())",
					starter: "",
					expected: "True\nFalse\n",
					solution: "print(\"42\".isdigit())\nprint(\"4a\".isdigit())",
					hints: [
						"\"42\".isdigit()",
						"\"4a\".isdigit()",
						"Two prints."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l35-alpha",
					title: "Letters only",
					concept: "isalpha",
					prompt: "Print whether Ada is all letters.",
					briefing: "isalpha() — parentheses required.",
					example: "print(\"Ada\".isalpha())",
					starter: "",
					expected: "True\n",
					solution: "print(\"Ada\".isalpha())",
					hints: [
						"\"Ada\".isalpha()",
						"Do not forget ().",
						"True."
					]
				}
			}
		]
	},
	{
		id: 36,
		title: "Pop Stack",
		job: "Director",
		difficulty: "Medium / Hard",
		description: "pop removes and returns. insert places an item at an index.",
		objective: "Pop the last seat, then insert at the front.",
		rewardCoins: 3800,
		rewardXp: 1400,
		unlockRewardId: "pop-stack",
		unlockReward: "Pop Stack",
		careerUnlock: "oracle",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "Take and place",
				body: "team.pop() removes the last item and returns it — you can print that return. insert(0, x) puts x at the front. Both change the list in place.",
				example: "print(team.pop())\nteam.insert(0, \"Ada\")"
			},
			{
				type: "code",
				challenge: {
					id: "l36-pop",
					title: "Last out",
					concept: "pop",
					prompt: "team is Ada, Lin, Kai. Pop the last name and print what pop returns. Then print the list.",
					briefing: "Two prints: Kai then the remaining list.",
					example: "print(team.pop())\nprint(team)",
					starter: "team = [\"Ada\", \"Lin\", \"Kai\"]\n",
					expected: "Kai\n['Ada', 'Lin']\n",
					solution: "team = [\"Ada\", \"Lin\", \"Kai\"]\nprint(team.pop())\nprint(team)",
					hints: [
						"print(team.pop())",
						"Then print(team)",
						"Kai comes off the end."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l36-insert",
					title: "Front of line",
					concept: "insert",
					prompt: "queue is Lin, Kai. Insert Ada at index 0, then print the list.",
					briefing: "queue.insert(0, \"Ada\")",
					example: "queue.insert(0, \"Ada\")\nprint(queue)",
					starter: "queue = [\"Lin\", \"Kai\"]\n",
					expected: "['Ada', 'Lin', 'Kai']\n",
					solution: "queue = [\"Lin\", \"Kai\"]\nqueue.insert(0, \"Ada\")\nprint(queue)",
					hints: [
						"insert(0, \"Ada\")",
						"Index 0 is the front.",
						"print(queue) after."
					]
				}
			}
		]
	},
	{
		id: 37,
		title: "Mutate Rack",
		job: "Director",
		difficulty: "Medium / Hard",
		description: "sort and reverse change the list. They return None.",
		objective: "Sort in place, then reverse in place.",
		rewardCoins: 3900,
		rewardXp: 1450,
		unlockRewardId: "mutate-rack",
		unlockReward: "Mutate Rack",
		careerUnlock: "sage",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "In place vs sorted",
				body: "nums.sort() changes nums and returns None. sorted(nums) returns a new list. reverse() flips the current order. Print the list after you mutate it, not the method call.",
				example: "nums.sort()\nprint(nums)"
			},
			{
				type: "choice",
				concept: "sort return",
				question: "What does print(nums.sort()) show?",
				options: [
					{
						id: "a",
						label: "The sorted list",
						correct: false,
						explain: "sort returns None. Print nums afterwards."
					},
					{
						id: "b",
						label: "None",
						correct: true,
						explain: "Mutating methods return None. The list changed silently."
					},
					{
						id: "c",
						label: "An error",
						correct: false,
						explain: "It is legal — just not useful to print."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l37-sort",
					title: "Order in place",
					concept: "sort",
					prompt: "nums is [5, 1, 4]. Sort it in place, then print nums.",
					briefing: "nums.sort() then print(nums).",
					example: "nums.sort()\nprint(nums)",
					starter: "nums = [5, 1, 4]\n",
					expected: "[1, 4, 5]\n",
					solution: "nums = [5, 1, 4]\nnums.sort()\nprint(nums)",
					hints: [
						"nums.sort()",
						"Do not print the call.",
						"print(nums)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l37-rev",
					title: "Flip",
					concept: "reverse",
					prompt: "items is [1, 2, 3]. Reverse it in place, then print the list.",
					briefing: "items.reverse()",
					example: "items.reverse()\nprint(items)",
					starter: "items = [1, 2, 3]\n",
					expected: "[3, 2, 1]\n",
					solution: "items = [1, 2, 3]\nitems.reverse()\nprint(items)",
					hints: [
						"items.reverse()",
						"Then print(items)",
						"[3, 2, 1]"
					]
				}
			}
		]
	},
	{
		id: 38,
		title: "Count Desk",
		job: "Director",
		difficulty: "Medium",
		description: "count tells you how many times a value appears.",
		objective: "Count in a list and in a string.",
		rewardCoins: 4e3,
		rewardXp: 1500,
		unlockRewardId: "count-desk",
		unlockReward: "Count Desk",
		careerUnlock: "sage",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "How many",
				body: "[1, 2, 1, 1].count(1) is 3. \"banana\".count(\"a\") is 3. Missing values count as 0, they do not crash.",
				example: "print(nums.count(1))\nprint(\"banana\".count(\"a\"))"
			},
			{
				type: "code",
				challenge: {
					id: "l38-list",
					title: "Ones",
					concept: "list.count",
					prompt: "nums is [1, 2, 1, 1]. Print how many times 1 appears.",
					briefing: "nums.count(1)",
					example: "print(nums.count(1))",
					starter: "nums = [1, 2, 1, 1]\n",
					expected: "3\n",
					solution: "nums = [1, 2, 1, 1]\nprint(nums.count(1))",
					hints: [
						"nums.count(1)",
						"Print that.",
						"The answer is 3."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l38-str",
					title: "Letter a",
					concept: "str.count",
					prompt: "Print how many times a appears in banana.",
					briefing: "\"banana\".count(\"a\")",
					example: "print(\"banana\".count(\"a\"))",
					starter: "",
					expected: "3\n",
					solution: "print(\"banana\".count(\"a\"))",
					hints: [
						"\"banana\".count(\"a\")",
						"Three a's.",
						"Print the number."
					]
				}
			}
		]
	},
	{
		id: 39,
		title: "Enum Walk",
		job: "Sage",
		difficulty: "Hard",
		description: "enumerate gives you the index and the item together.",
		objective: "Print each index, then each item.",
		rewardCoins: 4200,
		rewardXp: 1600,
		unlockRewardId: "enum-walk",
		unlockReward: "Enum Walk",
		careerUnlock: "sage",
		chapter: "fluency",
		steps: [{
			type: "brief",
			title: "Two names on the for line",
			body: "for i, x in enumerate(items): unpacks each pair. i is 0, 1, 2… x is the value. You need both names, a comma, and enumerate around the list.",
			example: "for i, x in enumerate([\"a\", \"b\"]):\n    print(i)\n    print(x)"
		}, {
			type: "code",
			challenge: {
				id: "l39-enum",
				title: "Numbered seats",
				concept: "enumerate",
				prompt: "Loop enumerate([\"a\", \"b\"]) as i, x. Print i then x, each on its own line.",
				briefing: "Four lines: 0, a, 1, b.",
				example: "for i, x in enumerate([\"a\", \"b\"]):\n    print(i)\n    print(x)",
				starter: "",
				expected: "0\na\n1\nb\n",
				solution: "for i, x in enumerate([\"a\", \"b\"]):\n    print(i)\n    print(x)",
				hints: [
					"for i, x in enumerate([\"a\", \"b\"]):",
					"print(i)",
					"print(x)"
				]
			}
		}]
	},
	{
		id: 40,
		title: "Pair Unpack",
		job: "Director",
		difficulty: "Hard",
		description: "items() yields (key, value) pairs you can unpack.",
		objective: "Walk a dict printing each key then each value.",
		rewardCoins: 4300,
		rewardXp: 1650,
		unlockRewardId: "pair-unpack",
		unlockReward: "Pair Unpack",
		careerUnlock: "sage",
		chapter: "fluency",
		steps: [{
			type: "brief",
			title: "Two names, one pair",
			body: "for k, v in scores.items(): sets k to the key and v to the value. Insertion order is Ada then Kai.",
			example: "for k, v in scores.items():\n    print(k)\n    print(v)"
		}, {
			type: "code",
			challenge: {
				id: "l40-items",
				title: "Open the pairs",
				concept: "dict.items",
				prompt: "scores maps Ada to 90 and Kai to 70. Unpack items as k, v. Print k then v, each on its own line.",
				briefing: "Four lines: Ada, 90, Kai, 70.",
				example: "for k, v in scores.items():\n    print(k)\n    print(v)",
				starter: "scores = {\"Ada\": 90, \"Kai\": 70}\n",
				expected: "Ada\n90\nKai\n70\n",
				solution: "scores = {\"Ada\": 90, \"Kai\": 70}\nfor k, v in scores.items():\n    print(k)\n    print(v)",
				hints: [
					"for k, v in scores.items():",
					"print(k)",
					"print(v)"
				]
			}
		}]
	},
	{
		id: 41,
		title: "Grid Key",
		job: "Director",
		difficulty: "Hard",
		description: "A list of lists is a grid. Two indexes: row, then column.",
		objective: "Read a cell, then overwrite one.",
		rewardCoins: 4400,
		rewardXp: 1700,
		unlockRewardId: "grid-key",
		unlockReward: "Grid Key",
		careerUnlock: "director",
		chapter: "studio",
		steps: [
			{
				type: "brief",
				title: "Row then column",
				body: "grid[1][0] is row 1, column 0. Both indexes start at 0. You can assign grid[0][1] = 9 to replace a cell.",
				example: "grid = [[1, 2], [3, 4]]\nprint(grid[1][0])"
			},
			{
				type: "code",
				challenge: {
					id: "l41-read",
					title: "Lower left",
					concept: "nested list",
					prompt: "grid is [[1, 2], [3, 4]]. Print the value at row 1, column 0.",
					briefing: "That cell is 3.",
					example: "print(grid[1][0])",
					starter: "grid = [[1, 2], [3, 4]]\n",
					expected: "3\n",
					solution: "grid = [[1, 2], [3, 4]]\nprint(grid[1][0])",
					hints: [
						"grid[1][0]",
						"Row 1 is [3, 4].",
						"Column 0 is 3."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l41-write",
					title: "Overwrite a cell",
					concept: "nested assign",
					prompt: "Set grid[0][1] to 9, then print the whole grid.",
					briefing: "grid[0][1] = 9 mutates the inner list.",
					example: "grid[0][1] = 9\nprint(grid)",
					starter: "grid = [[1, 2], [3, 4]]\n",
					expected: "[[1, 9], [3, 4]]\n",
					solution: "grid = [[1, 2], [3, 4]]\ngrid[0][1] = 9\nprint(grid)",
					hints: [
						"grid[0][1] = 9",
						"print(grid)",
						"The 2 becomes 9."
					]
				}
			}
		]
	},
	{
		id: 42,
		title: "Nested Vault",
		job: "Director",
		difficulty: "Hard",
		description: "A dictionary can hold another dictionary as a value.",
		objective: "Read a nested field, then update one.",
		rewardCoins: 4500,
		rewardXp: 1750,
		unlockRewardId: "nested-vault",
		unlockReward: "Nested Vault",
		careerUnlock: "director",
		chapter: "studio",
		steps: [
			{
				type: "brief",
				title: "Two keys in a row",
				body: "desk[\"Ada\"][\"role\"] walks into Ada's record, then reads role. You can assign desk[\"Ada\"][\"role\"] = \"lead\" to update.",
				example: "print(desk[\"Ada\"][\"role\"])"
			},
			{
				type: "code",
				challenge: {
					id: "l42-read",
					title: "Inner field",
					concept: "nested dict",
					prompt: "Print Ada's role from the nested desk record.",
					briefing: "desk[\"Ada\"][\"role\"]",
					example: "print(desk[\"Ada\"][\"role\"])",
					starter: "desk = {\"Ada\": {\"role\": \"lead\", \"score\": 90}, \"Lin\": {\"role\": \"dev\", \"score\": 70}}\n",
					expected: "lead\n",
					solution: "desk = {\"Ada\": {\"role\": \"lead\", \"score\": 90}, \"Lin\": {\"role\": \"dev\", \"score\": 70}}\nprint(desk[\"Ada\"][\"role\"])",
					hints: [
						"desk[\"Ada\"]",
						"then [\"role\"]",
						"print that."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l42-write",
					title: "Promote Ada",
					concept: "nested assign",
					prompt: "Set Ada's role to director, then print that role.",
					briefing: "desk[\"Ada\"][\"role\"] = \"director\"",
					example: "desk[\"Ada\"][\"role\"] = \"director\"\nprint(desk[\"Ada\"][\"role\"])",
					starter: "desk = {\"Ada\": {\"role\": \"lead\", \"score\": 90}}\n",
					expected: "director\n",
					solution: "desk = {\"Ada\": {\"role\": \"lead\", \"score\": 90}}\ndesk[\"Ada\"][\"role\"] = \"director\"\nprint(desk[\"Ada\"][\"role\"])",
					hints: [
						"desk[\"Ada\"][\"role\"] = \"director\"",
						"Then print it.",
						"Match lowercase director."
					]
				}
			}
		]
	},
	{
		id: 43,
		title: "Step Rail",
		job: "Grandmaster",
		difficulty: "Medium / Hard",
		description: "range can take a step so it skips numbers.",
		objective: "Print even numbers using range with a step.",
		rewardCoins: 4600,
		rewardXp: 1800,
		unlockRewardId: "step-rail",
		unlockReward: "Step Rail",
		careerUnlock: "director",
		chapter: "studio",
		timeLimitSec: 70,
		steps: [
			{
				type: "brief",
				title: "Three arguments",
				body: "range(start, stop, step). range(0, 8, 2) is 0, 2, 4, 6 — stop is still excluded. Negative steps count down.",
				example: "for i in range(0, 8, 2):\n    print(i)"
			},
			{
				type: "code",
				challenge: {
					id: "l43-evens",
					title: "Skip by two",
					concept: "range step",
					prompt: "Print 0, 2, 4, 6 using range with a step of 2. Stop before 8.",
					briefing: "range(0, 8, 2)",
					example: "for i in range(0, 8, 2):\n    print(i)",
					starter: "",
					expected: "0\n2\n4\n6\n",
					solution: "for i in range(0, 8, 2):\n    print(i)",
					hints: [
						"range(0, 8, 2)",
						"Stop is 8, last printed is 6.",
						"for i in ...: print(i)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l43-down",
					title: "Count down",
					concept: "negative step",
					prompt: "Print 5, 4, 3, 2, 1 using range with a negative step. Stop before 0.",
					briefing: "range(5, 0, -1)",
					example: "for i in range(5, 0, -1):\n    print(i)",
					starter: "",
					expected: "5\n4\n3\n2\n1\n",
					solution: "for i in range(5, 0, -1):\n    print(i)",
					hints: [
						"range(5, 0, -1)",
						"0 is the stop, not printed.",
						"print(i) in the loop."
					]
				}
			}
		]
	},
	{
		id: 44,
		title: "Mirror Glass",
		job: "Grandmaster",
		difficulty: "Medium / Hard",
		description: "[::-1] reverses a string or a list.",
		objective: "Mirror a word and a list.",
		rewardCoins: 4700,
		rewardXp: 1850,
		unlockRewardId: "mirror-glass",
		unlockReward: "Mirror Glass",
		careerUnlock: "director",
		chapter: "studio",
		steps: [
			{
				type: "brief",
				title: "Step of -1",
				body: "\"Python\"[::-1] is nohtyP. [1, 2, 3][::-1] is [3, 2, 1]. The empty start and end mean “the whole thing”, walking backwards.",
				example: "print(\"Python\"[::-1])\nprint([1, 2, 3][::-1])"
			},
			{
				type: "code",
				challenge: {
					id: "l44-str",
					title: "Mirror the name",
					concept: "reverse slice",
					prompt: "Print Python reversed with a slice.",
					briefing: "[::-1] on the string.",
					example: "print(\"Python\"[::-1])",
					starter: "",
					expected: "nohtyP\n",
					solution: "print(\"Python\"[::-1])",
					hints: [
						"\"Python\"[::-1]",
						"Capitals stay on the same letters.",
						"P ends up last."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l44-list",
					title: "Flip the list",
					concept: "reverse slice",
					prompt: "Print [1, 2, 3] reversed with a slice. Do not use reverse().",
					briefing: "[1, 2, 3][::-1] returns a new list.",
					example: "print([1, 2, 3][::-1])",
					starter: "",
					expected: "[3, 2, 1]\n",
					solution: "print([1, 2, 3][::-1])",
					hints: [
						"[::-1]",
						"Print the slice.",
						"[3, 2, 1]"
					]
				}
			}
		]
	},
	{
		id: 45,
		title: "Accum Forge",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "Start with empty text. Add a piece each time the loop runs.",
		objective: "Build a joined string without using join().",
		rewardCoins: 4800,
		rewardXp: 1900,
		unlockRewardId: "accum-forge",
		unlockReward: "Accum Forge",
		careerUnlock: "director",
		chapter: "studio",
		steps: [{
			type: "brief",
			title: "The running box",
			body: "out = \"\" then out = out + x builds a longer string. A space goes in as its own piece if you want gaps. Print once after the loop.",
			example: "out = \"\"\nfor w in words:\n    out = out + w\nprint(out)"
		}, {
			type: "code",
			challenge: {
				id: "l45-glue",
				title: "Smash together",
				concept: "accumulator",
				prompt: "words is go, team. Start out as empty. Add each word onto out. Print out once after the loop. Result: goteam",
				briefing: "No spaces. Concatenate in the loop, print after.",
				example: "out = \"\"\nfor w in words:\n    out = out + w\nprint(out)",
				starter: "words = [\"go\", \"team\"]\n",
				expected: "goteam\n",
				solution: "words = [\"go\", \"team\"]\nout = \"\"\nfor w in words:\n    out = out + w\nprint(out)",
				hints: [
					"out = \"\"",
					"out = out + w",
					"print(out) after the loop"
				]
			}
		}]
	},
	{
		id: 46,
		title: "Helper Link",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "One function can call another. Small tools stack.",
		objective: "Write double, then twice, and print twice(5).",
		rewardCoins: 5e3,
		rewardXp: 2e3,
		unlockRewardId: "helper-link",
		unlockReward: "Helper Link",
		careerUnlock: "grandmaster",
		chapter: "studio",
		steps: [{
			type: "brief",
			title: "Call down the stack",
			body: "twice(n) can return double(n) + double(n), or simply 2 * double(n). Define double first so twice can see it.",
			example: "def double(n):\n    return n * 2\ndef twice(n):\n    return double(n) + double(n)"
		}, {
			type: "code",
			challenge: {
				id: "l46-link",
				title: "Stacked tools",
				concept: "function calls function",
				prompt: "Write double(n) that returns n * 2. Write twice(n) that returns double(n) + double(n). Print twice(5).",
				briefing: "5 doubled is 10. 10 + 10 is 20.",
				example: "def double(n):\n    return n * 2",
				starter: "def double(n):\n    return n\n",
				expected: "20\n",
				solution: "def double(n):\n    return n * 2\ndef twice(n):\n    return double(n) + double(n)\nprint(twice(5))",
				hints: [
					"return n * 2",
					"twice returns double(n) + double(n)",
					"print(twice(5))"
				]
			}
		}]
	},
	{
		id: 47,
		title: "Studio Report",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "A function reads a roster and writes one labeled line.",
		objective: "Write line(name, score) and print two reports.",
		rewardCoins: 5200,
		rewardXp: 2100,
		unlockRewardId: "studio-report",
		unlockReward: "Studio Report",
		careerUnlock: "grandmaster",
		chapter: "studio",
		steps: [{
			type: "brief",
			title: "One shape, many calls",
			body: "line(name, score) returns name + \": \" + str(score). Convert the number. Call it twice to print two people.",
			example: "def line(name, score):\n    return name + \": \" + str(score)"
		}, {
			type: "code",
			challenge: {
				id: "l47-line",
				title: "Two badges",
				concept: "format helper",
				prompt: "Write line(name, score) that returns name, then \": \", then the score as text. Print line(\"Ada\", 90) and line(\"Kai\", 70).",
				briefing: "Two lines of output. Space after the colon.",
				example: "print(line(\"Ada\", 90))",
				starter: "def line(name, score):\n    return name\n",
				expected: "Ada: 90\nKai: 70\n",
				solution: "def line(name, score):\n    return name + \": \" + str(score)\nprint(line(\"Ada\", 90))\nprint(line(\"Kai\", 70))",
				hints: [
					"str(score)",
					"\": \" has a colon and a space",
					"Print both calls."
				]
			}
		}]
	},
	{
		id: 48,
		title: "Even Filter",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "Walk a list. Print only the even numbers.",
		objective: "Filter with % before the clock hits zero.",
		rewardCoins: 5400,
		rewardXp: 2200,
		unlockRewardId: "even-filter",
		unlockReward: "Even Filter",
		careerUnlock: "grandmaster",
		chapter: "studio",
		timeLimitSec: 80,
		steps: [{
			type: "brief",
			title: "Keep the evens",
			body: "for n in nums: if n % 2 == 0: print(n). Indent twice. Odds are skipped, not deleted.",
			example: "for n in nums:\n    if n % 2 == 0:\n        print(n)"
		}, {
			type: "code",
			challenge: {
				id: "l48-even",
				title: "Evens only",
				concept: "filter loop",
				prompt: "nums is [1, 4, 7, 8, 3, 10]. Print only the even numbers, each on its own line, in order.",
				briefing: "4, 8, 10.",
				example: "for n in nums:\n    if n % 2 == 0:\n        print(n)",
				starter: "nums = [1, 4, 7, 8, 3, 10]\n",
				expected: "4\n8\n10\n",
				solution: "nums = [1, 4, 7, 8, 3, 10]\nfor n in nums:\n    if n % 2 == 0:\n        print(n)",
				hints: [
					"for n in nums:",
					"if n % 2 == 0:",
					"print(n)"
				]
			}
		}]
	},
	{
		id: 49,
		title: "Default Key",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "get(key, fallback) returns the fallback instead of crashing.",
		objective: "Look up a missing city with a default.",
		rewardCoins: 5600,
		rewardXp: 2300,
		unlockRewardId: "default-key",
		unlockReward: "Default Key",
		careerUnlock: "grandmaster",
		chapter: "studio",
		steps: [{
			type: "brief",
			title: "The second argument",
			body: "user.get(\"city\", \"unknown\") returns unknown when city is missing. user[\"city\"] would raise KeyError. Use get when the key might not exist.",
			example: "print(user.get(\"city\", \"unknown\"))"
		}, {
			type: "code",
			challenge: {
				id: "l49-get",
				title: "Fallback city",
				concept: "get default",
				prompt: "user has a name but no city. Print user.get(\"city\", \"unknown\"), then print user.get(\"name\", \"unknown\").",
				briefing: "Missing city → unknown. Present name → Ada.",
				example: "print(user.get(\"city\", \"unknown\"))",
				starter: "user = {\"name\": \"Ada\"}\n",
				expected: "unknown\nAda\n",
				solution: "user = {\"name\": \"Ada\"}\nprint(user.get(\"city\", \"unknown\"))\nprint(user.get(\"name\", \"unknown\"))",
				hints: [
					"get(\"city\", \"unknown\")",
					"get(\"name\", \"unknown\")",
					"Two prints."
				]
			}
		}]
	},
	{
		id: 50,
		title: "Grandmaster Championship",
		job: "Grandmaster",
		difficulty: "Expert",
		description: "Grandmaster checkpoint. Helpers, filters, nested records — under the clock. The course continues after this.",
		objective: "Clear every stage. Claim the Grandmaster Crown. Then keep climbing.",
		rewardCoins: 12e3,
		rewardXp: 4e3,
		unlockRewardId: "grandmaster-crown",
		unlockReward: "Grandmaster Crown",
		careerUnlock: "grandmaster",
		chapter: "studio",
		timeLimitSec: 200,
		championship: true,
		steps: [
			{
				type: "brief",
				title: "The whole career",
				body: "Stage 1: a helper that classifies. Stage 2: walk nested scores. Stage 3: write a labeled report from a list. Same laws: colons, indents, quotes, print.",
				example: "def stamp(n):\n    if n % 2 == 0:\n        return \"EVEN\"\n    return \"ODD\""
			},
			{
				type: "code",
				challenge: {
					id: "l50-stamp",
					title: "Stage 1 — Stamp",
					concept: "function + %",
					prompt: "Write stamp(n) that returns EVEN if n is even, else ODD. Print stamp(8) then stamp(7).",
					briefing: "Two lines: EVEN then ODD.",
					example: "print(stamp(8))\nprint(stamp(7))",
					starter: "def stamp(n):\n    return n\n",
					expected: "EVEN\nODD\n",
					solution: "def stamp(n):\n    if n % 2 == 0:\n        return \"EVEN\"\n    return \"ODD\"\nprint(stamp(8))\nprint(stamp(7))",
					hints: [
						"if n % 2 == 0: return \"EVEN\"",
						"return \"ODD\"",
						"Print both calls."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l50-nested",
					title: "Stage 2 — Nested scores",
					concept: "nested dict + if",
					prompt: "desk maps names to records with a score. Print each name whose score is at least 80, in dictionary order.",
					briefing: "Ada 90 and Kai 88 pass. Lin 70 does not. Read desk[name][\"score\"].",
					example: "for name in desk:\n    if desk[name][\"score\"] >= 80:\n        print(name)",
					starter: "desk = {\"Ada\": {\"score\": 90}, \"Lin\": {\"score\": 70}, \"Kai\": {\"score\": 88}}\n",
					expected: "Ada\nKai\n",
					solution: "desk = {\"Ada\": {\"score\": 90}, \"Lin\": {\"score\": 70}, \"Kai\": {\"score\": 88}}\nfor name in desk:\n    if desk[name][\"score\"] >= 80:\n        print(name)",
					hints: [
						"for name in desk:",
						"if desk[name][\"score\"] >= 80:",
						"print(name)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l50-report",
					title: "Stage 3 — Final report",
					concept: "helpers + builtins",
					prompt: "Write report(nums) that returns max= then the max, then a space, then even= then how many even numbers. Print report([1, 4, 8, 3]).",
					briefing: "max is 8. Evens are 4 and 8, so even=2. Shape: max=8 even=2",
					example: "return \"max=\" + str(max(nums)) + \" even=\" + str(c)",
					starter: "def report(nums):\n    return \"\"\n",
					expected: "max=8 even=2\n",
					solution: "def report(nums):\n    c = 0\n    for n in nums:\n        if n % 2 == 0:\n            c += 1\n    return \"max=\" + str(max(nums)) + \" even=\" + str(c)\nprint(report([1, 4, 8, 3]))",
					hints: [
						"Count evens with % 2 == 0",
						"str(max(nums)) and str(c)",
						"print(report([1, 4, 8, 3]))"
					]
				}
			}
		]
	}
];
function brief(title, body, example) {
	return example ? {
		type: "brief",
		title,
		body,
		example
	} : {
		type: "brief",
		title,
		body
	};
}
function choice(concept, question, a, ae, b, be, c, ce, correct) {
	return {
		type: "choice",
		concept,
		question,
		options: [
			{
				id: "a",
				label: a,
				correct: correct === "a",
				explain: ae
			},
			{
				id: "b",
				label: b,
				correct: correct === "b",
				explain: be
			},
			{
				id: "c",
				label: c,
				correct: correct === "c",
				explain: ce
			}
		]
	};
}
function code(id, title, concept, prompt, briefing, example, starter, expected, solution, hints) {
	return {
		type: "code",
		challenge: {
			id,
			title,
			concept,
			prompt,
			briefing,
			example,
			starter,
			expected,
			solution,
			hints
		}
	};
}
function lv(id, title, job, difficulty, description, objective, coins, xp, unlockRewardId, unlockReward, careerUnlock, chapter, steps, extra) {
	return {
		id,
		title,
		job,
		difficulty,
		description,
		objective,
		rewardCoins: coins,
		rewardXp: xp,
		unlockRewardId,
		unlockReward,
		careerUnlock,
		chapter,
		...extra,
		steps
	};
}
var LEVELS_PRO = [
	lv(51, "Zip Rail", "Virtuoso", "Medium", "zip walks two lists together: first with first, second with second.", "Pair names with scores and print each pair.", 3e3, 1e3, "zip-rail", "Zip Rail", "virtuoso", "patterns", [
		brief("Two lists, one walk", "zip(names, scores) hands you a pair on each step. Unpack: for n, s in zip(names, scores):. It stops at the shorter list.", "for n, s in zip([\"Ada\", \"Lin\"], [90, 70]):\n    print(n)\n    print(s)"),
		choice("zip length", "zip([1, 2, 3], [\"a\", \"b\"]) makes how many pairs?", "3", "zip stops when the shortest list ends. The extra 3 is ignored.", "2", "Two pairs: (1, a) and (2, b). The leftover 3 is dropped.", "5", "zip does not concatenate. It pairs by position.", "b"),
		code("l51-zip", "Lockstep", "zip", "names is Ada, Lin. scores is 90, 70. For each pair, print the name then the score.", "Use zip and unpack two names in the for line.", "for n, s in zip(names, scores):", "names = [\"Ada\", \"Lin\"]\nscores = [90, 70]\n", "Ada\n90\nLin\n70\n", "names = [\"Ada\", \"Lin\"]\nscores = [90, 70]\nfor n, s in zip(names, scores):\n    print(n)\n    print(s)", [
			"for n, s in zip(names, scores):",
			"print(n) then print(s)",
			"Do not add extra text."
		])
	]),
	lv(52, "Truth Bulk", "Virtuoso", "Medium", "any(list) is True if at least one item is true. all(list) needs every item true.", "Print any and all for the given lists.", 3100, 1050, "truth-bulk", "Truth Bulk", "virtuoso", "patterns", [
		brief("One question for the whole list", "0, \"\", [], None are false. any([0, 0, 1]) is True because 1 is true. all([1, 0, 3]) is False because 0 is false. all([]) is True — there is no liar.", "print(any([0, 1]))  # True\nprint(all([1, 2]))  # True"),
		choice("any vs all", "What does any([0, 0, 0]) print?", "True", "Every item is 0, which is false, so any is False.", "False", "No item is true, so any is False.", "0", "any always returns True or False, not a number.", "b"),
		code("l52-any", "Bulk truth", "any / all", "Print any([0, 0, 1]), then all([1, 2, 3]), then all([1, 0, 3]).", "Three prints. True, True, False.", "print(any([0, 0, 1]))", "", "True\nTrue\nFalse\n", "print(any([0, 0, 1]))\nprint(all([1, 2, 3]))\nprint(all([1, 0, 3]))", [
			"any([0, 0, 1])",
			"all([1, 2, 3])",
			"all([1, 0, 3]) is False because of 0"
		])
	]),
	lv(53, "Round Dial", "Virtuoso", "Medium", "round(n) nearest integer. float(\"2.5\") turns text into a decimal number.", "Round 3.7 and convert the string 2.5.", 3200, 1100, "round-dial", "Round Dial", "virtuoso", "patterns", [
		brief("Nearby integer, numeric text", "round(3.7) is 4. round(3.2) is 3. float(\"2.5\") is the number 2.5 — not a string. int() would drop the decimal; float keeps it.", "print(round(3.7))\nprint(float(\"2.5\"))"),
		choice("float vs int", "What does int(\"3.0\") do in this course interpreter?", "Returns 3", "int() truncates a numeric string that Number() can read. \"3.0\" becomes 3.", "Crashes", "This teaching interpreter accepts numeric strings. Real CPython int(\"3.0\") does fail — here float is the safe conversion for decimals.", "Returns 3.0", "int() never keeps a decimal. float() would.", "a"),
		code("l53-round", "Nearby", "round / float", "Print round(3.7), then print float(\"2.5\").", "First line 4. Second line 2.5.", "print(round(3.7))", "", "4\n2.5\n", "print(round(3.7))\nprint(float(\"2.5\"))", [
			"round(3.7)",
			"float(\"2.5\")",
			"Two print calls."
		])
	]),
	lv(54, "Bool Gate", "Virtuoso", "Medium", "bool(x) names the truth of a value. Non-empty lists are True even if they hold 0.", "Print bool of empty string, \"ok\", empty list, and [0].", 3300, 1150, "bool-gate", "Bool Gate", "virtuoso", "patterns", [
		brief("Name the truth", "bool(\"\") is False. bool(\"ok\") is True. bool([]) is False. bool([0]) is True — the list is not empty. The 0 inside does not make the list false.", "print(bool([0]))  # True"),
		choice("non-empty list", "Why is bool([0]) True?", "0 is true", "0 is false. The list is true because it has an item.", "The list has a length of 1", "A non-empty list is true, even if the item inside is 0 or False.", "Lists are always true", "Empty lists are false. bool([]) is False.", "b"),
		code("l54-bool", "Name it", "bool()", "Print bool(\"\"), bool(\"ok\"), bool([]), bool([0]) — each on its own line.", "False, True, False, True.", "print(bool(\"\"))", "", "False\nTrue\nFalse\nTrue\n", "print(bool(\"\"))\nprint(bool(\"ok\"))\nprint(bool([]))\nprint(bool([0]))", [
			"Four print(bool(...)) calls",
			"[0] is a non-empty list",
			"Empty string is False"
		])
	]),
	lv(55, "None Identity", "Artisan", "Medium", "is checks identity. Use x is None, not x == None, when you mean “no value”.", "Test a missing value with is and is not.", 3400, 1200, "none-is", "None Identity", "artisan", "patterns", [
		brief("The value that means no value", "None is a singleton. x is None is True only when x really is None. 0 is not None. \"\" is not None. is not is the opposite.", "x = None\nprint(x is None)      # True\nprint(x is not None)  # False"),
		choice("is vs ==", "Which check is the Python style for “this is missing”?", "x == None", "It often works, but style (and this course) wants is, because None is one object.", "x is None", "Identity. There is only one None.", "x = None", "That assigns, it does not test.", "b"),
		code("l55-is", "Identity", "is None", "x is None. Print x is None, then x is not None, then (0 is None).", "True, False, False.", "print(x is None)", "x = None\n", "True\nFalse\nFalse\n", "x = None\nprint(x is None)\nprint(x is not None)\nprint(0 is None)", [
			"x is None",
			"x is not None",
			"0 is None is False"
		])
	]),
	lv(56, "Ternary Key", "Artisan", "Medium", "value_if_true if condition else value_if_false — a one-line choice that returns a value.", "Stamp even/odd with a ternary.", 3500, 1250, "ternary-key", "Ternary Key", "artisan", "patterns", [
		brief("If that returns", "\"even\" if n % 2 == 0 else \"odd\" picks a string. It is an expression — you can print it or return it. The condition sits in the middle.", "print(\"yes\" if n > 0 else \"no\")"),
		choice("ternary order", "In a if cond else b, when is a used?", "When cond is false", "False takes the else branch — b.", "When cond is true", "The value before if is the True result.", "Always", "Only one side runs.", "b"),
		code("l56-tern", "One-line stamp", "ternary", "Print \"even\" if 8 is even else \"odd\". Then the same for 7.", "even then odd. Use n % 2 == 0 in the middle.", "print(\"even\" if n % 2 == 0 else \"odd\")", "", "even\nodd\n", "print(\"even\" if 8 % 2 == 0 else \"odd\")\nprint(\"even\" if 7 % 2 == 0 else \"odd\")", [
			"\"even\" if 8 % 2 == 0 else \"odd\"",
			"Second line uses 7",
			"Two prints"
		])
	]),
	lv(57, "Swap Hands", "Artisan", "Medium", "a, b = b, a swaps two boxes in one line. Python evaluates the right side first.", "Swap 3 and 9, then print both.", 3600, 1300, "swap-hands", "Swap Hands", "artisan", "patterns", [
		brief("No third box", "In many languages you need t = a; a = b; b = t. Python lets you write a, b = b, a. The right side is packed, then unpacked into the left names.", "a = 3\nb = 9\na, b = b, a\nprint(a)  # 9"),
		choice("evaluation order", "After a, b = b, a, what happened to the original a?", "It is lost forever", "It moved into b. Nothing is lost.", "It is now in b", "Right side is (old b, old a). Then a gets old b, b gets old a.", "It stays in a", "That would not be a swap.", "b"),
		code("l57-swap", "Hands", "unpack assign", "a is 3, b is 9. Swap them with one assignment. Print a, then b.", "9 then 3.", "a, b = b, a", "a = 3\nb = 9\n", "9\n3\n", "a = 3\nb = 9\na, b = b, a\nprint(a)\nprint(b)", [
			"a, b = b, a",
			"print(a)",
			"print(b)"
		])
	]),
	lv(58, "Repeat Rack", "Artisan", "Medium", "A list times a number repeats the items. [0] * 4 is four zeros.", "Build a repeated list and a repeated word list.", 3700, 1350, "repeat-rack", "Repeat Rack", "artisan", "patterns", [
		brief("Fill the rack", "[0] * 4 → [0, 0, 0, 0]. [\"go\"] * 3 → ['go', 'go', 'go']. This is a new list. Changing one slot later does not rewrite the multiplier.", "print([0] * 4)"),
		choice("repeat vs append", "What is [1, 2] * 2?", "[2, 4]", "That would be multiplying items. * on a list repeats the list.", "[1, 2, 1, 2]", "The whole list is laid down twice.", "[1, 2, 2]", "It does not append only the last item.", "b"),
		code("l58-rep", "Rack", "list * n", "Print [0] * 4, then print [\"go\"] * 3.", "[0, 0, 0, 0] then ['go', 'go', 'go'].", "print([0] * 4)", "", "[0, 0, 0, 0]\n['go', 'go', 'go']\n", "print([0] * 4)\nprint([\"go\"] * 3)", [
			"[0] * 4",
			"[\"go\"] * 3",
			"Two prints"
		])
	]),
	lv(59, "Reverse Walk", "Artisan", "Medium", "reversed(items) walks backwards. The original list stays in order.", "Print 3, 2, 1 from [1, 2, 3] without mutating it.", 3800, 1400, "reverse-walk", "Reverse Walk", "artisan", "patterns", [
		brief("Backwards, copy", "list.reverse() flips the list in place and returns None. reversed(items) leaves items alone and lets you for-loop from the end. This course’s reversed() hands you a list.", "for n in reversed([1, 2, 3]):\n    print(n)"),
		choice("reverse vs reversed", "After xs = [1, 2]; xs.reverse(), what is xs?", "[1, 2]", "reverse() mutates. xs is now [2, 1].", "[2, 1]", "In-place flip.", "None", "reverse() returns None, but xs itself is the flipped list.", "b"),
		code("l59-rev", "Walk back", "reversed", "For each n in reversed([1, 2, 3]), print n.", "3 then 2 then 1.", "for n in reversed([1, 2, 3]):", "", "3\n2\n1\n", "for n in reversed([1, 2, 3]):\n    print(n)", [
			"for n in reversed([1, 2, 3]):",
			"print(n)",
			"Do not call .reverse()"
		])
	]),
	lv(60, "Fizz Seal", "Artisan", "Medium / Hard", "The classic remainder song. % 3 Fizz, % 5 Buzz, both FizzBuzz, else the number.", "Print FizzBuzz for 1 through 15.", 4e3, 1500, "fizz-seal", "Fizz Seal", "artisan", "patterns", [
		brief("Test the double first", "If you check % 3 before % 15, 15 would print Fizz and skip Buzz. Check n % 15 == 0 (or both) first, then 3, then 5, else the number. range(1, 16) is 1..15.", "if n % 15 == 0:\n    print(\"FizzBuzz\")"),
		choice("order", "Why check 15 before 3?", "15 is bigger", "Size is not the reason. 15 is divisible by 3, so the 3-branch would steal it.", "15 is also divisible by 3, so the Fizz branch would catch it first", "The more specific case must come first.", "15 is divisible by 5 only", "15 is divisible by both 3 and 5.", "b"),
		code("l60-fizz", "The song", "FizzBuzz", "For n from 1 to 15 inclusive: print FizzBuzz if divisible by 15, Fizz by 3, Buzz by 5, else n.", "Fifteen lines. 15 must be FizzBuzz, not Fizz.", "for n in range(1, 16):", "", "1\n2\nFizz\n4\nBuzz\nFizz\n7\n8\nFizz\nBuzz\n11\nFizz\n13\n14\nFizzBuzz\n", "for n in range(1, 16):\n    if n % 15 == 0:\n        print(\"FizzBuzz\")\n    elif n % 3 == 0:\n        print(\"Fizz\")\n    elif n % 5 == 0:\n        print(\"Buzz\")\n    else:\n        print(n)", [
			"range(1, 16)",
			"if n % 15 == 0 first",
			"elif % 3, elif % 5, else n"
		])
	]),
	lv(61, "Clamp Band", "Artisan", "Medium", "A clamp keeps a number inside [lo, hi]. Below lo → lo. Above hi → hi.", "Write clamp and print three cases.", 4100, 1550, "clamp-band", "Clamp Band", "artisan", "patterns", [
		brief("Stay in the band", "clamp(-2, 0, 10) is 0. clamp(4, 0, 10) is 4. clamp(99, 0, 10) is 10. Two ifs, or a nested min/max. Write the ifs so you see the rule.", "if n < lo:\n    return lo"),
		choice("inclusive", "clamp(0, 0, 10) should return?", "lo - 1", "0 is already on the edge, and edges are allowed.", "0", "The band includes both ends.", "10", "That would be the high end. 0 is the low end.", "b"),
		code("l61-clamp", "Band", "clamp", "Write clamp(n, lo, hi). Print clamp(-2, 0, 10), clamp(4, 0, 10), clamp(99, 0, 10).", "0, 4, 10.", "def clamp(n, lo, hi):", "def clamp(n, lo, hi):\n    return n\n", "0\n4\n10\n", "def clamp(n, lo, hi):\n    if n < lo:\n        return lo\n    if n > hi:\n        return hi\n    return n\nprint(clamp(-2, 0, 10))\nprint(clamp(4, 0, 10))\nprint(clamp(99, 0, 10))", [
			"if n < lo: return lo",
			"if n > hi: return hi",
			"Print three calls"
		])
	]),
	lv(62, "Mirror Test", "Artisan", "Medium", "A palindrome equals its reverse. s == s[::-1].", "Write pal(s) and test level vs python.", 4200, 1600, "mirror-test", "Mirror Test", "artisan", "patterns", [
		brief("Same forwards and back", "\"level\" reversed is \"level\". \"python\" reversed is \"nohtyp\". Return the comparison — True or False — do not print inside the function.", "return s == s[::-1]"),
		choice("slice reverse", "What does \"ab\"[::-1] equal?", "\"ab\"", "Step -1 flips it to ba.", "\"ba\"", "[::-1] walks the string backwards.", "\"\"", "A missing start/end still covers the whole string.", "b"),
		code("l62-pal", "Mirror", "palindrome", "Write pal(s) that returns True when s equals its reverse. Print pal(\"level\") then pal(\"python\").", "True then False.", "def pal(s):\n    return s == s[::-1]", "def pal(s):\n    return False\n", "True\nFalse\n", "def pal(s):\n    return s == s[::-1]\nprint(pal(\"level\"))\nprint(pal(\"python\"))", [
			"s == s[::-1]",
			"print(pal(\"level\"))",
			"print(pal(\"python\"))"
		])
	]),
	lv(63, "Fact Forge", "Titan", "Medium / Hard", "Factorial n! is 1*2*...*n. An accumulator starts at 1 and multiplies.", "Write fact and print fact(5) and fact(1).", 4300, 1650, "fact-forge", "Fact Forge", "titan", "craft", [
		brief("Multiply down the range", "Start p = 1. for i in range(1, n + 1): p *= i. fact(5) is 120. fact(1) is 1. fact(0) would also be 1 — the loop never runs.", "p = 1\nfor i in range(1, n + 1):\n    p *= i"),
		choice("start at 1", "Why start the product at 1, not 0?", "Style", "0 times anything stays 0. The answer would always be 0.", "0 * k is always 0, so the result would be stuck at 0", "1 is the identity for multiplication.", "range starts at 1", "That is a separate reason. The accumulator still needs 1.", "b"),
		code("l63-fact", "Forge", "factorial", "Write fact(n) that returns n!. Print fact(5) then fact(1).", "120 then 1.", "def fact(n):\n    p = 1\n    for i in range(1, n + 1):\n        p *= i\n    return p", "def fact(n):\n    return n\n", "120\n1\n", "def fact(n):\n    p = 1\n    for i in range(1, n + 1):\n        p *= i\n    return p\nprint(fact(5))\nprint(fact(1))", [
			"p = 1",
			"for i in range(1, n + 1): p *= i",
			"Print both calls"
		])
	]),
	lv(64, "Fib Spiral", "Titan", "Hard", "Fibonacci: 0, 1, 1, 2, 3, 5, 8, 13. Each term is the two before it, added. Swap walks it.", "Write fib(n) as the nth term (fib(0)=0). Print fib(6) and fib(7).", 4400, 1700, "fib-spiral", "Fib Spiral", "titan", "craft", [
		brief("Two hands walking", "a, b = 0, 1. Repeat n times: a, b = b, a + b. After n steps, a is fib(n). fib(6) is 8. fib(7) is 13.", "a, b = 0, 1\nfor i in range(n):\n    a, b = b, a + b\nreturn a"),
		choice("fib 0", "What is fib(0)?", "1", "The sequence starts at 0.", "0", "Zeroth term is 0. First is 1.", "2", "That is later in the sequence.", "b"),
		code("l64-fib", "Spiral", "fibonacci", "Write fib(n) where fib(0) is 0 and fib(1) is 1. Print fib(6) then fib(7).", "8 then 13.", "a, b = b, a + b", "def fib(n):\n    return n\n", "8\n13\n", "def fib(n):\n    a, b = 0, 1\n    for i in range(n):\n        a, b = b, a + b\n    return a\nprint(fib(6))\nprint(fib(7))", [
			"a, b = 0, 1",
			"a, b = b, a + b  n times",
			"return a"
		])
	]),
	lv(65, "Digit Well", "Titan", "Medium / Hard", "% 10 peels the last digit. // 10 drops it. Loop until the number is 0.", "Sum the digits of 409.", 4500, 1750, "digit-well", "Digit Well", "titan", "craft", [
		brief("Peel from the right", "409 % 10 is 9. 409 // 10 is 40. 40 % 10 is 0. 40 // 10 is 4. 4 % 10 is 4. Sum 9+0+4 = 13.", "while n > 0:\n    s += n % 10\n    n = n // 10"),
		choice("peel", "What is 27 % 10?", "2", "2 is 27 // 10, the leftover tens.", "7", "Remainder when dividing by 10 is the last digit.", "0", "27 is not a multiple of 10.", "b"),
		code("l65-digits", "Well", "digit sum", "Write digits(n) that returns the sum of decimal digits. Print digits(409).", "13.", "s += n % 10", "def digits(n):\n    return n\n", "13\n", "def digits(n):\n    s = 0\n    while n > 0:\n        s += n % 10\n        n = n // 10\n    return s\nprint(digits(409))", [
			"while n > 0:",
			"s += n % 10",
			"n = n // 10"
		])
	]),
	lv(66, "Vowel Net", "Titan", "Medium", "Count letters that sit in \"aeiou\". Membership does the test.", "Count vowels in jarvis.", 4600, 1800, "vowel-net", "Vowel Net", "titan", "craft", [
		brief("A tiny membership net", "for ch in s: if ch in \"aeiou\": c += 1. \"jarvis\" has a and i — 2. This version is case-sensitive; lower first if you need both cases.", "if ch in \"aeiou\":\n    c += 1"),
		choice("membership", "Does \"y\" count as a vowel in this mission?", "Yes", "The net is aeiou only.", "No — the string is aeiou", "Keep the rule small and exact.", "Only at the end", "Position does not matter.", "b"),
		code("l66-vow", "Net", "vowel count", "Write vowels(s) that counts a, e, i, o, u. Print vowels(\"jarvis\").", "2.", "if ch in \"aeiou\":", "def vowels(s):\n    return 0\n", "2\n", "def vowels(s):\n    c = 0\n    for ch in s:\n        if ch in \"aeiou\":\n            c += 1\n    return c\nprint(vowels(\"jarvis\"))", [
			"for ch in s:",
			"if ch in \"aeiou\":",
			"c += 1"
		])
	]),
	lv(67, "Search Pin", "Titan", "Medium / Hard", "Linear search: walk until you find the target, return the index. Miss → -1.", "Find Lin and miss Mo in a three-name list.", 4700, 1850, "search-pin", "Search Pin", "titan", "craft", [
		brief("Walk with a counter", "i = 0. for x in items: if x == target: return i. Then i += 1. After the loop, return -1. First match wins.", "for i, x in enumerate(items):\n    if x == target:\n        return i\nreturn -1"),
		choice("miss", "Why return -1 when missing?", "Indexes start at -1", "Indexes start at 0. -1 is a signal, not a position you would print as found.", "It cannot be a real index in a normal list", "Callers can test found < 0.", "Python requires it", "It is a convention, like str.find.", "b"),
		code("l67-find", "Pin", "linear search", "Write find(items, target) returning the first index or -1. Print find([\"Ada\", \"Lin\", \"Kai\"], \"Lin\") then find(..., \"Mo\").", "1 then -1.", "return -1", "def find(items, target):\n    return 0\n", "1\n-1\n", "def find(items, target):\n    i = 0\n    for x in items:\n        if x == target:\n            return i\n        i += 1\n    return -1\nprint(find([\"Ada\", \"Lin\", \"Kai\"], \"Lin\"))\nprint(find([\"Ada\", \"Lin\", \"Kai\"], \"Mo\"))", [
			"Walk with i",
			"return i when equal",
			"return -1 after the loop"
		])
	]),
	lv(68, "Unique Press", "Titan", "Medium / Hard", "Keep the first of each value. Drop later repeats. Order stays.", "Press [1, 2, 2, 3, 1, 4] into unique items.", 4800, 1900, "unique-press", "Unique Press", "titan", "craft", [
		brief("Seen before?", "out starts empty. for x in items: if x not in out: out.append(x). First 1 stays. Second 1 is skipped. This is O(n²) and fine for mission-size lists.", "if x not in out:\n    out.append(x)"),
		choice("order", "Unique of [2, 1, 2] is?", "[1, 2]", "That would sort. We keep first-seen order: 2 then 1.", "[2, 1]", "First 2, then 1. The later 2 is dropped.", "[2, 1, 2]", "That is not unique.", "b"),
		code("l68-uniq", "Press", "dedup", "From items [1, 2, 2, 3, 1, 4], build a new list with first-seen uniques and print it.", "[1, 2, 3, 4]", "if x not in out:\n    out.append(x)", "items = [1, 2, 2, 3, 1, 4]\n", "[1, 2, 3, 4]\n", "items = [1, 2, 2, 3, 1, 4]\nout = []\nfor x in items:\n    if x not in out:\n        out.append(x)\nprint(out)", [
			"out = []",
			"if x not in out",
			"print(out)"
		])
	]),
	lv(69, "Flat Grid", "Titan", "Medium", "A list of lists becomes one list. Nested for. append each inner item.", "Flatten [[1, 2], [3, 4], [5]].", 4900, 1950, "flat-grid", "Flat Grid", "titan", "craft", [
		brief("Rows then cells", "for row in grid: for x in row: out.append(x). Uneven rows are fine — the inner loop just runs fewer times.", "for row in grid:\n    for x in row:\n        out.append(x)"),
		choice("append row", "What if you append(row) instead of each x?", "Same result", "You would nest lists inside out.", "out would be a list of lists still", "Flatten means items, not rows.", "Error", "append accepts a list. It just would not flatten.", "b"),
		code("l69-flat", "Flatten", "nested lists", "Flatten grid = [[1, 2], [3, 4], [5]] into one list and print it.", "[1, 2, 3, 4, 5]", "for row in grid:\n    for x in row:", "grid = [[1, 2], [3, 4], [5]]\n", "[1, 2, 3, 4, 5]\n", "grid = [[1, 2], [3, 4], [5]]\nout = []\nfor row in grid:\n    for x in row:\n        out.append(x)\nprint(out)", [
			"out = []",
			"nested for",
			"out.append(x)"
		])
	]),
	lv(70, "Min Hand", "Titan", "Medium", "Find the smallest with a loop. No min(). Start from the first item.", "Smallest of [9, 2, 7, 2, 5].", 5e3, 2e3, "min-hand", "Min Hand", "titan", "craft", [
		brief("Champion challenger", "m = nums[0]. for n in nums: if n < m: m = n. Ties keep the old champion. Empty lists are out of scope — you need a first item.", "m = nums[0]\nfor n in nums:\n    if n < m:\n        m = n"),
		choice("start", "Why not start m at 0?", "0 is always smallest", "If every number is positive, 0 would win even though it is not in the list.", "0 might not be in the list, and might be smaller than every real item", "Start from an actual item.", "Indexes start at 0", "Different 0.", "b"),
		code("l70-min", "Hand", "min loop", "Write smallest(nums) without calling min. Print smallest([9, 2, 7, 2, 5]).", "2.", "if n < m:\n    m = n", "def smallest(nums):\n    return nums[0]\n", "2\n", "def smallest(nums):\n    m = nums[0]\n    for n in nums:\n        if n < m:\n            m = n\n    return m\nprint(smallest([9, 2, 7, 2, 5]))", [
			"m = nums[0]",
			"if n < m: m = n",
			"Do not use min()"
		])
	]),
	lv(71, "Run Total", "Titan", "Medium", "Print the sum after every add. A running total, not just the final number.", "Running total of [5, 10, 3].", 5100, 2050, "run-total", "Run Total", "titan", "craft", [
		brief("After every step", "total = 0. for n in nums: total += n; print(total). For [5, 10, 3] you should see 5, then 15, then 18 — three lines, not one.", "total += n\nprint(total)"),
		choice("print place", "If you print only after the loop, what do you see?", "The running total", "You would only see the last sum.", "Only the final sum", "Print belongs inside the loop.", "Nothing", "You would still see one number if you print after.", "b"),
		code("l71-run", "Running", "accumulator print", "Starting at 0, add each of [5, 10, 3] and print the total after each add.", "5, 15, 18.", "total += n\nprint(total)", "nums = [5, 10, 3]\n", "5\n15\n18\n", "nums = [5, 10, 3]\ntotal = 0\nfor n in nums:\n    total += n\n    print(total)", [
			"total = 0",
			"total += n",
			"print inside the loop"
		])
	]),
	lv(72, "Prime Gate", "Titan", "Hard", "A prime is greater than 1 and has no divisor from 2 through sqrt(n).", "Test 7, 9, and 2.", 5200, 2100, "prime-gate", "Prime Gate", "titan", "craft", [
		brief("Trial division", "n < 2 → False. i from 2 while i * i <= n: if n % i == 0: return False; i += 1. Then True. 2 is prime. 9 fails at i = 3.", "while i * i <= n:\n    if n % i == 0:\n        return False\n    i += 1"),
		choice("two", "Is 2 prime?", "No, it is even", "2 is the even prime. The loop i*i <= 2 never finds a divisor.", "Yes", "Only divisible by 1 and 2.", "Only odd numbers are prime", "2 is the exception that proves the rule about other evens.", "b"),
		code("l72-prime", "Gate", "prime", "Write prime(n) returning True/False. Print prime(7), prime(9), prime(2).", "True, False, True.", "while i * i <= n:", "def prime(n):\n    return True\n", "True\nFalse\nTrue\n", "def prime(n):\n    if n < 2:\n        return False\n    i = 2\n    while i * i <= n:\n        if n % i == 0:\n            return False\n        i += 1\n    return True\nprint(prime(7))\nprint(prime(9))\nprint(prime(2))", [
			"n < 2 → False",
			"test i from 2 while i * i <= n",
			"Print three calls"
		])
	]),
	lv(73, "GCD Lock", "Titan", "Hard", "Euclid: while b is not 0, a, b = b, a % b. Then a is the greatest common divisor.", "gcd(48, 18) and gcd(7, 3).", 5300, 2150, "gcd-lock", "GCD Lock", "titan", "craft", [
		brief("Remainders shrink", "48, 18 → 18, 12 → 12, 6 → 6, 0. Stop. Answer 6. gcd(7, 3) is 1 — they share no larger factor. Swap with a, b = b, a % b.", "while b != 0:\n    a, b = b, a % b\nreturn a"),
		choice("stop", "When the remainder is 0, why is a the GCD?", "a is always 1", "gcd can be larger than 1. 6 in the 48, 18 example.", "b now divides a exactly, and Euclid proved that remainder chain shares the GCD", "The last non-zero remainder is the GCD.", "You guessed", "It is a theorem, not a guess — but you only need the loop here.", "b"),
		code("l73-gcd", "Lock", "gcd", "Write gcd(a, b) with Euclid’s remainder loop. Print gcd(48, 18) then gcd(7, 3).", "6 then 1.", "a, b = b, a % b", "def gcd(a, b):\n    return a\n", "6\n1\n", "def gcd(a, b):\n    while b != 0:\n        a, b = b, a % b\n    return a\nprint(gcd(48, 18))\nprint(gcd(7, 3))", [
			"while b != 0:",
			"a, b = b, a % b",
			"return a"
		])
	]),
	lv(74, "Leap Dial", "Titan", "Medium / Hard", "Leap year: divisible by 400, or by 4 but not by 100. 2000 yes, 1900 no, 2024 yes.", "Write leap(y) for those three years.", 5400, 2200, "leap-dial", "Leap Dial", "titan", "craft", [
		brief("Calendar remainders", "if y % 400 == 0: True. if y % 100 == 0: False. return y % 4 == 0. Order matters: 2000 is a 400-year, 1900 is a century that is not.", "if y % 400 == 0:\n    return True\nif y % 100 == 0:\n    return False"),
		choice("1900", "Why is 1900 not a leap year?", "It is odd", "1900 is even. The century rule drops it.", "It is divisible by 100 but not by 400", "Centuries need 400.", "2024 is the only leap year", "Many years leap. 2000 does.", "b"),
		code("l74-leap", "Dial", "leap year", "Write leap(y). Print leap(2000), leap(1900), leap(2024).", "True, False, True.", "if y % 400 == 0:\n    return True", "def leap(y):\n    return y % 4 == 0\n", "True\nFalse\nTrue\n", "def leap(y):\n    if y % 400 == 0:\n        return True\n    if y % 100 == 0:\n        return False\n    return y % 4 == 0\nprint(leap(2000))\nprint(leap(1900))\nprint(leap(2024))", [
			"400 first",
			"then 100 → False",
			"else % 4 == 0"
		])
	]),
	lv(75, "Sovereign Championship", "Sovereign", "Expert", "Craft championship. Stamp, flatten-unique, digit sum — under the clock.", "Clear every stage. Claim the Sovereign Seal.", 14e3, 4500, "sovereign-seal", "Sovereign Seal", "sovereign", "craft", [
		brief("Three tools, one clock", "Stage 1: remainder stamp. Stage 2: flatten then unique. Stage 3: digit sum. Same laws: colon, indent, return.", "def stamp(n):\n    if n % 3 == 0:\n        return \"Fizz\"\n    return str(n)"),
		code("l75-stamp", "Stage 1 — Stamp", "remainder stamp", "Write stamp(n): Fizz if n % 3 == 0 else the number as text. Print stamp(3), stamp(5), stamp(6).", "Fizz, 5, Fizz.", "return str(n)", "def stamp(n):\n    return n\n", "Fizz\n5\nFizz\n", "def stamp(n):\n    if n % 3 == 0:\n        return \"Fizz\"\n    return str(n)\nprint(stamp(3))\nprint(stamp(5))\nprint(stamp(6))", [
			"if n % 3 == 0: return \"Fizz\"",
			"return str(n)",
			"Print three calls"
		]),
		code("l75-flat", "Stage 2 — Flatten unique", "flatten + unique", "Flatten [[1, 1], [2, 1], [3]] then keep first-seen uniques. Print the result.", "[1, 2, 3]", "if x not in out:\n    out.append(x)", "grid = [[1, 1], [2, 1], [3]]\n", "[1, 2, 3]\n", "grid = [[1, 1], [2, 1], [3]]\nout = []\nfor row in grid:\n    for x in row:\n        if x not in out:\n            out.append(x)\nprint(out)", [
			"nested for",
			"if x not in out",
			"print(out)"
		]),
		code("l75-digits", "Stage 3 — Digit sum", "digit sum", "Write digits(n) summing decimal digits. Print digits(1234).", "10.", "s += n % 10", "def digits(n):\n    return n\n", "10\n", "def digits(n):\n    s = 0\n    while n > 0:\n        s += n % 10\n        n = n // 10\n    return s\nprint(digits(1234))", [
			"while n > 0",
			"% 10 and // 10",
			"print(digits(1234))"
		])
	], {
		timeLimitSec: 180,
		championship: true
	}),
	lv(76, "Collatz Path", "Sovereign", "Hard", "Even → n//2. Odd → 3n+1. Count steps until 1. The hailstone path.", "How many steps from 6 to 1?", 5500, 2250, "collatz-path", "Collatz Path", "sovereign", "craft", [
		brief("Hailstones", "6 → 3 → 10 → 5 → 16 → 8 → 4 → 2 → 1. That is 8 steps. Count the arrows, not the starting 6. Stop when n == 1. Do not count a step at 1.", "while n != 1:\n    if n % 2 == 0:\n        n = n // 2\n    else:\n        n = 3 * n + 1\n    c += 1"),
		choice("count", "From 2 to 1, how many steps?", "2", "2 is even → 1. One step.", "1", "A single halving.", "0", "You start at 2, not 1.", "b"),
		code("l76-col", "Path", "Collatz", "Write steps(n) counting Collatz steps to 1. Print steps(6).", "8.", "n = n // 2", "def steps(n):\n    return n\n", "8\n", "def steps(n):\n    c = 0\n    while n != 1:\n        if n % 2 == 0:\n            n = n // 2\n        else:\n            n = 3 * n + 1\n        c += 1\n    return c\nprint(steps(6))", [
			"while n != 1:",
			"even: n // 2  odd: 3*n+1",
			"c += 1 each round"
		])
	]),
	lv(77, "Power Loop", "Sovereign", "Medium / Hard", "Raise a base without **. Multiply in a counted loop.", "2 to the 8th is 256.", 5600, 2300, "power-loop", "Power Loop", "sovereign", "craft", [
		brief("Multiply e times", "p = 1. Repeat e times: p *= b. power(2, 8) is 256. power(anything, 0) is 1 because the loop does not run.", "p = 1\nfor i in range(e):\n    p *= b"),
		choice("zero exp", "power(5, 0) should be?", "0", "The empty product is 1.", "1", "No multiplications. Identity 1.", "5", "That would be exponent 1.", "b"),
		code("l77-pow", "Loop power", "power by loop", "Write power(b, e) without **. Print power(2, 8).", "256.", "p *= b", "def power(b, e):\n    return b\n", "256\n", "def power(b, e):\n    p = 1\n    for i in range(e):\n        p *= b\n    return p\nprint(power(2, 8))", [
			"p = 1",
			"for i in range(e): p *= b",
			"Do not use **"
		])
	]),
	lv(78, "Odd Bin", "Sovereign", "Medium", "Build a new list of odds. Do not mutate the original.", "Odds from [4, 7, 2, 9, 8].", 5700, 2350, "odd-bin", "Odd Bin", "sovereign", "craft", [
		brief("Filter into a new box", "odds = []. for n in nums: if n % 2 != 0: odds.append(n). The original nums stays [4, 7, 2, 9, 8].", "if n % 2 != 0:\n    odds.append(n)"),
		choice("new list", "Why not nums.remove odds in place?", "remove while looping skips items", "Mutating a list you are walking is a classic bug. Build a new list.", "remove is illegal", "It exists — it is just the wrong tool here.", "Odds cannot be removed", "They can. Prefer a fresh list.", "a"),
		code("l78-odd", "Bin", "filter odds", "From nums = [4, 7, 2, 9, 8], print a new list of the odd numbers in order.", "[7, 9]", "if n % 2 != 0:", "nums = [4, 7, 2, 9, 8]\n", "[7, 9]\n", "nums = [4, 7, 2, 9, 8]\nodds = []\nfor n in nums:\n    if n % 2 != 0:\n        odds.append(n)\nprint(odds)", [
			"odds = []",
			"n % 2 != 0",
			"print(odds)"
		])
	]),
	lv(79, "Word Span", "Sovereign", "Easy / Medium", "len of every word. A loop over a list of strings.", "Print lengths of code, a, python.", 5800, 2400, "word-span", "Word Span", "sovereign", "craft", [
		brief("Measure each token", "for w in words: print(len(w)). \"code\" is 4, \"a\" is 1, \"python\" is 6. Do not print the words themselves.", "print(len(w))"),
		choice("len string", "len(\"a\") is?", "0", "One character.", "1", "A single letter has length 1.", "97", "That would be ord, not len.", "b"),
		code("l79-len", "Span", "len words", "For each word in [\"code\", \"a\", \"python\"], print its length.", "4, 1, 6.", "print(len(w))", "words = [\"code\", \"a\", \"python\"]\n", "4\n1\n6\n", "words = [\"code\", \"a\", \"python\"]\nfor w in words:\n    print(len(w))", [
			"for w in words:",
			"print(len(w))",
			"Three lines"
		])
	]),
	lv(80, "Title Press", "Sovereign", "Medium", "Chain methods: strip then title. Spaces off, words capitalized.", "Clean \"  hello world  \".", 5900, 2450, "title-press", "Title Press", "sovereign", "craft", [
		brief("Two methods, one expression", "raw.strip().title() first trims, then capitalizes each word. Order matters: title() would keep the spaces, strip after still works, but the taught press is strip then title.", "print(raw.strip().title())"),
		choice("order", "What does \"  hi\".title() start with?", "H immediately", "title does not strip. It would start with spaces, then Hi.", "spaces, then Hi", "Strip first if you want Hi at the left edge.", "error", "title accepts leading spaces.", "b"),
		code("l80-title", "Press", "strip + title", "raw is \"  hello world  \". Print raw.strip().title().", "Hello World", "print(raw.strip().title())", "raw = \"  hello world  \"\n", "Hello World\n", "raw = \"  hello world  \"\nprint(raw.strip().title())", [
			"strip() first",
			".title()",
			"One print"
		])
	]),
	lv(81, "Ord Key", "Sentinel", "Medium", "ord(\"A\") is 65. chr(66) is B. Letters are numbers underneath.", "Print ord of A and chr of 66.", 6e3, 2500, "ord-key", "Ord Key", "sentinel", "legend", [
		brief("The number of a letter", "Unicode code points. For basic English, they match ASCII. ord needs a string of length 1. chr maps the other way. \"A\" + 1 is a TypeError — use ord/chr to shift.", "print(ord(\"A\"))\nprint(chr(66))"),
		choice("shift", "How do you get the letter after ch?", "ch + 1", "str + int is a TypeError. Convert with ord, add, chr.", "chr(ord(ch) + 1)", "Number, add, back to letter.", "ch.next()", "No such method here.", "b"),
		code("l81-ord", "Key", "ord / chr", "Print ord(\"A\"), then chr(66).", "65 then B.", "print(ord(\"A\"))", "", "65\nB\n", "print(ord(\"A\"))\nprint(chr(66))", [
			"ord(\"A\")",
			"chr(66)",
			"Two prints"
		])
	]),
	lv(82, "Caesar Shift", "Sentinel", "Hard", "Move every letter one place forward with chr(ord(ch) + 1). A tiny cipher.", "Shift abc to bcd.", 6100, 2550, "caesar-shift", "Caesar Shift", "sentinel", "legend", [
		brief("One step on the alphabet", "Build a new string. for ch in s: out += chr(ord(ch) + 1). \"abc\" → \"bcd\". This version does not wrap Z → A. Keep the mission small.", "out += chr(ord(ch) + 1)"),
		choice("immutable", "Why not s[0] = \"b\"?", "Indexes start at 1", "Strings cannot be assigned at an index. They are immutable.", "Strings cannot be changed in place", "Build a new string with += or join.", "ord would fail", "ord is fine. Assignment is the problem.", "b"),
		code("l82-cae", "Shift", "caesar +1", "Write shift(s) that moves every character one code point forward. Print shift(\"abc\").", "bcd", "out += chr(ord(ch) + 1)", "def shift(s):\n    return s\n", "bcd\n", "def shift(s):\n    out = \"\"\n    for ch in s:\n        out += chr(ord(ch) + 1)\n    return out\nprint(shift(\"abc\"))", [
			"out = \"\"",
			"chr(ord(ch) + 1)",
			"print(shift(\"abc\"))"
		])
	]),
	lv(83, "Case Gate", "Sentinel", "Medium", "isupper, islower, isspace classify a character. Empty strings are False.", "Stamp U, S, L for \"A z\".", 6200, 2600, "case-gate", "Case Gate", "sentinel", "legend", [
		brief("Three gates", "Walk \"A z\". A is upper → U. space is space → S. z is lower → L. elif chain so a letter is not also called space.", "if ch.isupper():\n    print(\"U\")\nelif ch.islower():\n    print(\"L\")"),
		choice("space", "Does \" \".isalpha() pass?", "Yes", "Space is not a letter. isspace is the test.", "No", "isalpha needs A–Z or a–z.", "Only in Python 2", "Same rule in Python 3.", "b"),
		code("l83-case", "Classify", "isupper/islower/isspace", "For each character in \"A z\": print U if upper, S if space, L if lower.", "U, S, L on three lines.", "if ch.isupper():", "text = \"A z\"\n", "U\nS\nL\n", "text = \"A z\"\nfor ch in text:\n    if ch.isupper():\n        print(\"U\")\n    elif ch.isspace():\n        print(\"S\")\n    elif ch.islower():\n        print(\"L\")", [
			"for ch in text:",
			"isupper / isspace / islower",
			"Print U, S, L"
		])
	]),
	lv(84, "Freq Table", "Sentinel", "Hard", "A dictionary of counts. If the key exists, add 1. Else plant 1.", "Count letters in aba.", 6300, 2650, "freq-table", "Freq Table", "sentinel", "legend", [
		brief("Tally by key", "freq = {}. for ch in text: if ch in freq: freq[ch] = freq[ch] + 1 else: freq[ch] = 1. \"aba\" → a:2, b:1. Then print the two lookups.", "if ch in freq:\n    freq[ch] = freq[ch] + 1\nelse:\n    freq[ch] = 1"),
		choice("missing key", "What if you write freq[ch] = freq[ch] + 1 on a new letter?", "It starts at 1", "KeyError. The key is not there yet.", "KeyError", "Plant the first 1 in the else branch, or use setdefault.", "It stays 0", "There is no 0 until you put one.", "b"),
		code("l84-freq", "Tally", "frequency dict", "Count characters in \"aba\". Print freq[\"a\"] then freq[\"b\"].", "2 then 1.", "freq[ch] = freq[ch] + 1", "text = \"aba\"\n", "2\n1\n", "text = \"aba\"\nfreq = {}\nfor ch in text:\n    if ch in freq:\n        freq[ch] = freq[ch] + 1\n    else:\n        freq[ch] = 1\nprint(freq[\"a\"])\nprint(freq[\"b\"])", [
			"freq = {}",
			"if ch in freq",
			"print freq of a and b"
		])
	]),
	lv(85, "Anagram Seal", "Sentinel", "Medium / Hard", "Same letters, new order. sorted(a) == sorted(b).", "listen/silent vs cat/car.", 6400, 2700, "anagram-seal", "Anagram Seal", "sentinel", "legend", [
		brief("Sort and compare", "sorted(\"listen\") and sorted(\"silent\") are the same list of letters. Length can differ — sorted then catches that too. This ignores meaning, only letters.", "return sorted(a) == sorted(b)"),
		choice("length", "Are \"aa\" and \"a\" anagrams?", "Yes, same letters", "Counts must match. sorted differs in length.", "No — counts differ", "Anagrams are rearrangements, not subsets.", "Only if sorted", "sorted would not be equal.", "b"),
		code("l85-ana", "Seal", "anagram", "Write ana(a, b) True when sorted letters match. Print ana(\"listen\", \"silent\") then ana(\"cat\", \"car\").", "True then False.", "return sorted(a) == sorted(b)", "def ana(a, b):\n    return a == b\n", "True\nFalse\n", "def ana(a, b):\n    return sorted(a) == sorted(b)\nprint(ana(\"listen\", \"silent\"))\nprint(ana(\"cat\", \"car\"))", [
			"sorted(a) == sorted(b)",
			"print both calls",
			"Do not compare a == b raw"
		])
	]),
	lv(86, "Merge Unique", "Sentinel", "Medium / Hard", "Concatenate two lists, then keep first-seen uniques.", "Merge [1, 2, 3] with [3, 4].", 6500, 2750, "merge-unique", "Merge Unique", "sentinel", "legend", [
		brief("Plus, then press", "a + b concatenates. Then the unique press from earlier. [1, 2, 3] + [3, 4] → drop the second 3 → [1, 2, 3, 4].", "for x in a + b:\n    if x not in out:\n        out.append(x)"),
		choice("plus lists", "[1, 2] + [2] equals?", "[1, 2]", "Plus concatenates, it does not unique. [1, 2, 2].", "[1, 2, 2]", "Then you unique in a second step.", "[3]", "That would add items.", "b"),
		code("l86-merge", "Merge", "concat + unique", "Merge a = [1, 2, 3] and b = [3, 4] into a unique list in first-seen order. Print it.", "[1, 2, 3, 4]", "for x in a + b:", "a = [1, 2, 3]\nb = [3, 4]\n", "[1, 2, 3, 4]\n", "a = [1, 2, 3]\nb = [3, 4]\nout = []\nfor x in a + b:\n    if x not in out:\n        out.append(x)\nprint(out)", [
			"a + b",
			"if x not in out",
			"print(out)"
		])
	]),
	lv(87, "Stock Ledger", "Sentinel", "Medium", "Add to an existing key. Create a missing one. Inventory math.", "Add 3 pens and stock a new mug.", 6600, 2800, "stock-ledger", "Stock Ledger", "sentinel", "legend", [
		brief("Read, add, write", "stock[\"pen\"] = stock[\"pen\"] + 3. A new item is just stock[\"mug\"] = 1. Reading a missing key is KeyError — create it instead.", "stock[\"pen\"] = stock[\"pen\"] + 3\nstock[\"mug\"] = 1"),
		choice("missing", "stock[\"mug\"] + 1 when mug is missing?", "Creates mug", "KeyError on the read.", "KeyError", "Assign a first value when the key is new.", "0", "No implicit zero.", "b"),
		code("l87-stock", "Ledger", "dict update values", "stock starts {\"pen\": 2}. Add 3 pens. Set mug to 1. Print pen then mug.", "5 then 1.", "stock[\"pen\"] = stock[\"pen\"] + 3", "stock = {\"pen\": 2}\n", "5\n1\n", "stock = {\"pen\": 2}\nstock[\"pen\"] = stock[\"pen\"] + 3\nstock[\"mug\"] = 1\nprint(stock[\"pen\"])\nprint(stock[\"mug\"])", [
			"add 3 to pen",
			"stock[\"mug\"] = 1",
			"Two prints"
		])
	]),
	lv(88, "Update Kit", "Sentinel", "Medium / Hard", "update merges another dict in place. setdefault plants a default if missing.", "Merge a role, then tally with setdefault.", 6700, 2850, "update-kit", "Update Kit", "sentinel", "legend", [
		brief("Two dict tools", "user.update({\"role\": \"lead\"}) writes/overwrites keys. freq.setdefault(\"a\", 0) returns the current value, planting 0 if new. Then you can add 1.", "freq.setdefault(\"a\", 0)\nfreq[\"a\"] = freq[\"a\"] + 1"),
		choice("setdefault", "If a is already 4, setdefault(\"a\", 0) returns?", "0", "It only plants when missing. It returns 4.", "4", "Existing value wins.", "None", "You passed 0 as the default, but it is not used.", "b"),
		code("l88-upd", "Kit", "update / setdefault", "user is {\"name\": \"Ada\"}. update role to lead and print it. Then freq = {}, setdefault a to 0, add 1, print freq[\"a\"].", "lead then 1.", "user.update({\"role\": \"lead\"})", "user = {\"name\": \"Ada\"}\n", "lead\n1\n", "user = {\"name\": \"Ada\"}\nuser.update({\"role\": \"lead\"})\nprint(user[\"role\"])\nfreq = {}\nfreq.setdefault(\"a\", 0)\nfreq[\"a\"] = freq[\"a\"] + 1\nprint(freq[\"a\"])", [
			"user.update(...)",
			"setdefault(\"a\", 0)",
			"add 1 and print"
		])
	]),
	lv(89, "Mean Desk", "Mythic", "Medium", "Integer mean: sum with a loop, divide with //. No floating surprise.", "Mean of 80, 90, 70.", 6800, 2900, "mean-desk", "Mean Desk", "mythic", "legend", [
		brief("Floor the average", "s = 0; for n in nums: s += n; return s // len(nums). 240 // 3 is 80. // drops the decimal on purpose for this desk.", "return s // len(nums)"),
		choice("slash", "Why // not / here?", "/ is illegal", "/ works and would print 80.0. The mission wants a whole number.", "The briefing asks for an integer mean", "80 not 80.0.", "// is faster", "Not the reason in this course.", "b"),
		code("l89-mean", "Desk", "integer mean", "Write mean(nums) as integer average with //. Print mean([80, 90, 70]).", "80.", "return s // len(nums)", "def mean(nums):\n    return 0\n", "80\n", "def mean(nums):\n    s = 0\n    for n in nums:\n        s += n\n    return s // len(nums)\nprint(mean([80, 90, 70]))", [
			"sum with a loop",
			"s // len(nums)",
			"print the call"
		])
	]),
	lv(90, "Nested Pass", "Mythic", "Medium / Hard", "Walk a dict of records. Print names whose nested ok is True.", "Ada and Kai pass. Lin does not.", 6900, 2950, "nested-pass", "Nested Pass", "mythic", "legend", [
		brief("Record inside a record", "for name in desk: if desk[name][\"ok\"]: print(name). Dictionary order is insertion order: Ada, Lin, Kai — Lin is skipped.", "if desk[name][\"ok\"]:\n    print(name)"),
		choice("truth", "if desk[name][\"ok\"] tests what?", "The name string", "It tests the nested boolean.", "Whether that record’s ok is true", "True prints. False skips.", "Whether the key exists", "Missing ok would be KeyError. It exists here.", "b"),
		code("l90-ok", "Pass list", "nested dict filter", "desk maps names to {ok: bool}. Print each name whose ok is True, in dict order.", "Ada then Kai.", "if desk[name][\"ok\"]:", "desk = {\"Ada\": {\"ok\": True}, \"Lin\": {\"ok\": False}, \"Kai\": {\"ok\": True}}\n", "Ada\nKai\n", "desk = {\"Ada\": {\"ok\": True}, \"Lin\": {\"ok\": False}, \"Kai\": {\"ok\": True}}\nfor name in desk:\n    if desk[name][\"ok\"]:\n        print(name)", [
			"for name in desk:",
			"if desk[name][\"ok\"]:",
			"print(name)"
		])
	]),
	lv(91, "Pair Sheet", "Mythic", "Medium", "zip keys to values and print k=v lines. A tiny report sheet.", "name=Ada and job=lead.", 7e3, 3e3, "pair-sheet", "Pair Sheet", "mythic", "legend", [
		brief("Two rails, one sheet", "for k, v in zip(keys, vals): print(k + \"=\" + v). Both values are strings here, so + is enough. str() if a number appears later.", "print(k + \"=\" + v)"),
		choice("plus", "k + \"=\" + 7 would?", "Print name=7", "TypeError — int is not str. Use str(7).", "TypeError unless you str() the number", "This mission’s values are already strings.", "Print 7", "The + would fail first.", "b"),
		code("l91-sheet", "Sheet", "zip report", "keys = name, job. vals = Ada, lead. Print each as key=value.", "name=Ada then job=lead.", "print(k + \"=\" + v)", "keys = [\"name\", \"job\"]\nvals = [\"Ada\", \"lead\"]\n", "name=Ada\njob=lead\n", "keys = [\"name\", \"job\"]\nvals = [\"Ada\", \"lead\"]\nfor k, v in zip(keys, vals):\n    print(k + \"=\" + v)", [
			"for k, v in zip(keys, vals):",
			"k + \"=\" + v",
			"Two lines"
		])
	]),
	lv(92, "Histo Bar", "Mythic", "Hard", "Stars for counts. n: plus \"*\" * count. A chart you can read.", "Histogram of [1, 2, 2, 3, 3, 3] for 1..3.", 7100, 3050, "histo-bar", "Histo Bar", "mythic", "legend", [
		brief("Count then draw", "for n in range(1, 4): print(str(n) + \":\" + \"*\" * scores.count(n)). 1 once, 2 twice, 3 thrice. String * int repeats the bar.", "print(str(n) + \":\" + \"*\" * scores.count(n))"),
		choice("count", "[1, 2, 2].count(2) is?", "1", "Two is there twice.", "2", "count walks the whole list.", "3", "Length is 3, count of 2 is 2.", "b"),
		code("l92-hist", "Bars", "histogram", "scores = [1, 2, 2, 3, 3, 3]. For n in 1, 2, 3 print n: plus that many stars.", "1:* then 2:** then 3:***", "\"*\" * scores.count(n)", "scores = [1, 2, 2, 3, 3, 3]\n", "1:*\n2:**\n3:***\n", "scores = [1, 2, 2, 3, 3, 3]\nfor n in range(1, 4):\n    print(str(n) + \":\" + \"*\" * scores.count(n))", [
			"for n in range(1, 4):",
			"str(n) + \":\" + stars",
			"count(n)"
		])
	]),
	lv(93, "Rotate Ring", "Mythic", "Medium", "pop(0) takes the front. append puts it on the back. The ring turns once.", "Rotate [1, 2, 3, 4] left by one.", 7200, 3100, "rotate-ring", "Rotate Ring", "mythic", "legend", [
		brief("Front to back", "first = items.pop(0) removes index 0 and returns it. items.append(first) hangs it on the end. [1, 2, 3, 4] becomes [2, 3, 4, 1].", "first = items.pop(0)\nitems.append(first)"),
		choice("pop 0", "pop() with no args takes?", "The first item", "Bare pop takes the last. pop(0) takes the first.", "The last item", "Default is the end. Pass 0 for the front.", "A random item", "Index is explicit.", "b"),
		code("l93-rot", "Ring", "rotate left", "items = [1, 2, 3, 4]. Move the first item to the end. Print items.", "[2, 3, 4, 1]", "items.append(items.pop(0))", "items = [1, 2, 3, 4]\n", "[2, 3, 4, 1]\n", "items = [1, 2, 3, 4]\nfirst = items.pop(0)\nitems.append(first)\nprint(items)", [
			"pop(0)",
			"append that value",
			"print(items)"
		])
	]),
	lv(94, "Window Sum", "Mythic", "Medium / Hard", "Add each neighbor pair as you walk. A window of two.", "Neighbor sums of [3, 1, 4, 1].", 7300, 3150, "window-sum", "Window Sum", "mythic", "legend", [
		brief("i and i+1", "i from 0 while i < len(items) - 1: print(items[i] + items[i + 1]); i += 1. Four items → three windows: 3+1, 1+4, 4+1.", "while i < len(items) - 1:\n    print(items[i] + items[i + 1])\n    i += 1"),
		choice("last index", "Why stop at len - 1?", "Indexes start at 1", "items[i+1] would fall off the end if i is the last index.", "i+1 must still be a valid index", "Last pair starts at the second-to-last item.", "Windows are even", "Count of windows is n-1, not about even.", "b"),
		code("l94-win", "Windows", "pairwise sum", "items = [3, 1, 4, 1]. Print the sum of each neighbor pair, in order.", "4, 5, 5.", "print(items[i] + items[i + 1])", "items = [3, 1, 4, 1]\n", "4\n5\n5\n", "items = [3, 1, 4, 1]\ni = 0\nwhile i < len(items) - 1:\n    print(items[i] + items[i + 1])\n    i += 1", [
			"i = 0",
			"while i < len(items) - 1",
			"print pair sum"
		])
	]),
	lv(95, "Clock Mod", "Mythic", "Medium", "% 24 wraps hours. 22 + 5 is 3 o’clock, not 27.", "Wrap 22+5 and 0+24.", 7400, 3200, "clock-mod", "Clock Mod", "mythic", "legend", [
		brief("A circle of 24", "return (h + add) % 24. 22+5 = 27, 27 % 24 is 3. 0+24 % 24 is 0 — midnight again. Negative hours are out of scope.", "return (h + add) % 24"),
		choice("24", "24 % 24 is?", "24", "A full circle is 0, not 24, on a 0–23 clock.", "0", "Exactly 24 hours lands on the same hour.", "1", "That would be 25 % 24.", "b"),
		code("l95-clock", "Wrap", "mod 24", "Write wrap(h, add) as (h + add) % 24. Print wrap(22, 5) then wrap(0, 24).", "3 then 0.", "return (h + add) % 24", "def wrap(h, add):\n    return h + add\n", "3\n0\n", "def wrap(h, add):\n    return (h + add) % 24\nprint(wrap(22, 5))\nprint(wrap(0, 24))", [
			"% 24",
			"print wrap(22, 5)",
			"print wrap(0, 24)"
		])
	]),
	lv(96, "Temp Forge", "Mythic", "Medium", "C to F with integer math: c * 9 // 5 + 32. 0 → 32, 100 → 212.", "Convert freezing and boiling.", 7500, 3250, "temp-forge", "Temp Forge", "mythic", "legend", [
		brief("Integer Fahrenheit", "to_f(c) = c * 9 // 5 + 32. Multiply before you floor-divide so 100 * 9 // 5 is 180, plus 32 is 212. Parentheses optional here because * // bind left to right, then +.", "return c * 9 // 5 + 32"),
		choice("order", "Why not c * (9 // 5)?", "Same answer", "9 // 5 is 1, so you would add 32 to c. Freezing would still look ok; boiling would be 132.", "9 // 5 is 1, so boiling would be wrong", "Multiply first: 100 * 9 // 5.", "Python forbids it", "It runs. It is just the wrong formula.", "b"),
		code("l96-temp", "Forge", "C to F", "Write to_f(c) as integer Fahrenheit. Print to_f(0) then to_f(100).", "32 then 212.", "return c * 9 // 5 + 32", "def to_f(c):\n    return c\n", "32\n212\n", "def to_f(c):\n    return c * 9 // 5 + 32\nprint(to_f(0))\nprint(to_f(100))", [
			"c * 9 // 5 + 32",
			"print to_f(0)",
			"print to_f(100)"
		])
	]),
	lv(97, "Bit Tape", "Mythic", "Medium / Hard", "Odd → 1. Even → 0. Build a string of bits from a list of numbers.", "Tape for [1, 4, 5, 8].", 7600, 3300, "bit-tape", "Bit Tape", "mythic", "legend", [
		brief("Parity as bits", "out = \"\". for n in nums: if n % 2 == 0: out += \"0\" else: out += \"1\". [1, 4, 5, 8] → 1010. This is not binary conversion of each n — only even/odd.", "if n % 2 == 0:\n    out += \"0\"\nelse:\n    out += \"1\""),
		choice("parity", "Is 4 odd or even for this tape?", "Odd, bit 1", "4 % 2 is 0 → even → 0.", "Even, bit 0", "Remainder 0 means even.", "Both", "Pick one branch.", "b"),
		code("l97-bits", "Tape", "parity string", "From [1, 4, 5, 8] build a string: 1 if odd, 0 if even. Print it.", "1010", "out += \"1\"", "nums = [1, 4, 5, 8]\n", "1010\n", "nums = [1, 4, 5, 8]\nout = \"\"\nfor n in nums:\n    if n % 2 == 0:\n        out += \"0\"\n    else:\n        out += \"1\"\nprint(out)", [
			"out = \"\"",
			"even → 0, odd → 1",
			"print(out)"
		])
	]),
	lv(98, "Ticket Bay", "Mythic", "Medium / Hard", "A list of ticket records. Print ids whose open is True.", "Open tickets 1 and 3.", 7700, 3350, "ticket-bay", "Ticket Bay", "mythic", "legend", [
		brief("Filter records", "for t in tickets: if t[\"open\"]: print(t[\"id\"]). Same pattern as nested pass, but the outer structure is a list, not a dict of names.", "if t[\"open\"]:\n    print(t[\"id\"])"),
		choice("key", "t[\"id\"] vs t.id?", "Same", "Python dicts use []. .id would be an attribute — TypeError on a dict.", "Use t[\"id\"] for a dictionary", "Brackets and a string key.", "Use t.id always", "That is another language’s records, or a class. Not this dict.", "b"),
		code("l98-tix", "Bay", "filter dict list", "tickets have id and open. Print the id of each open ticket, in list order.", "1 then 3.", "if t[\"open\"]:", "tickets = [{\"id\": 1, \"open\": True}, {\"id\": 2, \"open\": False}, {\"id\": 3, \"open\": True}]\n", "1\n3\n", "tickets = [{\"id\": 1, \"open\": True}, {\"id\": 2, \"open\": False}, {\"id\": 3, \"open\": True}]\nfor t in tickets:\n    if t[\"open\"]:\n        print(t[\"id\"])", [
			"for t in tickets:",
			"if t[\"open\"]:",
			"print(t[\"id\"])"
		])
	]),
	lv(99, "Pipe Link", "Mythic", "Medium / Hard", "One helper feeds another. clean then tag. A two-stage pipeline.", "Tag a stripped, lowered name.", 7800, 3400, "pipe-link", "Pipe Link", "mythic", "legend", [
		brief("Return, don’t print inside", "clean(s) returns s.strip().lower(). tag(s) returns \"[\" + s + \"]\". Compose: tag(clean(\"  Ada  \")) → [ada]. Each function does one job.", "def clean(s):\n    return s.strip().lower()\ndef tag(s):\n    return \"[\" + s + \"]\""),
		choice("compose", "tag(clean(x)) runs which first?", "tag", "Inner call runs first. clean, then tag.", "clean", "Inside-out. Same as math f(g(x)).", "Together", "They are two calls, nested.", "b"),
		code("l99-pipe", "Pipeline", "compose helpers", "Write clean(s) as strip+lower and tag(s) as [s]. Print tag(clean(\"  Ada  \")).", "[ada]", "print(tag(clean(\"  Ada  \")))", "def clean(s):\n    return s\ndef tag(s):\n    return s\n", "[ada]\n", "def clean(s):\n    return s.strip().lower()\ndef tag(s):\n    return \"[\" + s + \"]\"\nprint(tag(clean(\"  Ada  \")))", [
			"strip().lower()",
			"\"[\" + s + \"]\"",
			"print(tag(clean(...)))"
		])
	]),
	lv(100, "Immortal Championship", "Immortal", "Expert", "Final championship. Palindrome, zip filter, frequency report — under the clock.", "Clear every stage. Claim the Immortal Crown.", 2e4, 6e3, "immortal-crown", "Immortal Crown", "immortal", "legend", [
		brief("The whole language", "Stage 1: a string equals its reverse. Stage 2: zip names to scores, print who passes. Stage 3: count a letter and write a labeled line. Colons, indents, quotes, print.", "def pal(s):\n    return s == s[::-1]"),
		code("l100-pal", "Stage 1 — Mirror", "palindrome", "Write pal(s) True when s equals s[::-1]. Print pal(\"radar\") then pal(\"jarvis\").", "True then False.", "return s == s[::-1]", "def pal(s):\n    return False\n", "True\nFalse\n", "def pal(s):\n    return s == s[::-1]\nprint(pal(\"radar\"))\nprint(pal(\"jarvis\"))", [
			"s == s[::-1]",
			"print pal(\"radar\")",
			"print pal(\"jarvis\")"
		]),
		code("l100-zip", "Stage 2 — Pass sheet", "zip + filter", "names Ada, Lin, Kai. scores 90, 60, 88. Print each name whose score is at least 70, using zip.", "Ada then Kai.", "for n, s in zip(names, scores):", "names = [\"Ada\", \"Lin\", \"Kai\"]\nscores = [90, 60, 88]\n", "Ada\nKai\n", "names = [\"Ada\", \"Lin\", \"Kai\"]\nscores = [90, 60, 88]\nfor n, s in zip(names, scores):\n    if s >= 70:\n        print(n)", [
			"zip(names, scores)",
			"if s >= 70",
			"print(n)"
		]),
		code("l100-freq", "Stage 3 — Letter report", "count + report", "Write report(text, ch) that returns ch + \"=\" + str(text.count(ch)). Print report(\"banana\", \"a\").", "a=3", "return ch + \"=\" + str(text.count(ch))", "def report(text, ch):\n    return \"\"\n", "a=3\n", "def report(text, ch):\n    return ch + \"=\" + str(text.count(ch))\nprint(report(\"banana\", \"a\"))", [
			"text.count(ch)",
			"str(...) for the number",
			"print(report(\"banana\", \"a\"))"
		])
	], {
		timeLimitSec: 220,
		championship: true,
		finale: true
	})
];
var LEVELS = [
	...[
		{
			id: 1,
			title: "Rookie Orientation",
			job: "Trainee",
			difficulty: "Easy",
			description: "Learn how a mission works, then write your first Python line.",
			objective: "Wait for the signal, then print a greeting.",
			rewardCoins: 500,
			rewardXp: 100,
			unlockRewardId: "trainee-badge",
			unlockReward: "Trainee Badge",
			careerUnlock: "trainee",
			chapter: "foundations",
			steps: [
				{
					type: "brief",
					title: "How missions work",
					body: "Each mission has a goal, a Python briefing, and a reward. Follow the steps. If your code is wrong, Jarvis explains the mistake and the fix — not just “error”."
				},
				{
					type: "reaction",
					title: "Step 1 — Wait for the signal",
					body: "Stay ready. When GO appears, tap the action button. Too early fails the check."
				},
				{
					type: "brief",
					title: "Step 2 — Python talks with print()",
					body: "print() is a function. A function is a tool you call with parentheses. The text inside quotes is a string — characters Python should treat as words, not as a name.",
					example: "print(\"Hello\")\n# The screen shows: Hello"
				},
				{
					type: "code",
					challenge: {
						id: "l1-hello",
						title: "Step 3 — Your first program",
						concept: "print() and strings",
						prompt: "Print exactly this greeting, including the comma and capital letters:",
						briefing: "Quotes wrap the message so Python does not look for a variable named Hello. print() then shows the message. The quotes themselves do not appear on the screen.",
						example: "print(\"Hello, Jarvis\")",
						starter: "# Type your line below.\n",
						expected: "Hello, Jarvis\n",
						solution: "print(\"Hello, Jarvis\")",
						hints: [
							"Use print( ) with parentheses.",
							"Put Hello, Jarvis inside quotes.",
							"Match capitals: Hello, Jarvis"
						]
					}
				}
			]
		},
		{
			id: 2,
			title: "First Assignment",
			job: "Junior Associate",
			difficulty: "Easy / Medium",
			description: "Choose the valid Python, then store values in variables.",
			objective: "Pass the decision cards and print a calculated result.",
			rewardCoins: 900,
			rewardXp: 150,
			unlockRewardId: "junior-desk",
			unlockReward: "Junior Desk",
			careerUnlock: "junior",
			chapter: "foundations",
			steps: [
				{
					type: "brief",
					title: "Variables store values",
					body: "A variable is a labeled box. name = \"Ada\" puts the string Ada in the box called name. After that, print(name) shows Ada — no quotes — because you printed the box, not the word name.",
					example: "name = \"Ada\"\nprint(name)\n# Ada"
				},
				{
					type: "choice",
					concept: "Assignment vs text",
					question: "Which line correctly stores the text Ada in a variable?",
					options: [
						{
							id: "a",
							label: "name = Ada",
							correct: false,
							explain: "Ada without quotes is treated as another variable. Python will look for a box named Ada and fail."
						},
						{
							id: "b",
							label: "name = \"Ada\"",
							correct: true,
							explain: "Quotes make Ada a string. The box name now holds that text."
						},
						{
							id: "c",
							label: "name == \"Ada\"",
							correct: false,
							explain: "== asks a yes/no question. It does not store anything. = stores. == compares."
						}
					]
				},
				{
					type: "choice",
					concept: "What print shows",
					question: "What does print(3 + 2) show?",
					options: [
						{
							id: "a",
							label: "3 + 2",
							correct: false,
							explain: "Without quotes, 3 + 2 is math. Python adds first, then prints the result."
						},
						{
							id: "b",
							label: "5",
							correct: true,
							explain: "Numbers without quotes are numbers. + adds them. print shows 5."
						},
						{
							id: "c",
							label: "\"32\"",
							correct: false,
							explain: "Sticking 3 and 2 together happens with strings: print(\"3\" + \"2\") would show 32."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l2-vars",
						title: "Store and print",
						concept: "variables",
						prompt: "Create a variable called city with the text London, then print the variable (not the word in quotes).",
						briefing: "Assign with =. Print the name with no quotes around the name.",
						example: "city = \"London\"\nprint(city)",
						starter: "city = \"\"\n",
						expected: "London\n",
						solution: "city = \"London\"\nprint(city)",
						hints: [
							"Put London inside quotes on the right of =.",
							"Then print(city) — city has no quotes.",
							"If you print(\"city\") you will see the word city, not London."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l2-sum",
						title: "Payroll math",
						concept: "numbers",
						prompt: "base is 40. bonus is 15. Print the sum of base and bonus as a number.",
						briefing: "Numbers have no quotes. + adds them. print(base + bonus) calculates, then shows the result.",
						example: "print(40 + 15)",
						starter: "base = 40\nbonus = 15\n",
						expected: "55\n",
						solution: "base = 40\nbonus = 15\nprint(base + bonus)",
						hints: [
							"Do not quote the numbers.",
							"print(base + bonus)",
							"The screen should show 55 with no extra text."
						]
					}
				}
			]
		},
		{
			id: 3,
			title: "Speed Mission",
			job: "Specialist",
			difficulty: "Medium",
			description: "Write correct conditions before the clock hits zero.",
			objective: "Finish every task before time runs out.",
			rewardCoins: 1500,
			rewardXp: 250,
			unlockRewardId: "specialist-outfit",
			unlockReward: "Specialist Outfit",
			careerUnlock: "specialist",
			chapter: "foundations",
			timeLimitSec: 75,
			steps: [
				{
					type: "brief",
					title: "if / else decides",
					body: "An if line asks a yes/no question. If the answer is True, Python runs the indented block. else runs when the answer is False. The if line must end with a colon, and the next line must be indented.",
					example: "if score >= 70:\n    print(\"PASS\")\nelse:\n    print(\"RETRY\")"
				},
				{
					type: "code",
					challenge: {
						id: "l3-if",
						title: "Gate check",
						concept: "if / else",
						prompt: "score is 82. If score is at least 70, print PASS. Otherwise print RETRY.",
						briefing: ">= means greater than or equal. PASS and RETRY are strings — wrap them in quotes. Indent the print lines.",
						example: "if score >= 70:\n    print(\"PASS\")",
						starter: "score = 82\n",
						expected: "PASS\n",
						solution: "score = 82\nif score >= 70:\n    print(\"PASS\")\nelse:\n    print(\"RETRY\")",
						hints: [
							"End the if line with a colon.",
							"Indent print with 4 spaces.",
							"print(\"PASS\") with quotes."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l3-compare",
						title: "True or False",
						concept: "comparisons",
						prompt: "Print the result of checking whether 9 is less than 4. It should print False.",
						briefing: "Comparisons produce True or False. print(9 < 4) shows False because 9 is not less than 4. Do not quote True/False — they are boolean values, not text.",
						example: "print(9 < 4)",
						starter: "",
						expected: "False\n",
						solution: "print(9 < 4)",
						hints: [
							"Use the < operator.",
							"print(9 < 4)",
							"False has a capital F — Python will print that if you compare correctly."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l3-branch",
						title: "Access level",
						concept: "if / else",
						prompt: "role is guest. If role equals admin, print OPEN. Otherwise print LOCKED.",
						briefing: "== compares two values. Strings must match exactly. guest is not admin, so the else branch should run.",
						example: "if role == \"admin\":\n    print(\"OPEN\")\nelse:\n    print(\"LOCKED\")",
						starter: "role = \"guest\"\n",
						expected: "LOCKED\n",
						solution: "role = \"guest\"\nif role == \"admin\":\n    print(\"OPEN\")\nelse:\n    print(\"LOCKED\")",
						hints: [
							"Compare with == not =.",
							"else: then indented print(\"LOCKED\")",
							"guest is not admin, so LOCKED is correct."
						]
					}
				}
			]
		},
		{
			id: 4,
			title: "Executive Trial",
			job: "Manager",
			difficulty: "Hard",
			description: "Complete three list-and-loop objectives in order.",
			objective: "Build a list, walk it, then report its size.",
			rewardCoins: 2500,
			rewardXp: 400,
			unlockRewardId: "executive-office",
			unlockReward: "Executive Office",
			careerUnlock: "manager",
			chapter: "foundations",
			steps: [
				{
					type: "brief",
					title: "Lists and for-loops",
					body: "A list holds several values in order, inside square brackets. for item in list: runs the indented block once per value. len(list) counts how many items. Indexes start at 0 — the first item is items[0].",
					example: "items = [\"plan\", \"code\", \"test\"]\nfor item in items:\n    print(item)"
				},
				{
					type: "code",
					challenge: {
						id: "l4-list",
						title: "Objective 1 — The roster",
						concept: "lists",
						prompt: "Create a list called team with three strings: Ada, Lin, Kai. Print the list.",
						briefing: "Strings in a list still need quotes. print(team) shows the whole list with brackets and quotes — that is normal.",
						example: "team = [\"Ada\", \"Lin\", \"Kai\"]\nprint(team)",
						starter: "team = []\n",
						expected: "['Ada', 'Lin', 'Kai']\n",
						solution: "team = [\"Ada\", \"Lin\", \"Kai\"]\nprint(team)",
						hints: [
							"Three quoted names inside [ ].",
							"Separate them with commas.",
							"print(team) after you build it."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l4-loop",
						title: "Objective 2 — Walk the list",
						concept: "for loops",
						prompt: "Loop through tasks and print each item on its own line.",
						briefing: "for t in tasks: then indent print(t). The loop variable t becomes each item in turn. Do not print the whole list.",
						example: "for t in tasks:\n    print(t)",
						starter: "tasks = [\"plan\", \"code\", \"test\"]\n",
						expected: "plan\ncode\ntest\n",
						solution: "tasks = [\"plan\", \"code\", \"test\"]\nfor t in tasks:\n    print(t)",
						hints: [
							"for t in tasks:",
							"Indent print(t) with 4 spaces.",
							"You should see three lines, one word each."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l4-len",
						title: "Objective 3 — Headcount",
						concept: "len()",
						prompt: "Print how many items are in rooms using len().",
						briefing: "len(rooms) returns a number. print(len(rooms)) shows that number. Do not write 3 by hand — use len so the answer stays correct if the list changes.",
						example: "print(len(rooms))",
						starter: "rooms = [\"ops\", \"lab\", \"brief\", \"vault\"]\n",
						expected: "4\n",
						solution: "rooms = [\"ops\", \"lab\", \"brief\", \"vault\"]\nprint(len(rooms))",
						hints: [
							"len(rooms) counts items.",
							"print(len(rooms))",
							"The answer is 4."
						]
					}
				}
			]
		},
		{
			id: 5,
			title: "Elite Championship",
			job: "Elite Professional",
			difficulty: "Hard",
			description: "Combine functions, loops, and conditions. Championship scoring is live.",
			objective: "Clear every stage before time expires.",
			rewardCoins: 5e3,
			rewardXp: 750,
			unlockRewardId: "m8-apex",
			unlockReward: "M8 Apex",
			careerUnlock: "elite",
			chapter: "foundations",
			timeLimitSec: 120,
			championship: true,
			steps: [
				{
					type: "brief",
					title: "Functions package skill",
					body: "def name(args): creates a reusable tool. return sends a value back to the caller. print(greet(\"Elite\")) first runs greet, then prints whatever greet returned.",
					example: "def greet(name):\n    return \"Ready, \" + name\nprint(greet(\"Elite\"))"
				},
				{
					type: "code",
					challenge: {
						id: "l5-fn",
						title: "Stage 1 — Briefing call",
						concept: "functions + return",
						prompt: "Write greet(name) so it returns Ready, plus a space, plus name. Then print greet(\"Elite\").",
						briefing: "return does not print. print is separate. Join strings with +.",
						example: "def greet(name):\n    return \"Ready, \" + name",
						starter: "def greet(name):\n    return name\n",
						expected: "Ready, Elite\n",
						solution: "def greet(name):\n    return \"Ready, \" + name\nprint(greet(\"Elite\"))",
						hints: [
							"return \"Ready, \" + name",
							"Remember the comma and space after Ready.",
							"Call print(greet(\"Elite\")) under the function."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l5-filter",
						title: "Stage 2 — Clearance filter",
						concept: "loop + if",
						prompt: "scores holds exam results. Print only the scores that are at least 70, each on its own line.",
						briefing: "Loop every score. Inside the loop, if score >= 70, print it. Indent twice: once for the for, once for the if.",
						example: "for s in scores:\n    if s >= 70:\n        print(s)",
						starter: "scores = [55, 90, 70, 41, 88]\n",
						expected: "90\n70\n88\n",
						solution: "scores = [55, 90, 70, 41, 88]\nfor s in scores:\n    if s >= 70:\n        print(s)",
						hints: [
							"for s in scores:",
							"if s >= 70:",
							"print(s) indented under the if."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l5-total",
						title: "Stage 3 — Final tally",
						concept: "functions + loops",
						prompt: "Write total(nums) that adds every number in the list and returns the sum. Print total([10, 20, 30]).",
						briefing: "Start a box at 0. Loop, add each number, return the box. You may also use sum(nums).",
						example: "def total(nums):\n    s = 0\n    for n in nums:\n        s += n\n    return s",
						starter: "def total(nums):\n    return 0\n",
						expected: "60\n",
						solution: "def total(nums):\n    s = 0\n    for n in nums:\n        s += n\n    return s\nprint(total([10, 20, 30]))",
						hints: [
							"s = 0 then for n in nums: s += n",
							"return s",
							"print(total([10, 20, 30]))"
						]
					}
				}
			]
		},
		{
			id: 6,
			title: "String Lab",
			job: "Senior Engineer",
			difficulty: "Easy / Medium",
			description: "Join text together. Turn numbers into text with str().",
			objective: "Concatenate names, then build a labeled desk number.",
			rewardCoins: 1100,
			rewardXp: 300,
			unlockRewardId: "string-keys",
			unlockReward: "String Keys",
			careerUnlock: "elite",
			chapter: "strings",
			steps: [
				{
					type: "brief",
					title: "Strings glue with +",
					body: "+ on two strings pastes them. It does not add a space unless you put one in. Numbers cannot join text until you wrap them in str().",
					example: "print(\"Ada\" + \" \" + \"Lovelace\")\nprint(\"Desk \" + str(7))"
				},
				{
					type: "choice",
					concept: "str() vs quotes",
					question: "How do you turn the number 7 into the text \"7\"?",
					options: [
						{
							id: "a",
							label: "int(7)",
							correct: false,
							explain: "int() turns values into numbers. 7 is already a number."
						},
						{
							id: "b",
							label: "str(7)",
							correct: true,
							explain: "str() makes a string from a number so it can join other text."
						},
						{
							id: "c",
							label: "print(7)",
							correct: false,
							explain: "print shows 7 on the screen, but the value is still a number — you cannot add it to a string."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l6-concat",
						title: "Nameplate",
						concept: "string +",
						prompt: "first is Ada. last is Lovelace. Print the full name with one space in the middle.",
						briefing: "Join with +. Put a space string between the two names.",
						example: "print(first + \" \" + last)",
						starter: "first = \"Ada\"\nlast = \"Lovelace\"\n",
						expected: "Ada Lovelace\n",
						solution: "first = \"Ada\"\nlast = \"Lovelace\"\nprint(first + \" \" + last)",
						hints: [
							"Use + between the pieces.",
							"The space is its own string: \" \"",
							"print(first + \" \" + last)"
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l6-str",
						title: "Desk label",
						concept: "str()",
						prompt: "n is 7. Print Desk 7 using the variable n — do not type the digit 7 inside the string.",
						briefing: "Python refuses \"Desk \" + n because one side is text and the other is a number. Convert with str(n).",
						example: "print(\"Desk \" + str(n))",
						starter: "n = 7\n",
						expected: "Desk 7\n",
						solution: "n = 7\nprint(\"Desk \" + str(n))",
						hints: [
							"str(n) turns 7 into \"7\".",
							"\"Desk \" has a trailing space.",
							"print(\"Desk \" + str(n))"
						]
					}
				}
			]
		},
		{
			id: 7,
			title: "Case File",
			job: "Senior Engineer",
			difficulty: "Easy / Medium",
			description: "Change letter case and trim leftover spaces.",
			objective: "Use upper, lower, and strip.",
			rewardCoins: 1200,
			rewardXp: 350,
			unlockRewardId: "case-file",
			unlockReward: "Case File",
			careerUnlock: "senior",
			chapter: "strings",
			steps: [
				{
					type: "brief",
					title: "Methods sit after a dot",
					body: "text.upper() is a method — a function that belongs to a value. The empty () still matter. Forgetting them is a common miss. strip() removes spaces from both ends, not from the middle.",
					example: "print(\"jarvis\".upper())\nprint(\"  Ada  \".strip())"
				},
				{
					type: "choice",
					concept: "methods need ()",
					question: "What does print(\"Hi\".lower()) show?",
					options: [
						{
							id: "a",
							label: "Hi",
							correct: false,
							explain: "lower() changes every letter. H becomes h."
						},
						{
							id: "b",
							label: "hi",
							correct: true,
							explain: "lower() returns a new string with all lowercase letters."
						},
						{
							id: "c",
							label: "HI",
							correct: false,
							explain: "That would be upper(), the opposite method."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l7-upper",
						title: "Loud callsign",
						concept: "upper()",
						prompt: "Print jarvis in all capitals using a string method.",
						briefing: "Call upper on the string. Parentheses are required.",
						example: "print(\"jarvis\".upper())",
						starter: "",
						expected: "JARVIS\n",
						solution: "print(\"jarvis\".upper())",
						hints: [
							"\"jarvis\".upper()",
							"Do not forget ().",
							"Wrap the call in print."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l7-strip",
						title: "Clean badge",
						concept: "strip()",
						prompt: "name has extra spaces. Print the cleaned name with no leading or trailing spaces.",
						briefing: "strip() returns a new string. It does not change name unless you assign it.",
						example: "print(name.strip())",
						starter: "name = \"  Ada  \"\n",
						expected: "Ada\n",
						solution: "name = \"  Ada  \"\nprint(name.strip())",
						hints: [
							"name.strip()",
							"Print the result of strip, not name itself.",
							"The output is Ada with no spaces."
						]
					}
				}
			]
		},
		{
			id: 8,
			title: "Character Lens",
			job: "Staff Engineer",
			difficulty: "Medium",
			description: "Read one character at a time. Indexes start at zero.",
			objective: "Print the first letter, the last letter, and a string length.",
			rewardCoins: 1300,
			rewardXp: 400,
			unlockRewardId: "char-lens",
			unlockReward: "Character Lens",
			careerUnlock: "senior",
			chapter: "strings",
			steps: [
				{
					type: "brief",
					title: "Indexes start at 0",
					body: "word[0] is the first character. word[-1] is the last. len(word) counts characters, including spaces.",
					example: "word = \"Python\"\nprint(word[0])  # P\nprint(word[-1]) # n"
				},
				{
					type: "choice",
					concept: "zero-based index",
					question: "In the string \"code\", which index is the letter d?",
					options: [
						{
							id: "a",
							label: "1",
							correct: false,
							explain: "Index 1 is o. Counting starts at 0: c=0, o=1, d=2, e=3."
						},
						{
							id: "b",
							label: "2",
							correct: true,
							explain: "c=0, o=1, d=2. The third letter lives at index 2."
						},
						{
							id: "c",
							label: "3",
							correct: false,
							explain: "Index 3 is e, the last letter."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l8-first-last",
						title: "Bookends",
						concept: "string index",
						prompt: "word is Python. Print the first character, then the last character, each on its own line.",
						briefing: "Use [0] and [-1]. Each print makes a new line.",
						example: "print(word[0])\nprint(word[-1])",
						starter: "word = \"Python\"\n",
						expected: "P\nn\n",
						solution: "word = \"Python\"\nprint(word[0])\nprint(word[-1])",
						hints: [
							"First letter: word[0]",
							"Last letter: word[-1]",
							"Two print calls."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l8-len",
						title: "Letter count",
						concept: "len(str)",
						prompt: "Print how many characters are in the string career using len().",
						briefing: "len works on strings the same way it works on lists.",
						example: "print(len(\"career\"))",
						starter: "",
						expected: "6\n",
						solution: "print(len(\"career\"))",
						hints: [
							"len(\"career\")",
							"Wrap it in print.",
							"The answer is 6."
						]
					}
				}
			]
		},
		{
			id: 9,
			title: "Logic Core",
			job: "Staff Engineer",
			difficulty: "Medium",
			description: "Combine True and False with and, or, and not.",
			objective: "Print boolean results from comparisons and logic.",
			rewardCoins: 1400,
			rewardXp: 450,
			unlockRewardId: "logic-core",
			unlockReward: "Logic Core",
			careerUnlock: "staff",
			chapter: "logic",
			steps: [
				{
					type: "brief",
					title: "and / or / not",
					body: "and is True only if both sides are True. or is True if at least one side is True. not flips True to False. Comparisons like >= produce booleans you can combine.",
					example: "print(True and False)  # False\nprint(age >= 18 and age < 65)"
				},
				{
					type: "choice",
					concept: "not",
					question: "What does print(not True) show?",
					options: [
						{
							id: "a",
							label: "True",
							correct: false,
							explain: "not flips the value. The opposite of True is False."
						},
						{
							id: "b",
							label: "False",
							correct: true,
							explain: "not True is False. not False is True."
						},
						{
							id: "c",
							label: "not True",
							correct: false,
							explain: "Python evaluates the expression, then prints the boolean result."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l9-and",
						title: "Both gates",
						concept: "and",
						prompt: "Print the result of True and False.",
						briefing: "Do not quote True or False. They are keywords.",
						example: "print(True and False)",
						starter: "",
						expected: "False\n",
						solution: "print(True and False)",
						hints: [
							"True and False — no quotes.",
							"and needs both sides True to be True.",
							"The output is False."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l9-range",
						title: "Working age",
						concept: "combined compare",
						prompt: "age is 20. Print whether age is at least 18 and also less than 65.",
						briefing: "Chain with and. Python will print True or False.",
						example: "print(age >= 18 and age < 65)",
						starter: "age = 20\n",
						expected: "True\n",
						solution: "age = 20\nprint(age >= 18 and age < 65)",
						hints: [
							"age >= 18",
							"and age < 65",
							"Print the whole comparison."
						]
					}
				}
			]
		},
		{
			id: 10,
			title: "Branch Map",
			job: "Lead Engineer",
			difficulty: "Medium / Hard",
			description: "elif picks the first matching branch. The clock is live.",
			objective: "Grade a score and classify a temperature before time runs out.",
			rewardCoins: 1600,
			rewardXp: 500,
			unlockRewardId: "branch-map",
			unlockReward: "Branch Map",
			careerUnlock: "staff",
			chapter: "logic",
			timeLimitSec: 90,
			steps: [
				{
					type: "brief",
					title: "elif is the next door",
					body: "Python checks if, then each elif, then else. The first True branch runs. Later branches are skipped even if they would also be True. Order matters.",
					example: "if score >= 90:\n    print(\"A\")\nelif score >= 70:\n    print(\"B\")\nelse:\n    print(\"C\")"
				},
				{
					type: "code",
					challenge: {
						id: "l10-grade",
						title: "Letter grade",
						concept: "elif",
						prompt: "score is 91. If it is at least 90 print A. Else if it is at least 70 print B. Otherwise print C.",
						briefing: "91 matches the first branch. Put colons on every header. Indent each print.",
						example: "if score >= 90:\n    print(\"A\")",
						starter: "score = 91\n",
						expected: "A\n",
						solution: "score = 91\nif score >= 90:\n    print(\"A\")\nelif score >= 70:\n    print(\"B\")\nelse:\n    print(\"C\")",
						hints: [
							"if score >= 90:",
							"elif score >= 70:",
							"else: print(\"C\")"
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l10-temp",
						title: "Climate check",
						concept: "elif",
						prompt: "temp is 12. If temp is under 10 print COLD. Else if temp is under 25 print OK. Otherwise print HOT.",
						briefing: "12 is not < 10, but it is < 25, so OK.",
						example: "if temp < 10:\n    print(\"COLD\")",
						starter: "temp = 12\n",
						expected: "OK\n",
						solution: "temp = 12\nif temp < 10:\n    print(\"COLD\")\nelif temp < 25:\n    print(\"OK\")\nelse:\n    print(\"HOT\")",
						hints: [
							"if temp < 10:",
							"elif temp < 25:",
							"12 is OK, not COLD."
						]
					}
				}
			]
		},
		{
			id: 11,
			title: "While Engine",
			job: "Lead Engineer",
			difficulty: "Medium",
			description: "A while loop repeats until its condition becomes False.",
			objective: "Count up, then count down. Always change the loop variable.",
			rewardCoins: 1700,
			rewardXp: 550,
			unlockRewardId: "while-engine",
			unlockReward: "While Engine",
			careerUnlock: "lead",
			chapter: "loops",
			steps: [
				{
					type: "brief",
					title: "while needs an exit",
					body: "while condition: repeats the indented block as long as the condition is True. If you forget to change the variable, the loop never ends — Jarvis will stop it and tell you.",
					example: "i = 1\nwhile i <= 3:\n    print(i)\n    i += 1"
				},
				{
					type: "choice",
					concept: "infinite loops",
					question: "Why must you change i inside while i <= 3?",
					options: [
						{
							id: "a",
							label: "So the condition eventually becomes False",
							correct: true,
							explain: "If i stays 1 forever, i <= 3 stays True and the loop never stops."
						},
						{
							id: "b",
							label: "Python requires += on every line",
							correct: false,
							explain: "+= is just one way to change a number. The requirement is that the condition can become False."
						},
						{
							id: "c",
							label: "print() only works after +=",
							correct: false,
							explain: "print works any time. The increment is about ending the loop, not about printing."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l11-up",
						title: "Count up",
						concept: "while",
						prompt: "Start i at 1. While i is at most 3, print i, then add 1.",
						briefing: "The increment belongs inside the loop, indented.",
						example: "while i <= 3:\n    print(i)\n    i += 1",
						starter: "i = 1\n",
						expected: "1\n2\n3\n",
						solution: "i = 1\nwhile i <= 3:\n    print(i)\n    i += 1",
						hints: [
							"while i <= 3:",
							"print(i) then i += 1",
							"Both lines indented."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l11-down",
						title: "Countdown",
						concept: "while",
						prompt: "n starts at 5. While n is greater than 0, print n, then subtract 1.",
						briefing: "n -= 1 is the same as n = n - 1. Stop when n is 0 so 0 is not printed.",
						example: "while n > 0:\n    print(n)\n    n -= 1",
						starter: "n = 5\n",
						expected: "5\n4\n3\n2\n1\n",
						solution: "n = 5\nwhile n > 0:\n    print(n)\n    n -= 1",
						hints: [
							"while n > 0:",
							"print(n)",
							"n -= 1"
						]
					}
				}
			]
		},
		{
			id: 12,
			title: "Range Rail",
			job: "Principal Engineer",
			difficulty: "Medium",
			description: "range() builds the numbers a for-loop walks.",
			objective: "Print range(4) and range(2, 6).",
			rewardCoins: 1800,
			rewardXp: 600,
			unlockRewardId: "range-rail",
			unlockReward: "Range Rail",
			careerUnlock: "lead",
			chapter: "loops",
			steps: [
				{
					type: "brief",
					title: "range stops before the end",
					body: "range(4) is 0, 1, 2, 3 — it does not include 4. range(2, 6) starts at 2 and stops before 6. You almost always use range inside a for loop.",
					example: "for i in range(4):\n    print(i)"
				},
				{
					type: "choice",
					concept: "range stop",
					question: "Which numbers does range(3) produce?",
					options: [
						{
							id: "a",
							label: "1, 2, 3",
							correct: false,
							explain: "range starts at 0 unless you say otherwise. It never includes the stop value."
						},
						{
							id: "b",
							label: "0, 1, 2",
							correct: true,
							explain: "Start 0, stop before 3."
						},
						{
							id: "c",
							label: "0, 1, 2, 3",
							correct: false,
							explain: "That would be range(4). The 3 is the stop, not a value."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l12-range",
						title: "Zero to three",
						concept: "range",
						prompt: "Loop with range(4) and print each number on its own line.",
						briefing: "for i in range(4): then print(i).",
						example: "for i in range(4):\n    print(i)",
						starter: "",
						expected: "0\n1\n2\n3\n",
						solution: "for i in range(4):\n    print(i)",
						hints: [
							"for i in range(4):",
							"Indent print(i).",
							"Four lines: 0 through 3."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l12-span",
						title: "Two to five",
						concept: "range(start, stop)",
						prompt: "Print every integer from 2 up to but not including 6.",
						briefing: "range(2, 6) does that in one call.",
						example: "for i in range(2, 6):\n    print(i)",
						starter: "",
						expected: "2\n3\n4\n5\n",
						solution: "for i in range(2, 6):\n    print(i)",
						hints: [
							"range(2, 6)",
							"Stop is 6, last printed is 5.",
							"for i in range(2, 6): print(i)"
						]
					}
				}
			]
		},
		{
			id: 13,
			title: "Nest Grid",
			job: "Principal Engineer",
			difficulty: "Hard",
			description: "A loop inside a loop. The inner one finishes every time the outer ticks.",
			objective: "Print a multiplication grid before the timer ends.",
			rewardCoins: 2e3,
			rewardXp: 650,
			unlockRewardId: "nest-grid",
			unlockReward: "Nest Grid",
			careerUnlock: "principal",
			chapter: "loops",
			timeLimitSec: 80,
			steps: [
				{
					type: "brief",
					title: "Inner loop runs fully",
					body: "For each value of x, y walks its whole list. Four prints from two lists of two. Indent the inner for one extra level.",
					example: "for x in [1, 2]:\n    for y in [3, 4]:\n        print(x * y)"
				},
				{
					type: "code",
					challenge: {
						id: "l13-grid",
						title: "Product grid",
						concept: "nested for",
						prompt: "x walks [1, 2]. For each x, y walks [3, 4]. Print x * y each time.",
						briefing: "Four lines: 3, 4, then 6, 8.",
						example: "for x in [1, 2]:\n    for y in [3, 4]:\n        print(x * y)",
						starter: "",
						expected: "3\n4\n6\n8\n",
						solution: "for x in [1, 2]:\n    for y in [3, 4]:\n        print(x * y)",
						hints: [
							"for x in [1, 2]:",
							"    for y in [3, 4]:",
							"        print(x * y)"
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l13-filter",
						title: "High water",
						concept: "for + if",
						prompt: "nums is [3, 10, 7, 2]. Print only the numbers greater than 5, each on its own line.",
						briefing: "Loop, then if n > 5: print(n).",
						example: "for n in nums:\n    if n > 5:\n        print(n)",
						starter: "nums = [3, 10, 7, 2]\n",
						expected: "10\n7\n",
						solution: "nums = [3, 10, 7, 2]\nfor n in nums:\n    if n > 5:\n        print(n)",
						hints: [
							"for n in nums:",
							"if n > 5:",
							"print(n) under the if."
						]
					}
				}
			]
		},
		{
			id: 14,
			title: "Index Desk",
			job: "Principal Engineer",
			difficulty: "Medium",
			description: "Read and replace a list item by position.",
			objective: "Print index 1, then overwrite index 0.",
			rewardCoins: 2100,
			rewardXp: 700,
			unlockRewardId: "index-badge",
			unlockReward: "Index Badge",
			careerUnlock: "principal",
			chapter: "structures",
			steps: [
				{
					type: "brief",
					title: "Replace, don't append",
					body: "nums[1] reads the second item. nums[0] = 99 replaces the first. You can only assign to an index that already exists — use append to grow the list.",
					example: "nums = [10, 20, 30]\nprint(nums[1])\nnums[0] = 99"
				},
				{
					type: "code",
					challenge: {
						id: "l14-read",
						title: "Second seat",
						concept: "list index",
						prompt: "nums is [10, 20, 30]. Print the item at index 1.",
						briefing: "Index 1 is the second value because counting starts at 0.",
						example: "print(nums[1])",
						starter: "nums = [10, 20, 30]\n",
						expected: "20\n",
						solution: "nums = [10, 20, 30]\nprint(nums[1])",
						hints: [
							"nums[1]",
							"That is 20, not 10.",
							"print(nums[1])"
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l14-write",
						title: "Overwrite",
						concept: "item assignment",
						prompt: "Set the first item of nums to 99, then print the whole list.",
						briefing: "nums[0] = 99 mutates the list in place.",
						example: "nums[0] = 99\nprint(nums)",
						starter: "nums = [10, 20, 30]\n",
						expected: "[99, 20, 30]\n",
						solution: "nums = [10, 20, 30]\nnums[0] = 99\nprint(nums)",
						hints: [
							"nums[0] = 99",
							"print(nums) after the assignment.",
							"Brackets in the output are normal."
						]
					}
				}
			]
		},
		{
			id: 15,
			title: "Append Bay",
			job: "Architect",
			difficulty: "Medium",
			description: "Grow a list with append. The method itself returns None.",
			objective: "Add a teammate, then count the box.",
			rewardCoins: 2200,
			rewardXp: 800,
			unlockRewardId: "append-bay",
			unlockReward: "Append Bay",
			careerUnlock: "principal",
			chapter: "structures",
			steps: [
				{
					type: "brief",
					title: "append mutates",
					body: "team.append(\"Lin\") adds Lin to the end. The call returns None — so print(team.append(\"Lin\")) would show None. Print the list after you append.",
					example: "team = [\"Ada\"]\nteam.append(\"Lin\")\nprint(team)"
				},
				{
					type: "choice",
					concept: "append return",
					question: "What does print(team.append(\"Lin\")) show?",
					options: [
						{
							id: "a",
							label: "Lin",
							correct: false,
							explain: "append does not return the new item. It returns None."
						},
						{
							id: "b",
							label: "None",
							correct: true,
							explain: "Most mutating list methods return None. Print the list afterwards if you want to see it."
						},
						{
							id: "c",
							label: "['Ada', 'Lin']",
							correct: false,
							explain: "That is what print(team) shows after append, not what append itself returns."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l15-append",
						title: "Hire Lin",
						concept: "append",
						prompt: "team starts as [\"Ada\"]. Append Lin, then print the list.",
						briefing: "Two steps: append, then print(team).",
						example: "team.append(\"Lin\")\nprint(team)",
						starter: "team = [\"Ada\"]\n",
						expected: "['Ada', 'Lin']\n",
						solution: "team = [\"Ada\"]\nteam.append(\"Lin\")\nprint(team)",
						hints: [
							"team.append(\"Lin\")",
							"Then print(team)",
							"Do not print the append call itself."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l15-grow",
						title: "Load the box",
						concept: "append + len",
						prompt: "box starts empty. Append 1, then append 2, then print how many items are in box.",
						briefing: "Two appends, then print(len(box)).",
						example: "box.append(1)\nbox.append(2)\nprint(len(box))",
						starter: "box = []\n",
						expected: "2\n",
						solution: "box = []\nbox.append(1)\nbox.append(2)\nprint(len(box))",
						hints: [
							"box.append(1)",
							"box.append(2)",
							"print(len(box))"
						]
					}
				}
			]
		},
		{
			id: 16,
			title: "Slice Glass",
			job: "Architect",
			difficulty: "Medium / Hard",
			description: "A slice is a window: start included, end excluded.",
			objective: "Slice a list and a string.",
			rewardCoins: 2300,
			rewardXp: 850,
			unlockRewardId: "slice-glass",
			unlockReward: "Slice Glass",
			careerUnlock: "architect",
			chapter: "structures",
			steps: [
				{
					type: "brief",
					title: "start:end",
					body: "items[1:3] takes indexes 1 and 2 — it stops before 3. Leaving the start empty means 0. Leaving the end empty means “to the last item”. Slicing a string returns a smaller string.",
					example: "letters = [\"a\", \"b\", \"c\", \"d\"]\nprint(letters[1:3])  # ['b', 'c']\nprint(\"Python\"[0:3])  # Pyt"
				},
				{
					type: "choice",
					concept: "half-open slice",
					question: "What does \"code\"[:2] produce?",
					options: [
						{
							id: "a",
							label: "cod",
							correct: false,
							explain: "[:2] is indexes 0 and 1, so co — it stops before 2."
						},
						{
							id: "b",
							label: "co",
							correct: true,
							explain: "Empty start means 0. End 2 is excluded. c=0, o=1."
						},
						{
							id: "c",
							label: "code",
							correct: false,
							explain: "That would be the whole string, slice [:] or [0:4]."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l16-list",
						title: "Middle pair",
						concept: "list slice",
						prompt: "letters is a, b, c, d. Print the slice from index 1 up to (not including) 3.",
						briefing: "letters[1:3] → b and c.",
						example: "print(letters[1:3])",
						starter: "letters = [\"a\", \"b\", \"c\", \"d\"]\n",
						expected: "['b', 'c']\n",
						solution: "letters = [\"a\", \"b\", \"c\", \"d\"]\nprint(letters[1:3])",
						hints: [
							"letters[1:3]",
							"End 3 is not included.",
							"print the slice."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l16-str",
						title: "Prefix",
						concept: "string slice",
						prompt: "Print the first three characters of Python using a slice.",
						briefing: "[0:3] on a string returns a string, not a list.",
						example: "print(\"Python\"[0:3])",
						starter: "",
						expected: "Pyt\n",
						solution: "print(\"Python\"[0:3])",
						hints: [
							"\"Python\"[0:3]",
							"P=0, y=1, t=2.",
							"Output is Pyt with no quotes."
						]
					}
				}
			]
		},
		{
			id: 17,
			title: "Break Seal",
			job: "Architect",
			difficulty: "Hard",
			description: "break leaves the loop. continue skips one round.",
			objective: "Stop at 9. Skip even numbers.",
			rewardCoins: 2400,
			rewardXp: 900,
			unlockRewardId: "break-seal",
			unlockReward: "Break Seal",
			careerUnlock: "architect",
			chapter: "structures",
			steps: [
				{
					type: "brief",
					title: "Two exits",
					body: "break jumps out of the nearest loop immediately. continue jumps to the next item and skips the rest of this round. % is remainder — n % 2 == 0 means n is even.",
					example: "for n in nums:\n    if n == 9:\n        break\n    print(n)"
				},
				{
					type: "code",
					challenge: {
						id: "l17-break",
						title: "Stop at nine",
						concept: "break",
						prompt: "Loop [1, 2, 9, 4]. Print each number, but break when you see 9 so 9 and 4 are not printed.",
						briefing: "Check for 9 first, then print. Order matters.",
						example: "if n == 9:\n    break\nprint(n)",
						starter: "",
						expected: "1\n2\n",
						solution: "for n in [1, 2, 9, 4]:\n    if n == 9:\n        break\n    print(n)",
						hints: [
							"for n in [1, 2, 9, 4]:",
							"if n == 9: break",
							"print(n) after the if, same indent as the if."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l17-continue",
						title: "Odds only",
						concept: "continue",
						prompt: "Loop 1, 2, 3, 4. Skip even numbers with continue. Print the odd ones.",
						briefing: "if n % 2 == 0: continue. Then print(n).",
						example: "if n % 2 == 0:\n    continue\nprint(n)",
						starter: "",
						expected: "1\n3\n",
						solution: "for n in [1, 2, 3, 4]:\n    if n % 2 == 0:\n        continue\n    print(n)",
						hints: [
							"for n in [1, 2, 3, 4]:",
							"if n % 2 == 0: continue",
							"print(n)"
						]
					}
				}
			]
		},
		{
			id: 18,
			title: "Record Vault",
			job: "Distinguished Engineer",
			difficulty: "Medium / Hard",
			description: "A dictionary maps a key to a value. Look up with [key].",
			objective: "Read a name, then promote a role.",
			rewardCoins: 2600,
			rewardXp: 1e3,
			unlockRewardId: "record-vault",
			unlockReward: "Record Vault",
			careerUnlock: "architect",
			chapter: "structures",
			steps: [
				{
					type: "brief",
					title: "Keys, not indexes",
					body: "A dict uses curly braces and colons: {\"name\": \"Ada\"}. Read with user[\"name\"]. Assign user[\"role\"] = \"architect\" to add or replace a key. Keys are usually strings.",
					example: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\nprint(user[\"name\"])"
				},
				{
					type: "choice",
					concept: "dict syntax",
					question: "Which line creates a dictionary?",
					options: [
						{
							id: "a",
							label: "user = [\"name\", \"Ada\"]",
							correct: false,
							explain: "Square brackets make a list, not a mapping."
						},
						{
							id: "b",
							label: "user = {\"name\": \"Ada\"}",
							correct: true,
							explain: "Curly braces, quoted key, colon, value."
						},
						{
							id: "c",
							label: "user = (\"name\": \"Ada\")",
							correct: false,
							explain: "Parentheses group expressions. They do not make a dict."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l18-read",
						title: "Look up",
						concept: "dict index",
						prompt: "user has name Ada and role lead. Print the name.",
						briefing: "user[\"name\"] — the key is a string, so it needs quotes.",
						example: "print(user[\"name\"])",
						starter: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\n",
						expected: "Ada\n",
						solution: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\nprint(user[\"name\"])",
						hints: [
							"user[\"name\"]",
							"Quotes around the key.",
							"print that lookup."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l18-write",
						title: "Promote",
						concept: "dict assign",
						prompt: "Change user role to architect, then print the role.",
						briefing: "user[\"role\"] = \"architect\" writes the key.",
						example: "user[\"role\"] = \"architect\"\nprint(user[\"role\"])",
						starter: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\n",
						expected: "architect\n",
						solution: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\nuser[\"role\"] = \"architect\"\nprint(user[\"role\"])",
						hints: [
							"user[\"role\"] = \"architect\"",
							"Then print(user[\"role\"])",
							"Match the lowercase spelling."
						]
					}
				}
			]
		},
		{
			id: 19,
			title: "Key Walk",
			job: "Distinguished Engineer",
			difficulty: "Hard",
			description: "for k in dict walks keys. .get returns None instead of crashing.",
			objective: "Count keys, walk them, and safely look up a missing field.",
			rewardCoins: 2800,
			rewardXp: 1100,
			unlockRewardId: "key-walk",
			unlockReward: "Key Walk",
			careerUnlock: "distinguished",
			chapter: "structures",
			steps: [
				{
					type: "brief",
					title: "Missing keys",
					body: "user[\"art\"] raises KeyError if art is not there. user.get(\"art\") returns None instead. for k in scores walks the keys in insertion order. len(scores) counts keys.",
					example: "print(scores.get(\"art\"))\nfor k in scores:\n    print(k)"
				},
				{
					type: "code",
					challenge: {
						id: "l19-len-get",
						title: "Safe lookup",
						concept: "len + get",
						prompt: "Print how many keys scores has, then print scores.get(\"art\") — that key is missing.",
						briefing: "Missing get returns None, which print shows as None.",
						example: "print(len(scores))\nprint(scores.get(\"art\"))",
						starter: "scores = {\"math\": 90, \"code\": 80}\n",
						expected: "2\nNone\n",
						solution: "scores = {\"math\": 90, \"code\": 80}\nprint(len(scores))\nprint(scores.get(\"art\"))",
						hints: [
							"print(len(scores))",
							"print(scores.get(\"art\"))",
							"None has a capital N."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l19-keys",
						title: "Walk keys",
						concept: "for in dict",
						prompt: "Loop through scores and print each key on its own line.",
						briefing: "for k in scores: prints math then code — insertion order.",
						example: "for k in scores:\n    print(k)",
						starter: "scores = {\"math\": 90, \"code\": 80}\n",
						expected: "math\ncode\n",
						solution: "scores = {\"math\": 90, \"code\": 80}\nfor k in scores:\n    print(k)",
						hints: [
							"for k in scores:",
							"print(k)",
							"Do not print the values in this task."
						]
					}
				}
			]
		},
		{
			id: 20,
			title: "Roster Intel",
			job: "Fellow",
			difficulty: "Hard",
			description: "Filter a dictionary of people by their scores.",
			objective: "Print names whose score is at least 80.",
			rewardCoins: 3e3,
			rewardXp: 1200,
			unlockRewardId: "roster-intel",
			unlockReward: "Roster Intel",
			careerUnlock: "distinguished",
			chapter: "structures",
			steps: [
				{
					type: "brief",
					title: "Key then value",
					body: "for name in team: gives keys. team[name] is the score. Combine with if to keep a shortlist. This is how live rosters are queried.",
					example: "for name in team:\n    if team[name] >= 80:\n        print(name)"
				},
				{
					type: "choice",
					concept: "in on dict",
					question: "What does \"Lin\" in team check?",
					options: [
						{
							id: "a",
							label: "Whether any score equals the text Lin",
							correct: false,
							explain: "in on a dict checks keys, not values."
						},
						{
							id: "b",
							label: "Whether Lin is a key in the dictionary",
							correct: true,
							explain: "\"Lin\" in team is True if that name exists as a key."
						},
						{
							id: "c",
							label: "Whether the dict is named Lin",
							correct: false,
							explain: "The dict is named team. in looks inside it."
						}
					]
				},
				{
					type: "code",
					challenge: {
						id: "l20-filter",
						title: "Clearance list",
						concept: "dict + if",
						prompt: "team maps names to scores. Print every name whose score is at least 80, each on its own line, in dictionary order.",
						briefing: "Ada 90 and Kai 88 pass. Lin 70 does not.",
						example: "for name in team:\n    if team[name] >= 80:\n        print(name)",
						starter: "team = {\"Ada\": 90, \"Lin\": 70, \"Kai\": 88}\n",
						expected: "Ada\nKai\n",
						solution: "team = {\"Ada\": 90, \"Lin\": 70, \"Kai\": 88}\nfor name in team:\n    if team[name] >= 80:\n        print(name)",
						hints: [
							"for name in team:",
							"if team[name] >= 80:",
							"print(name)"
						]
					}
				}
			]
		},
		{
			id: 21,
			title: "Dual Params",
			job: "Fellow",
			difficulty: "Medium / Hard",
			description: "A function can take more than one input.",
			objective: "Build a tag and compute an area.",
			rewardCoins: 3200,
			rewardXp: 1300,
			unlockRewardId: "dual-params",
			unlockReward: "Dual Params",
			careerUnlock: "distinguished",
			chapter: "mastery",
			steps: [
				{
					type: "brief",
					title: "Order of arguments",
					body: "def tag(role, name): has two parameters. tag(\"Lead\", \"Ada\") sends Lead into role and Ada into name — order matches. return sends a value back; print is still separate.",
					example: "def tag(role, name):\n    return role + \": \" + name\nprint(tag(\"Lead\", \"Ada\"))"
				},
				{
					type: "code",
					challenge: {
						id: "l21-tag",
						title: "Name tag",
						concept: "two parameters",
						prompt: "Write tag(role, name) so it returns role, then \": \", then name. Print tag(\"Lead\", \"Ada\").",
						briefing: "Join three strings. Remember the colon and space.",
						example: "return role + \": \" + name",
						starter: "def tag(role, name):\n    return name\n",
						expected: "Lead: Ada\n",
						solution: "def tag(role, name):\n    return role + \": \" + name\nprint(tag(\"Lead\", \"Ada\"))",
						hints: [
							"return role + \": \" + name",
							"Colon then space inside the string.",
							"print(tag(\"Lead\", \"Ada\"))"
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l21-area",
						title: "Floor plan",
						concept: "two parameters",
						prompt: "Write area(w, h) that returns w times h. Print area(4, 5).",
						briefing: "Numbers multiply with *. Return the product, then print the call.",
						example: "def area(w, h):\n    return w * h",
						starter: "def area(w, h):\n    return 0\n",
						expected: "20\n",
						solution: "def area(w, h):\n    return w * h\nprint(area(4, 5))",
						hints: [
							"return w * h",
							"print(area(4, 5))",
							"The answer is 20."
						]
					}
				}
			]
		},
		{
			id: 22,
			title: "Return Path",
			job: "Fellow",
			difficulty: "Hard",
			description: "A function can return from more than one branch.",
			objective: "Grade two scores with one function.",
			rewardCoins: 3400,
			rewardXp: 1400,
			unlockRewardId: "return-path",
			unlockReward: "Return Path",
			careerUnlock: "fellow",
			chapter: "mastery",
			steps: [{
				type: "brief",
				title: "return exits immediately",
				body: "When a function hits return, it stops. You can return from the if branch and from the else branch. Call the function twice to test both paths.",
				example: "def grade(n):\n    if n >= 70:\n        return \"PASS\"\n    return \"RETRY\""
			}, {
				type: "code",
				challenge: {
					id: "l22-grade",
					title: "Two calls",
					concept: "return branches",
					prompt: "Write grade(n) that returns PASS if n is at least 70, otherwise RETRY. Print grade(70) and grade(40), each on its own line.",
					briefing: "Two print calls after the function. 70 is PASS. 40 is RETRY.",
					example: "print(grade(70))\nprint(grade(40))",
					starter: "def grade(n):\n    return \"RETRY\"\n",
					expected: "PASS\nRETRY\n",
					solution: "def grade(n):\n    if n >= 70:\n        return \"PASS\"\n    return \"RETRY\"\nprint(grade(70))\nprint(grade(40))",
					hints: [
						"if n >= 70: return \"PASS\"",
						"return \"RETRY\" after the if",
						"Print both calls."
					]
				}
			}]
		},
		{
			id: 23,
			title: "Join Forge",
			job: "Python Master",
			difficulty: "Hard",
			description: "split turns text into a list. join turns a list into text.",
			objective: "Join with dashes. Split on commas.",
			rewardCoins: 3600,
			rewardXp: 1600,
			unlockRewardId: "join-forge",
			unlockReward: "Join Forge",
			careerUnlock: "fellow",
			chapter: "mastery",
			steps: [
				{
					type: "brief",
					title: "The separator is on the left",
					body: "\"-\".join(parts) puts a dash between each string in the list. text.split(\",\") cuts on commas and returns a list. join fails if a list item is a number — convert with str first in real work.",
					example: "print(\"-\".join([\"plan\", \"code\", \"ship\"]))\nprint(\"a,b,c\".split(\",\"))"
				},
				{
					type: "code",
					challenge: {
						id: "l23-join",
						title: "Pipeline",
						concept: "join",
						prompt: "parts is plan, code, ship. Print them joined with dashes, no extra spaces.",
						briefing: "The string before the dot is the glue.",
						example: "print(\"-\".join(parts))",
						starter: "parts = [\"plan\", \"code\", \"ship\"]\n",
						expected: "plan-code-ship\n",
						solution: "parts = [\"plan\", \"code\", \"ship\"]\nprint(\"-\".join(parts))",
						hints: [
							"\"-\".join(parts)",
							"Print that call.",
							"No spaces around the dashes."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l23-split",
						title: "Cut the csv",
						concept: "split",
						prompt: "text is a,b,c. Split on the comma and print the list.",
						briefing: "split returns a list of strings. print shows brackets and quotes.",
						example: "print(text.split(\",\"))",
						starter: "text = \"a,b,c\"\n",
						expected: "['a', 'b', 'c']\n",
						solution: "text = \"a,b,c\"\nprint(text.split(\",\"))",
						hints: [
							"text.split(\",\")",
							"The separator is a comma string.",
							"print the result."
						]
					}
				}
			]
		},
		{
			id: 24,
			title: "Sort Engine",
			job: "Python Master",
			difficulty: "Hard",
			description: "sorted returns a new list. min, max, and your own mean.",
			objective: "Order a list, then write a mean function using //.",
			rewardCoins: 4e3,
			rewardXp: 1800,
			unlockRewardId: "sort-engine",
			unlockReward: "Sort Engine",
			careerUnlock: "fellow",
			chapter: "mastery",
			steps: [
				{
					type: "brief",
					title: "sorted vs sort",
					body: "sorted(nums) returns a new ordered list and leaves nums alone. nums.sort() changes nums and returns None. // is integer division — 60 // 3 is 20, not 20.0.",
					example: "print(sorted([5, 1, 4]))\nprint(sum(xs) // len(xs))"
				},
				{
					type: "code",
					challenge: {
						id: "l24-sorted",
						title: "In order",
						concept: "sorted + min/max",
						prompt: "nums is [5, 1, 4]. Print the sorted list, then the max, then the min, each on its own line.",
						briefing: "sorted, max, and min are built-in functions — not methods on this task.",
						example: "print(sorted(nums))\nprint(max(nums))\nprint(min(nums))",
						starter: "nums = [5, 1, 4]\n",
						expected: "[1, 4, 5]\n5\n1\n",
						solution: "nums = [5, 1, 4]\nprint(sorted(nums))\nprint(max(nums))\nprint(min(nums))",
						hints: [
							"print(sorted(nums))",
							"print(max(nums))",
							"print(min(nums))"
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l24-mean",
						title: "Integer mean",
						concept: "functions + //",
						prompt: "Write mean(xs) that returns the integer average: sum divided by length using //. Print mean([10, 20, 30]).",
						briefing: "sum(xs) // len(xs). Integer division drops the decimal.",
						example: "def mean(xs):\n    return sum(xs) // len(xs)",
						starter: "def mean(xs):\n    return 0\n",
						expected: "20\n",
						solution: "def mean(xs):\n    return sum(xs) // len(xs)\nprint(mean([10, 20, 30]))",
						hints: [
							"return sum(xs) // len(xs)",
							"Use // not /",
							"print(mean([10, 20, 30]))"
						]
					}
				}
			]
		},
		{
			id: 25,
			title: "Python Mastery",
			job: "Python Master",
			difficulty: "Expert",
			description: "Mid-course championship. Functions, dictionaries, and a written report — under the clock.",
			objective: "Clear every stage. Claim the Master's Apex. Then the advanced tracks open.",
			rewardCoins: 8e3,
			rewardXp: 2500,
			unlockRewardId: "master-apex",
			unlockReward: "Master's Apex",
			careerUnlock: "master",
			chapter: "mastery",
			timeLimitSec: 180,
			championship: true,
			steps: [
				{
					type: "brief",
					title: "Everything you learned",
					body: "Stage 1 packages a decision in a function. Stage 2 filters a live roster. Stage 3 writes a text report from numbers. Same rules as always: colons, indents, quotes, and print.",
					example: "def label(score):\n    if score >= 70:\n        return \"PASS\"\n    return \"RETRY\""
				},
				{
					type: "code",
					challenge: {
						id: "l25-label",
						title: "Stage 1 — Stamp",
						concept: "functions + if",
						prompt: "Write label(score) that returns PASS if score is at least 70, else RETRY. Print label(88) then label(40).",
						briefing: "Two returns. Two calls. Two lines of output.",
						example: "print(label(88))\nprint(label(40))",
						starter: "def label(score):\n    return score\n",
						expected: "PASS\nRETRY\n",
						solution: "def label(score):\n    if score >= 70:\n        return \"PASS\"\n    return \"RETRY\"\nprint(label(88))\nprint(label(40))",
						hints: [
							"if score >= 70: return \"PASS\"",
							"return \"RETRY\"",
							"Print both calls."
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l25-roster",
						title: "Stage 2 — Shortlist",
						concept: "dict filter",
						prompt: "scores maps names to exam results. Print names with a score of at least 70, each on its own line, in dictionary order.",
						briefing: "Ada 90 and Kai 70 pass. Lin 55 does not.",
						example: "for name in scores:\n    if scores[name] >= 70:\n        print(name)",
						starter: "scores = {\"Ada\": 90, \"Lin\": 55, \"Kai\": 70}\n",
						expected: "Ada\nKai\n",
						solution: "scores = {\"Ada\": 90, \"Lin\": 55, \"Kai\": 70}\nfor name in scores:\n    if scores[name] >= 70:\n        print(name)",
						hints: [
							"for name in scores:",
							"if scores[name] >= 70:",
							"print(name)"
						]
					}
				},
				{
					type: "code",
					challenge: {
						id: "l25-report",
						title: "Stage 3 — Report",
						concept: "str + builtins",
						prompt: "Write report(nums) that returns the text sum= then the sum, then a space, then n= then the length. Print report([10, 20, 30]).",
						briefing: "Join strings with +. Convert numbers with str(). Example shape: sum=60 n=3",
						example: "return \"sum=\" + str(sum(nums)) + \" n=\" + str(len(nums))",
						starter: "def report(nums):\n    return \"\"\n",
						expected: "sum=60 n=3\n",
						solution: "def report(nums):\n    return \"sum=\" + str(sum(nums)) + \" n=\" + str(len(nums))\nprint(report([10, 20, 30]))",
						hints: [
							"str(sum(nums)) and str(len(nums))",
							"Space before n=",
							"print(report([10, 20, 30]))"
						]
					}
				}
			]
		}
	],
	...LEVELS_PLUS,
	...LEVELS_PRO
];
var CHAPTERS = [
	{
		id: "foundations",
		title: "Track 1 · Foundations",
		blurb: "Print, store, decide, loop, ship a function."
	},
	{
		id: "strings",
		title: "Track 2 · Strings",
		blurb: "Text, case, characters, and joining words."
	},
	{
		id: "logic",
		title: "Track 3 · Logic",
		blurb: "Booleans, comparisons, and branching paths."
	},
	{
		id: "loops",
		title: "Track 4 · Loops",
		blurb: "while, range, nested repetition."
	},
	{
		id: "structures",
		title: "Track 5 · Data",
		blurb: "Indexes, slices, dictionaries, live records."
	},
	{
		id: "mastery",
		title: "Track 6 · Mastery",
		blurb: "Functions, reports, and the mid-course championship."
	},
	{
		id: "algorithms",
		title: "Track 7 · Algorithms",
		blurb: "Remainders, membership, reverse, and counting tricks."
	},
	{
		id: "fluency",
		title: "Track 8 · Fluency",
		blurb: "Methods, unpacking, nested data, and range steps."
	},
	{
		id: "studio",
		title: "Track 9 · Studio",
		blurb: "Helpers, reports, and the Grandmaster checkpoint."
	},
	{
		id: "patterns",
		title: "Track 10 · Patterns",
		blurb: "zip, any/all, ternary, swap, FizzBuzz, palindrome."
	},
	{
		id: "craft",
		title: "Track 11 · Craft",
		blurb: "Classic algorithms: factorial, search, primes, GCD."
	},
	{
		id: "legend",
		title: "Track 12 · Legend",
		blurb: "Ciphers, inventories, pipelines, and the Immortal championship."
	}
];
var CAREERS = [
	{
		id: "rookie",
		title: "Rookie",
		rank: 0,
		blurb: "You just walked in. Learn how Python talks."
	},
	{
		id: "trainee",
		title: "Trainee",
		rank: 1,
		blurb: "Hired. You can print and store values."
	},
	{
		id: "junior",
		title: "Junior Associate",
		rank: 2,
		blurb: "You make decisions with data."
	},
	{
		id: "specialist",
		title: "Specialist",
		rank: 3,
		blurb: "You write conditions under pressure."
	},
	{
		id: "manager",
		title: "Manager",
		rank: 4,
		blurb: "You command lists and loops."
	},
	{
		id: "elite",
		title: "Elite Professional",
		rank: 5,
		blurb: "You ship functions. Mid-career championship cleared."
	},
	{
		id: "senior",
		title: "Senior Engineer",
		rank: 6,
		blurb: "Strings and text pipelines are second nature."
	},
	{
		id: "staff",
		title: "Staff Engineer",
		rank: 7,
		blurb: "You design branching logic that holds."
	},
	{
		id: "lead",
		title: "Lead Engineer",
		rank: 8,
		blurb: "You keep loops honest under a clock."
	},
	{
		id: "principal",
		title: "Principal Engineer",
		rank: 9,
		blurb: "Lists, indexes, and slices live in your hands."
	},
	{
		id: "architect",
		title: "Architect",
		rank: 10,
		blurb: "You model records with dictionaries."
	},
	{
		id: "distinguished",
		title: "Distinguished Engineer",
		rank: 11,
		blurb: "You query nested data without flinching."
	},
	{
		id: "fellow",
		title: "Fellow",
		rank: 12,
		blurb: "You compose functions into tools."
	},
	{
		id: "master",
		title: "Python Master",
		rank: 13,
		blurb: "Mid-course crown. The next tracks go deeper."
	},
	{
		id: "legend",
		title: "Legend",
		rank: 14,
		blurb: "You see patterns in operators and membership."
	},
	{
		id: "oracle",
		title: "Oracle",
		rank: 15,
		blurb: "String and list methods answer on command."
	},
	{
		id: "sage",
		title: "Sage",
		rank: 16,
		blurb: "You unpack pairs and walk nested structure."
	},
	{
		id: "director",
		title: "Director",
		rank: 17,
		blurb: "You compose helpers into a studio pipeline."
	},
	{
		id: "grandmaster",
		title: "Grandmaster",
		rank: 18,
		blurb: "Grandmaster checkpoint. The next tracks go deeper."
	},
	{
		id: "virtuoso",
		title: "Virtuoso",
		rank: 19,
		blurb: "You pair sequences and test truth in bulk."
	},
	{
		id: "artisan",
		title: "Artisan",
		rank: 20,
		blurb: "Ternary, swap, reverse — tools that fit in one line."
	},
	{
		id: "titan",
		title: "Titan",
		rank: 21,
		blurb: "You write the classic loops: factorial, search, flatten."
	},
	{
		id: "sovereign",
		title: "Sovereign",
		rank: 22,
		blurb: "Craft championship cleared. Numbers yield to you."
	},
	{
		id: "sentinel",
		title: "Sentinel",
		rank: 23,
		blurb: "Characters, ciphers, and frequency tables."
	},
	{
		id: "mythic",
		title: "Mythic",
		rank: 24,
		blurb: "You compose helpers into a living pipeline."
	},
	{
		id: "immortal",
		title: "Immortal",
		rank: 25,
		blurb: "Full Python career cleared. You teach the language by writing it."
	}
];
var REWARDS = [
	{
		id: "trainee-badge",
		name: "Trainee Badge",
		levelId: 1,
		blurb: "Proof you shipped your first program."
	},
	{
		id: "junior-desk",
		name: "Junior Desk",
		levelId: 2,
		blurb: "A real workstation. Variables live here."
	},
	{
		id: "specialist-outfit",
		name: "Specialist Outfit",
		levelId: 3,
		blurb: "Kit for timed missions."
	},
	{
		id: "executive-office",
		name: "Executive Office",
		levelId: 4,
		blurb: "Corner office. Lists on the glass."
	},
	{
		id: "m8-apex",
		name: "M8 Apex",
		levelId: 5,
		blurb: "In-game championship grand tourer. Not a real-world prize.",
		featured: true
	},
	{
		id: "string-keys",
		name: "String Keys",
		levelId: 6,
		blurb: "Access badge for the text lab."
	},
	{
		id: "case-file",
		name: "Case File",
		levelId: 7,
		blurb: "upper, lower, and strip — filed."
	},
	{
		id: "char-lens",
		name: "Character Lens",
		levelId: 8,
		blurb: "See every letter. Indexes start at 0."
	},
	{
		id: "logic-core",
		name: "Logic Core",
		levelId: 9,
		blurb: "True, False, and, or, not."
	},
	{
		id: "branch-map",
		name: "Branch Map",
		levelId: 10,
		blurb: "elif chains under a ticking clock."
	},
	{
		id: "while-engine",
		name: "While Engine",
		levelId: 11,
		blurb: "Loops that know when to stop."
	},
	{
		id: "range-rail",
		name: "Range Rail",
		levelId: 12,
		blurb: "0, 1, 2… counted without a handwritten list."
	},
	{
		id: "nest-grid",
		name: "Nest Grid",
		levelId: 13,
		blurb: "Loops inside loops. A grid of answers."
	},
	{
		id: "index-badge",
		name: "Index Badge",
		levelId: 14,
		blurb: "Replace the item at a position."
	},
	{
		id: "append-bay",
		name: "Append Bay",
		levelId: 15,
		blurb: "Grow a list. append returns None."
	},
	{
		id: "slice-glass",
		name: "Slice Glass",
		levelId: 16,
		blurb: "Take a window: start:end."
	},
	{
		id: "break-seal",
		name: "Break Seal",
		levelId: 17,
		blurb: "Leave a loop early. Skip with continue."
	},
	{
		id: "record-vault",
		name: "Record Vault",
		levelId: 18,
		blurb: "Key → value. Your first dictionary."
	},
	{
		id: "key-walk",
		name: "Key Walk",
		levelId: 19,
		blurb: "Walk keys. .get never explodes."
	},
	{
		id: "roster-intel",
		name: "Roster Intel",
		levelId: 20,
		blurb: "Filter a living record of people."
	},
	{
		id: "dual-params",
		name: "Dual Params",
		levelId: 21,
		blurb: "Functions that take more than one input."
	},
	{
		id: "return-path",
		name: "Return Path",
		levelId: 22,
		blurb: "Two returns. One function. Clean exits."
	},
	{
		id: "join-forge",
		name: "Join Forge",
		levelId: 23,
		blurb: "split and join — text as structure."
	},
	{
		id: "sort-engine",
		name: "Sort Engine",
		levelId: 24,
		blurb: "Order, min, max, and a mean you wrote."
	},
	{
		id: "master-apex",
		name: "Master's Apex",
		levelId: 25,
		blurb: "In-game mastery crown. Not a real-world prize.",
		featured: true
	},
	{
		id: "remainder-seal",
		name: "Remainder Seal",
		levelId: 26,
		blurb: "% tells you what is left after dividing."
	},
	{
		id: "power-cell",
		name: "Power Cell",
		levelId: 27,
		blurb: "** raises. // divides and drops the decimal."
	},
	{
		id: "repeat-tape",
		name: "Repeat Tape",
		levelId: 28,
		blurb: "A string times a number repeats the signal."
	},
	{
		id: "member-pass",
		name: "Member Pass",
		levelId: 29,
		blurb: "in and not in — present or absent."
	},
	{
		id: "chain-gate",
		name: "Chain Gate",
		levelId: 30,
		blurb: "1 < x < 10 reads like math class."
	},
	{
		id: "none-watch",
		name: "None Watch",
		levelId: 31,
		blurb: "None is the value that means no value."
	},
	{
		id: "truth-lens",
		name: "Truth Lens",
		levelId: 32,
		blurb: "Empty lists and empty strings are False."
	},
	{
		id: "swap-file",
		name: "Swap File",
		levelId: 33,
		blurb: "replace rewrites. find locates."
	},
	{
		id: "prefix-badge",
		name: "Prefix Badge",
		levelId: 34,
		blurb: "startswith and endswith check the edges."
	},
	{
		id: "digit-gate",
		name: "Digit Gate",
		levelId: 35,
		blurb: "isdigit and isalpha classify characters."
	},
	{
		id: "pop-stack",
		name: "Pop Stack",
		levelId: 36,
		blurb: "pop takes the last. insert places anywhere."
	},
	{
		id: "mutate-rack",
		name: "Mutate Rack",
		levelId: 37,
		blurb: "sort and reverse change the list in place."
	},
	{
		id: "count-desk",
		name: "Count Desk",
		levelId: 38,
		blurb: "count tells you how many times it appears."
	},
	{
		id: "enum-walk",
		name: "Enum Walk",
		levelId: 39,
		blurb: "enumerate hands you the index and the item."
	},
	{
		id: "pair-unpack",
		name: "Pair Unpack",
		levelId: 40,
		blurb: "for k, v in items() — two names, one pair."
	},
	{
		id: "grid-key",
		name: "Grid Key",
		levelId: 41,
		blurb: "grid[row][col] — a list inside a list."
	},
	{
		id: "nested-vault",
		name: "Nested Vault",
		levelId: 42,
		blurb: "A dictionary that holds dictionaries."
	},
	{
		id: "step-rail",
		name: "Step Rail",
		levelId: 43,
		blurb: "range can skip: 0, 2, 4, 6."
	},
	{
		id: "mirror-glass",
		name: "Mirror Glass",
		levelId: 44,
		blurb: "[::-1] reverses a string or a list."
	},
	{
		id: "accum-forge",
		name: "Accum Forge",
		levelId: 45,
		blurb: "Build a string one piece at a time."
	},
	{
		id: "helper-link",
		name: "Helper Link",
		levelId: 46,
		blurb: "One function calls another."
	},
	{
		id: "studio-report",
		name: "Studio Report",
		levelId: 47,
		blurb: "A function that reads a roster and writes a line."
	},
	{
		id: "even-filter",
		name: "Even Filter",
		levelId: 48,
		blurb: "Keep the evens. Discard the odds."
	},
	{
		id: "default-key",
		name: "Default Key",
		levelId: 49,
		blurb: "get(key, fallback) never crashes."
	},
	{
		id: "grandmaster-crown",
		name: "Grandmaster Crown",
		levelId: 50,
		blurb: "In-game grandmaster seal. The course continues after this.",
		featured: true
	},
	{
		id: "zip-rail",
		name: "Zip Rail",
		levelId: 51,
		blurb: "Walk two lists in lockstep."
	},
	{
		id: "truth-bulk",
		name: "Truth Bulk",
		levelId: 52,
		blurb: "any and all — one question for a whole list."
	},
	{
		id: "round-dial",
		name: "Round Dial",
		levelId: 53,
		blurb: "round and float — numbers that were text."
	},
	{
		id: "bool-gate",
		name: "Bool Gate",
		levelId: 54,
		blurb: "bool() names the truth you already felt."
	},
	{
		id: "none-is",
		name: "None Identity",
		levelId: 55,
		blurb: "is None — identity, not equality."
	},
	{
		id: "ternary-key",
		name: "Ternary Key",
		levelId: 56,
		blurb: "A one-line if that returns a value."
	},
	{
		id: "swap-hands",
		name: "Swap Hands",
		levelId: 57,
		blurb: "a, b = b, a — no third box required."
	},
	{
		id: "repeat-rack",
		name: "Repeat Rack",
		levelId: 58,
		blurb: "A list times a number fills the rack."
	},
	{
		id: "reverse-walk",
		name: "Reverse Walk",
		levelId: 59,
		blurb: "reversed() walks backwards without mutating."
	},
	{
		id: "fizz-seal",
		name: "Fizz Seal",
		levelId: 60,
		blurb: "The classic remainder song: Fizz, Buzz."
	},
	{
		id: "clamp-band",
		name: "Clamp Band",
		levelId: 61,
		blurb: "Keep a number inside a band."
	},
	{
		id: "mirror-test",
		name: "Mirror Test",
		levelId: 62,
		blurb: "A palindrome reads the same backwards."
	},
	{
		id: "fact-forge",
		name: "Fact Forge",
		levelId: 63,
		blurb: "Multiply down from n. Factorial."
	},
	{
		id: "fib-spiral",
		name: "Fib Spiral",
		levelId: 64,
		blurb: "Each number is the two before it, added."
	},
	{
		id: "digit-well",
		name: "Digit Well",
		levelId: 65,
		blurb: "% 10 peels a digit. // 10 shortens the number."
	},
	{
		id: "vowel-net",
		name: "Vowel Net",
		levelId: 66,
		blurb: "Count the letters that sing."
	},
	{
		id: "search-pin",
		name: "Search Pin",
		levelId: 67,
		blurb: "Walk until you find it. Return the index."
	},
	{
		id: "unique-press",
		name: "Unique Press",
		levelId: 68,
		blurb: "Keep the first of each. Drop repeats."
	},
	{
		id: "flat-grid",
		name: "Flat Grid",
		levelId: 69,
		blurb: "A list of lists becomes one list."
	},
	{
		id: "min-hand",
		name: "Min Hand",
		levelId: 70,
		blurb: "The smallest, found with a loop — no min()."
	},
	{
		id: "run-total",
		name: "Run Total",
		levelId: 71,
		blurb: "Print the sum after every step."
	},
	{
		id: "prime-gate",
		name: "Prime Gate",
		levelId: 72,
		blurb: "Only divisible by 1 and itself."
	},
	{
		id: "gcd-lock",
		name: "GCD Lock",
		levelId: 73,
		blurb: "Euclid's remainder loop."
	},
	{
		id: "leap-dial",
		name: "Leap Dial",
		levelId: 74,
		blurb: "400, 100, 4 — the calendar rules."
	},
	{
		id: "sovereign-seal",
		name: "Sovereign Seal",
		levelId: 75,
		blurb: "In-game craft championship. Not a real-world prize.",
		featured: true
	},
	{
		id: "collatz-path",
		name: "Collatz Path",
		levelId: 76,
		blurb: "Halve evens. 3n+1 odds. Count the steps."
	},
	{
		id: "power-loop",
		name: "Power Loop",
		levelId: 77,
		blurb: "Raise without **. Multiply in a loop."
	},
	{
		id: "odd-bin",
		name: "Odd Bin",
		levelId: 78,
		blurb: "Keep the odds. A new list, not a mutation."
	},
	{
		id: "word-span",
		name: "Word Span",
		levelId: 79,
		blurb: "len of every word in a line-up."
	},
	{
		id: "title-press",
		name: "Title Press",
		levelId: 80,
		blurb: "strip then title — a two-method press."
	},
	{
		id: "ord-key",
		name: "Ord Key",
		levelId: 81,
		blurb: "ord and chr — letters as numbers."
	},
	{
		id: "caesar-shift",
		name: "Caesar Shift",
		levelId: 82,
		blurb: "Move every letter one place forward."
	},
	{
		id: "case-gate",
		name: "Case Gate",
		levelId: 83,
		blurb: "isupper, islower, isspace — classify a character."
	},
	{
		id: "freq-table",
		name: "Freq Table",
		levelId: 84,
		blurb: "How many times each letter appears."
	},
	{
		id: "anagram-seal",
		name: "Anagram Seal",
		levelId: 85,
		blurb: "Same letters, new order. sorted decides."
	},
	{
		id: "merge-unique",
		name: "Merge Unique",
		levelId: 86,
		blurb: "Two lists. One sequence. No duplicates."
	},
	{
		id: "stock-ledger",
		name: "Stock Ledger",
		levelId: 87,
		blurb: "Add to a key. Create a missing one."
	},
	{
		id: "update-kit",
		name: "Update Kit",
		levelId: 88,
		blurb: "update merges. setdefault plants a default."
	},
	{
		id: "mean-desk",
		name: "Mean Desk",
		levelId: 89,
		blurb: "A mean you wrote with // and len."
	},
	{
		id: "nested-pass",
		name: "Nested Pass",
		levelId: 90,
		blurb: "Walk records. Print the ones that pass."
	},
	{
		id: "pair-sheet",
		name: "Pair Sheet",
		levelId: 91,
		blurb: "zip keys to values and print a sheet."
	},
	{
		id: "histo-bar",
		name: "Histo Bar",
		levelId: 92,
		blurb: "Stars for counts. A tiny chart."
	},
	{
		id: "rotate-ring",
		name: "Rotate Ring",
		levelId: 93,
		blurb: "pop the front. append it. The ring turns."
	},
	{
		id: "window-sum",
		name: "Window Sum",
		levelId: 94,
		blurb: "Add each neighbor pair as you walk."
	},
	{
		id: "clock-mod",
		name: "Clock Mod",
		levelId: 95,
		blurb: "% 24 wraps the hours."
	},
	{
		id: "temp-forge",
		name: "Temp Forge",
		levelId: 96,
		blurb: "C to F with integer math."
	},
	{
		id: "bit-tape",
		name: "Bit Tape",
		levelId: 97,
		blurb: "Odd is 1. Even is 0. A tape of bits."
	},
	{
		id: "ticket-bay",
		name: "Ticket Bay",
		levelId: 98,
		blurb: "Filter open tickets from a list of records."
	},
	{
		id: "pipe-link",
		name: "Pipe Link",
		levelId: 99,
		blurb: "One helper feeds another."
	},
	{
		id: "immortal-crown",
		name: "Immortal Crown",
		levelId: 100,
		blurb: "In-game career finale. Not a real-world prize.",
		featured: true
	}
];
function careerById(id) {
	return CAREERS.find((c) => c.id === id) ?? CAREERS[0];
}
function nextCareer(id) {
	const cur = careerById(id);
	return CAREERS.find((c) => c.rank === cur.rank + 1) ?? null;
}
function rewardById(id) {
	return REWARDS.find((r) => r.id === id);
}
/** Cumulative XP required to sit at a player level. Level 1 starts at 0. */
var XP_THRESHOLDS = [
	0,
	100,
	250,
	500,
	900,
	1650,
	2500,
	3600,
	5e3,
	6800,
	9e3,
	11600,
	14800,
	18600,
	23e3,
	28e3,
	34e3,
	41e3,
	49e3,
	58e3,
	68e3,
	79e3,
	91e3,
	104e3,
	118e3,
	133e3
];
function playerLevelFromXp(xp) {
	let level = 1;
	for (let i = 1; i < XP_THRESHOLDS.length; i++) if (xp >= XP_THRESHOLDS[i]) level = i + 1;
	else break;
	const last = XP_THRESHOLDS[XP_THRESHOLDS.length - 1];
	if (xp >= last) level = XP_THRESHOLDS.length + Math.floor((xp - last) / 1200);
	return level;
}
function xpProgress(xp) {
	const level = playerLevelFromXp(xp);
	const lastIdx = XP_THRESHOLDS.length - 1;
	if (level <= lastIdx) {
		const start = XP_THRESHOLDS[level - 1] ?? 0;
		const next = XP_THRESHOLDS[level] ?? start + 1e3;
		const current = xp - start;
		const needed = next - start;
		return {
			level,
			current,
			needed,
			ratio: needed === 0 ? 1 : Math.min(1, current / needed)
		};
	}
	const into = (xp - XP_THRESHOLDS[lastIdx]) % 1200;
	return {
		level,
		current: into,
		needed: 1200,
		ratio: into / 1200
	};
}
function levelById(id) {
	return LEVELS.find((l) => l.id === id);
}
function nextLevelId(completed) {
	for (const l of LEVELS) if (!completed.includes(l.id)) return l.id;
	return LEVELS[LEVELS.length - 1].id;
}
function isLevelUnlocked(id, completed) {
	if (id <= 1) return true;
	return completed.includes(id - 1);
}
function codeStepCount(level) {
	return level.steps.filter((s) => s.type === "code").length;
}
var GIG_LANES = [
	{
		id: "starter",
		title: "Starter desk",
		blurb: "Print, fix a typo, ship a one-liner.",
		unlockAfter: 1
	},
	{
		id: "numbers",
		title: "Numbers desk",
		blurb: "Bills, wages, leftover seats.",
		unlockAfter: 3
	},
	{
		id: "logic",
		title: "Logic desk",
		blurb: "Pass, fail, warn, convert.",
		unlockAfter: 5
	},
	{
		id: "text",
		title: "Text desk",
		blurb: "Names, tags, and clean strings.",
		unlockAfter: 8
	},
	{
		id: "loops",
		title: "Loops desk",
		blurb: "Count, filter, repeat.",
		unlockAfter: 11
	},
	{
		id: "lists",
		title: "Lists desk",
		blurb: "Menus, tickets, top scores.",
		unlockAfter: 15
	},
	{
		id: "records",
		title: "Records desk",
		blurb: "Lookups, reports, tiny APIs.",
		unlockAfter: 20
	},
	{
		id: "methods",
		title: "Methods desk",
		blurb: "Split, replace, classify.",
		unlockAfter: 30
	},
	{
		id: "studio",
		title: "Studio desk",
		blurb: "Zip, Fizz, clamp, unique.",
		unlockAfter: 50
	},
	{
		id: "craft",
		title: "Craft desk",
		blurb: "Pipelines, ciphers, nested data.",
		unlockAfter: 75
	}
];
function ch(partial) {
	return partial;
}
function gig(def) {
	return def;
}
var GIGS = [
	gig({
		id: "gig-cafe-open",
		title: "Cafe chalkboard",
		client: "Mina Cho",
		company: "Northshore Cafe",
		category: "utility",
		lane: "starter",
		unlockAfter: 1,
		difficulty: "Easy",
		pay: 220,
		xp: 40,
		skills: ["print()", "strings"],
		summary: "Print the morning sign exactly.",
		brief: "Mina needs the board to show OPEN 8AM — capitals, space, no extra words. Simulated cafe, simulated pay.",
		challenge: ch({
			id: "gig-cafe-open",
			title: "Print the sign",
			concept: "print() and strings",
			prompt: "Print exactly: OPEN 8AM",
			briefing: "Quotes wrap the message. print() shows it without the quotes.",
			example: "print(\"OPEN 8AM\")",
			starter: "# Print the chalkboard line.\n",
			expected: "OPEN 8AM\n",
			solution: "print(\"OPEN 8AM\")",
			hints: [
				"Use print() with parentheses.",
				"Put OPEN 8AM inside quotes.",
				"Match capitals and the space."
			]
		})
	}),
	gig({
		id: "gig-hello-bug",
		title: "Fix the greeting bug",
		client: "Jules Adeyemi",
		company: "Harbor Helpdesk",
		category: "bugfix",
		lane: "starter",
		unlockAfter: 1,
		difficulty: "Easy",
		pay: 240,
		xp: 45,
		skills: ["debugging", "strings"],
		summary: "Hello prints a NameError. Add quotes.",
		brief: "A trainee shipped print(Hello) without quotes. Python looks for a variable named Hello. Fix it so the screen shows Hello.",
		challenge: ch({
			id: "gig-hello-bug",
			title: "Quotes around the word",
			concept: "NameError vs string",
			prompt: "The starter crashes. Make it print Hello.",
			briefing: "A bare name is a variable. A quoted name is text.",
			example: "print(\"Hello\")",
			starter: "print(Hello)\n",
			expected: "Hello\n",
			solution: "print(\"Hello\")",
			hints: [
				"Hello without quotes is a missing variable.",
				"Wrap Hello in quotes.",
				"print(\"Hello\")"
			]
		})
	}),
	gig({
		id: "gig-sms-hi",
		title: "Welcome SMS",
		client: "Priya Shah",
		company: "Brightlane School",
		category: "utility",
		lane: "starter",
		unlockAfter: 1,
		difficulty: "Easy",
		pay: 200,
		xp: 40,
		skills: ["print()", "punctuation"],
		summary: "Send a one-line welcome text.",
		brief: "Print Hi, Maya — comma and capital M. This is a practice SMS, not a real message to a person.",
		challenge: ch({
			id: "gig-sms-hi",
			title: "One-line text",
			concept: "Exact strings",
			prompt: "Print exactly: Hi, Maya",
			briefing: "Match the comma and the space after it.",
			example: "print(\"Hi, Maya\")",
			starter: "# Type the print line.\n",
			expected: "Hi, Maya\n",
			solution: "print(\"Hi, Maya\")",
			hints: [
				"Include the comma.",
				"Capital M in Maya.",
				"print(\"Hi, Maya\")"
			]
		})
	}),
	gig({
		id: "gig-receipt-head",
		title: "Receipt header",
		client: "Owen Park",
		company: "Drift Market",
		category: "utility",
		lane: "starter",
		unlockAfter: 1,
		difficulty: "Easy",
		pay: 210,
		xp: 40,
		skills: ["print()"],
		summary: "Print the store name on a dummy receipt.",
		brief: "Owen wants the receipt simulator to start with NORTHSHORE in capitals. Not a real register.",
		challenge: ch({
			id: "gig-receipt-head",
			title: "Store name",
			concept: "print()",
			prompt: "Print NORTHSHORE",
			briefing: "One print, all caps, no extra spaces.",
			example: "print(\"NORTHSHORE\")",
			starter: "# Header line.\n",
			expected: "NORTHSHORE\n",
			solution: "print(\"NORTHSHORE\")",
			hints: [
				"All capitals.",
				"No spaces.",
				"print(\"NORTHSHORE\")"
			]
		})
	}),
	gig({
		id: "gig-status-ok",
		title: "Health-check ping",
		client: "Rae Quinn",
		company: "Fieldkit Labs",
		category: "automation",
		lane: "starter",
		unlockAfter: 1,
		difficulty: "Easy",
		pay: 230,
		xp: 45,
		skills: ["print()", "status strings"],
		summary: "A tiny uptime script should print STATUS OK.",
		brief: "Simulated monitor. Print STATUS OK so the dashboard test turns green.",
		challenge: ch({
			id: "gig-status-ok",
			title: "Ping the board",
			concept: "print()",
			prompt: "Print STATUS OK",
			briefing: "Space between the two words. Both caps.",
			example: "print(\"STATUS OK\")",
			starter: "# Status line.\n",
			expected: "STATUS OK\n",
			solution: "print(\"STATUS OK\")",
			hints: [
				"Two words.",
				"STATUS then a space then OK.",
				"print(\"STATUS OK\")"
			]
		})
	}),
	gig({
		id: "gig-tip-math",
		title: "Tip calculator",
		client: "Mina Cho",
		company: "Northshore Cafe",
		category: "utility",
		lane: "numbers",
		unlockAfter: 3,
		difficulty: "Easy",
		pay: 320,
		xp: 55,
		skills: ["variables", "addition"],
		summary: "Bill 50 plus a 5 tip.",
		brief: "Print the total after a $5 tip on a $50 bill. Virtual cafe math — not real money.",
		challenge: ch({
			id: "gig-tip-math",
			title: "Add the tip",
			concept: "variables and +",
			prompt: "Store bill 50 and tip 5. Print bill + tip.",
			briefing: "Names hold numbers. + adds them. print shows the total.",
			example: "bill = 50\ntip = 5\nprint(bill + tip)",
			starter: "bill = 50\ntip = 5\n",
			expected: "55\n",
			solution: "bill = 50\ntip = 5\nprint(bill + tip)",
			hints: [
				"You already have bill and tip.",
				"Add them: bill + tip",
				"print(bill + tip)"
			]
		})
	}),
	gig({
		id: "gig-hours-pay",
		title: "Shift payout",
		client: "Chris Vale",
		company: "Harbor Logistics",
		category: "utility",
		lane: "numbers",
		unlockAfter: 3,
		difficulty: "Easy",
		pay: 340,
		xp: 55,
		skills: ["multiplication"],
		summary: "8 hours times 15 an hour.",
		brief: "Print 8 * 15 for a simulated warehouse shift. Not a real payroll.",
		challenge: ch({
			id: "gig-hours-pay",
			title: "Hours times rate",
			concept: "multiplication",
			prompt: "Print 8 * 15",
			briefing: "* multiplies. No quotes around numbers.",
			example: "print(8 * 15)",
			starter: "hours = 8\nrate = 15\n",
			expected: "120\n",
			solution: "hours = 8\nrate = 15\nprint(hours * rate)",
			hints: [
				"Use hours * rate",
				"print the product",
				"120 is the target"
			]
		})
	}),
	gig({
		id: "gig-seats-left",
		title: "Seats remaining",
		client: "Priya Shah",
		company: "Brightlane School",
		category: "utility",
		lane: "numbers",
		unlockAfter: 3,
		difficulty: "Easy",
		pay: 300,
		xp: 50,
		skills: ["subtraction"],
		summary: "40 seats minus 12 taken.",
		brief: "Print how many seats are left. Classroom simulator.",
		challenge: ch({
			id: "gig-seats-left",
			title: "Subtract taken seats",
			concept: "subtraction",
			prompt: "Print 40 - 12",
			briefing: "- subtracts. print shows the leftover.",
			example: "print(40 - 12)",
			starter: "seats = 40\ntaken = 12\n",
			expected: "28\n",
			solution: "seats = 40\ntaken = 12\nprint(seats - taken)",
			hints: [
				"seats - taken",
				"print that value",
				"28"
			]
		})
	}),
	gig({
		id: "gig-double-score",
		title: "Bonus round",
		client: "Kenji Mori",
		company: "Pixel & Co",
		category: "game",
		lane: "numbers",
		unlockAfter: 3,
		difficulty: "Easy",
		pay: 310,
		xp: 50,
		skills: ["variables", "multiplication"],
		summary: "Double a score of 21.",
		brief: "A mini-game prototype needs the score doubled. Print 42.",
		challenge: ch({
			id: "gig-double-score",
			title: "Times two",
			concept: "multiply a variable",
			prompt: "score is 21. Print score * 2.",
			briefing: "You can multiply a stored number.",
			example: "score = 21\nprint(score * 2)",
			starter: "score = 21\n",
			expected: "42\n",
			solution: "score = 21\nprint(score * 2)",
			hints: [
				"score * 2",
				"print it",
				"42"
			]
		})
	}),
	gig({
		id: "gig-min-hours",
		title: "Minutes to hours",
		client: "Rae Quinn",
		company: "Fieldkit Labs",
		category: "utility",
		lane: "numbers",
		unlockAfter: 3,
		difficulty: "Easy / Medium",
		pay: 360,
		xp: 60,
		skills: ["// integer division"],
		summary: "150 minutes in whole hours.",
		brief: "Use // so 150 minutes becomes 2 hours. Drop the leftover minutes.",
		challenge: ch({
			id: "gig-min-hours",
			title: "Integer divide",
			concept: "//",
			prompt: "Print 150 // 60",
			briefing: "// divides and keeps the whole number. 150 // 60 is 2.",
			example: "print(150 // 60)",
			starter: "minutes = 150\n",
			expected: "2\n",
			solution: "minutes = 150\nprint(minutes // 60)",
			hints: [
				"Use // not /",
				"minutes // 60",
				"print 2"
			]
		})
	}),
	gig({
		id: "gig-pass-gate",
		title: "Exam gate",
		client: "Priya Shah",
		company: "Brightlane School",
		category: "utility",
		lane: "logic",
		unlockAfter: 5,
		difficulty: "Easy / Medium",
		pay: 420,
		xp: 70,
		skills: ["if", "comparison"],
		summary: "Score 82 — print PASS or FAIL at 70.",
		brief: "If score >= 70 print PASS else FAIL. Simulated grade, not a real transcript.",
		challenge: ch({
			id: "gig-pass-gate",
			title: "Pass at 70",
			concept: "if / else",
			prompt: "score is 82. Print PASS if score >= 70, else FAIL.",
			briefing: "if asks a yes/no. Colon, then indent the print.",
			example: "if score >= 70:\n    print(\"PASS\")\nelse:\n    print(\"FAIL\")",
			starter: "score = 82\n",
			expected: "PASS\n",
			solution: "score = 82\nif score >= 70:\n    print(\"PASS\")\nelse:\n    print(\"FAIL\")",
			hints: [
				"if score >= 70:",
				"print PASS on that branch",
				"82 passes"
			]
		})
	}),
	gig({
		id: "gig-age-check",
		title: "Door check",
		client: "Owen Park",
		company: "Drift Market",
		category: "utility",
		lane: "logic",
		unlockAfter: 5,
		difficulty: "Easy",
		pay: 400,
		xp: 65,
		skills: ["if", ">= "],
		summary: "Age 19 — print YES if 18+.",
		brief: "A simulated event door. Print YES or NO.",
		challenge: ch({
			id: "gig-age-check",
			title: "Eighteen and up",
			concept: "if / else",
			prompt: "age is 19. Print YES if age >= 18, else NO.",
			briefing: ">= means at least.",
			example: "if age >= 18:\n    print(\"YES\")",
			starter: "age = 19\n",
			expected: "YES\n",
			solution: "age = 19\nif age >= 18:\n    print(\"YES\")\nelse:\n    print(\"NO\")",
			hints: [
				"if age >= 18:",
				"print YES",
				"else print NO"
			]
		})
	}),
	gig({
		id: "gig-discount",
		title: "Basket discount",
		client: "Mina Cho",
		company: "Northshore Cafe",
		category: "utility",
		lane: "logic",
		unlockAfter: 5,
		difficulty: "Easy / Medium",
		pay: 440,
		xp: 75,
		skills: ["if", "reassignment"],
		summary: "Over 50? Take 10 off 80.",
		brief: "If price > 50, subtract 10, then print the price.",
		challenge: ch({
			id: "gig-discount",
			title: "Conditional markdown",
			concept: "if then assign",
			prompt: "price is 80. If price > 50, set price = price - 10. Then print price.",
			briefing: "You can change a variable inside an if.",
			example: "if price > 50:\n    price = price - 10\nprint(price)",
			starter: "price = 80\n",
			expected: "70\n",
			solution: "price = 80\nif price > 50:\n    price = price - 10\nprint(price)",
			hints: [
				"if price > 50:",
				"price = price - 10",
				"print(price) after the if"
			]
		})
	}),
	gig({
		id: "gig-temp-c",
		title: "Weather convert",
		client: "Rae Quinn",
		company: "Fieldkit Labs",
		category: "utility",
		lane: "logic",
		unlockAfter: 5,
		difficulty: "Medium",
		pay: 460,
		xp: 80,
		skills: ["integer math", "//"],
		summary: "77 F to C with integer math.",
		brief: "Print (77 - 32) * 5 // 9 which is 25. Sensor prototype, not a live weather feed.",
		challenge: ch({
			id: "gig-temp-c",
			title: "F to C",
			concept: "order of operations",
			prompt: "Print (77 - 32) * 5 // 9",
			briefing: "Parentheses first. // keeps a whole number.",
			example: "print((77 - 32) * 5 // 9)",
			starter: "f = 77\n",
			expected: "25\n",
			solution: "f = 77\nprint((f - 32) * 5 // 9)",
			hints: [
				"Subtract 32 first",
				"Then * 5 // 9",
				"Target is 25"
			]
		})
	}),
	gig({
		id: "gig-stock-warn",
		title: "Low-stock ping",
		client: "Chris Vale",
		company: "Harbor Logistics",
		category: "automation",
		lane: "logic",
		unlockAfter: 5,
		difficulty: "Easy / Medium",
		pay: 430,
		xp: 70,
		skills: ["if", "inventory"],
		summary: "Qty 2 — print LOW if under 5.",
		brief: "Warehouse simulator. Print LOW or OK.",
		challenge: ch({
			id: "gig-stock-warn",
			title: "Warn under five",
			concept: "if / else",
			prompt: "qty is 2. Print LOW if qty < 5, else OK.",
			briefing: "< means strictly less than.",
			example: "if qty < 5:\n    print(\"LOW\")",
			starter: "qty = 2\n",
			expected: "LOW\n",
			solution: "qty = 2\nif qty < 5:\n    print(\"LOW\")\nelse:\n    print(\"OK\")",
			hints: [
				"if qty < 5:",
				"print LOW",
				"2 is low"
			]
		})
	}),
	gig({
		id: "gig-upper-name",
		title: "Badge press",
		client: "Jules Adeyemi",
		company: "Harbor Helpdesk",
		category: "utility",
		lane: "text",
		unlockAfter: 8,
		difficulty: "Easy",
		pay: 480,
		xp: 80,
		skills: [".upper()"],
		summary: "Turn ada into ADA.",
		brief: "Name badges want capitals. Print ADA.",
		challenge: ch({
			id: "gig-upper-name",
			title: "Uppercase a name",
			concept: "str.upper",
			prompt: "Print \"ada\".upper()",
			briefing: ".upper() returns a new string in capitals.",
			example: "print(\"ada\".upper())",
			starter: "name = \"ada\"\n",
			expected: "ADA\n",
			solution: "name = \"ada\"\nprint(name.upper())",
			hints: [
				"name.upper()",
				"print that",
				"ADA"
			]
		})
	}),
	gig({
		id: "gig-join-hello",
		title: "Lobby greeting",
		client: "Kenji Mori",
		company: "Pixel & Co",
		category: "utility",
		lane: "text",
		unlockAfter: 8,
		difficulty: "Easy",
		pay: 470,
		xp: 75,
		skills: ["concatenation"],
		summary: "Hi + name.",
		brief: "Print Hi Leo using the stored name.",
		challenge: ch({
			id: "gig-join-hello",
			title: "Join two strings",
			concept: "string +",
			prompt: "name is Leo. Print \"Hi \" + name",
			briefing: "+ sticks strings together. Include the space after Hi.",
			example: "print(\"Hi \" + name)",
			starter: "name = \"Leo\"\n",
			expected: "Hi Leo\n",
			solution: "name = \"Leo\"\nprint(\"Hi \" + name)",
			hints: [
				"\"Hi \" has a trailing space",
				"Add name",
				"print the join"
			]
		})
	}),
	gig({
		id: "gig-len-handle",
		title: "Handle length",
		client: "Rae Quinn",
		company: "Fieldkit Labs",
		category: "data",
		lane: "text",
		unlockAfter: 8,
		difficulty: "Easy",
		pay: 460,
		xp: 75,
		skills: ["len()"],
		summary: "How many letters in pixel?",
		brief: "Print len(\"pixel\") which is 5. Signup form simulator.",
		challenge: ch({
			id: "gig-len-handle",
			title: "Count characters",
			concept: "len",
			prompt: "Print the length of \"pixel\".",
			briefing: "len counts characters in a string.",
			example: "print(len(\"pixel\"))",
			starter: "handle = \"pixel\"\n",
			expected: "5\n",
			solution: "handle = \"pixel\"\nprint(len(handle))",
			hints: [
				"len(handle)",
				"print it",
				"5 letters"
			]
		})
	}),
	gig({
		id: "gig-strip-tag",
		title: "Clean a tag",
		client: "Owen Park",
		company: "Drift Market",
		category: "data",
		lane: "text",
		unlockAfter: 8,
		difficulty: "Easy / Medium",
		pay: 500,
		xp: 85,
		skills: [".strip()"],
		summary: "Trim spaces around done.",
		brief: "Scanner padding left extra spaces. Print done with no padding.",
		challenge: ch({
			id: "gig-strip-tag",
			title: "strip() the edges",
			concept: "str.strip",
			prompt: "Print \"  done  \".strip()",
			briefing: "strip() removes spaces from both ends, not the middle.",
			example: "print(\"  done  \".strip())",
			starter: "tag = \"  done  \"\n",
			expected: "done\n",
			solution: "tag = \"  done  \"\nprint(tag.strip())",
			hints: [
				"tag.strip()",
				"print the result",
				"No extra spaces"
			]
		})
	}),
	gig({
		id: "gig-initials",
		title: "Monogram",
		client: "Priya Shah",
		company: "Brightlane School",
		category: "utility",
		lane: "text",
		unlockAfter: 8,
		difficulty: "Easy / Medium",
		pay: 520,
		xp: 90,
		skills: ["indexes"],
		summary: "First letters of Ada Lovelace.",
		brief: "Print AL using index 0 of each name.",
		challenge: ch({
			id: "gig-initials",
			title: "Index 0 + index 0",
			concept: "string indexes",
			prompt: "Print first[0] + last[0] for Ada Lovelace.",
			briefing: "Indexes start at 0. first[0] is A.",
			example: "print(first[0] + last[0])",
			starter: "first = \"Ada\"\nlast = \"Lovelace\"\n",
			expected: "AL\n",
			solution: "first = \"Ada\"\nlast = \"Lovelace\"\nprint(first[0] + last[0])",
			hints: [
				"first[0] is A",
				"last[0] is L",
				"Add the two characters"
			]
		})
	}),
	gig({
		id: "gig-sum-hours",
		title: "Timesheet total",
		client: "Chris Vale",
		company: "Harbor Logistics",
		category: "data",
		lane: "loops",
		unlockAfter: 11,
		difficulty: "Easy / Medium",
		pay: 560,
		xp: 95,
		skills: ["sum()", "lists"],
		summary: "Add 3, 4, and 5 hours.",
		brief: "Print sum([3, 4, 5]). Simulated timesheet.",
		challenge: ch({
			id: "gig-sum-hours",
			title: "Sum a list",
			concept: "sum",
			prompt: "Print the sum of [3, 4, 5].",
			briefing: "sum adds every number in a list.",
			example: "print(sum([3, 4, 5]))",
			starter: "hours = [3, 4, 5]\n",
			expected: "12\n",
			solution: "hours = [3, 4, 5]\nprint(sum(hours))",
			hints: [
				"sum(hours)",
				"print it",
				"12"
			]
		})
	}),
	gig({
		id: "gig-count-even",
		title: "Even-lot counter",
		client: "Owen Park",
		company: "Drift Market",
		category: "data",
		lane: "loops",
		unlockAfter: 11,
		difficulty: "Medium",
		pay: 620,
		xp: 110,
		skills: [
			"for",
			"%",
			"counters"
		],
		summary: "How many evens in 1..6?",
		brief: "Loop the list. If x % 2 == 0, add one. Print the count.",
		challenge: ch({
			id: "gig-count-even",
			title: "Count even numbers",
			concept: "for + remainder",
			prompt: "Count how many values in [1, 2, 3, 4, 5, 6] are even. Print that count.",
			briefing: "% 2 == 0 means even. Keep a counter.",
			example: "n = 0\nfor x in nums:\n    if x % 2 == 0:\n        n = n + 1\nprint(n)",
			starter: "nums = [1, 2, 3, 4, 5, 6]\nn = 0\n",
			expected: "3\n",
			solution: "nums = [1, 2, 3, 4, 5, 6]\nn = 0\nfor x in nums:\n    if x % 2 == 0:\n        n = n + 1\nprint(n)",
			hints: [
				"for x in nums:",
				"if x % 2 == 0",
				"n = n + 1, then print n"
			]
		})
	}),
	gig({
		id: "gig-table-row",
		title: "Times-table row",
		client: "Priya Shah",
		company: "Brightlane School",
		category: "game",
		lane: "loops",
		unlockAfter: 11,
		difficulty: "Easy / Medium",
		pay: 580,
		xp: 100,
		skills: ["for", "range"],
		summary: "Print 3, 6, 9, 12 each on its line.",
		brief: "Worksheet generator. One number per line.",
		challenge: ch({
			id: "gig-table-row",
			title: "3 times 1..4",
			concept: "for range",
			prompt: "Print 3*1, 3*2, 3*3, 3*4 each on a new line.",
			briefing: "range(1, 5) is 1, 2, 3, 4.",
			example: "for i in range(1, 5):\n    print(3 * i)",
			starter: "# Print four lines.\n",
			expected: "3\n6\n9\n12\n",
			solution: "for i in range(1, 5):\n    print(3 * i)",
			hints: [
				"for i in range(1, 5):",
				"print(3 * i)",
				"Four lines"
			]
		})
	}),
	gig({
		id: "gig-filter-pass",
		title: "Passing scores",
		client: "Jules Adeyemi",
		company: "Harbor Helpdesk",
		category: "data",
		lane: "loops",
		unlockAfter: 11,
		difficulty: "Medium",
		pay: 640,
		xp: 110,
		skills: [
			"for",
			"if",
			"filter"
		],
		summary: "Print scores that are 70 or more.",
		brief: "From [55, 70, 90] print 70 then 90. Training data, not real students.",
		challenge: ch({
			id: "gig-filter-pass",
			title: "Keep the passes",
			concept: "filter with for",
			prompt: "Loop [55, 70, 90]. Print each score that is >= 70.",
			briefing: "if inside a for keeps some items and skips others.",
			example: "for s in scores:\n    if s >= 70:\n        print(s)",
			starter: "scores = [55, 70, 90]\n",
			expected: "70\n90\n",
			solution: "scores = [55, 70, 90]\nfor s in scores:\n    if s >= 70:\n        print(s)",
			hints: [
				"for s in scores:",
				"if s >= 70",
				"print(s)"
			]
		})
	}),
	gig({
		id: "gig-countdown",
		title: "Launch countdown",
		client: "Kenji Mori",
		company: "Pixel & Co",
		category: "game",
		lane: "loops",
		unlockAfter: 11,
		difficulty: "Easy / Medium",
		pay: 540,
		xp: 90,
		skills: ["for", "print"],
		summary: "3, 2, 1, then GO.",
		brief: "Game boot screen. Four lines.",
		challenge: ch({
			id: "gig-countdown",
			title: "Count then GO",
			concept: "for over a list",
			prompt: "Print 3, then 2, then 1, then GO — four lines.",
			briefing: "Loop [3, 2, 1], then one more print.",
			example: "for n in [3, 2, 1]:\n    print(n)\nprint(\"GO\")",
			starter: "# Countdown.\n",
			expected: "3\n2\n1\nGO\n",
			solution: "for n in [3, 2, 1]:\n    print(n)\nprint(\"GO\")",
			hints: [
				"Loop 3, 2, 1",
				"print each n",
				"Then print GO"
			]
		})
	}),
	gig({
		id: "gig-append-ticket",
		title: "New ticket",
		client: "Jules Adeyemi",
		company: "Harbor Helpdesk",
		category: "automation",
		lane: "lists",
		unlockAfter: 15,
		difficulty: "Easy / Medium",
		pay: 680,
		xp: 115,
		skills: [".append()", "indexes"],
		summary: "Append 12 and print the last ticket.",
		brief: "Queue simulator. Start [10, 11], append 12, print index 2.",
		challenge: ch({
			id: "gig-append-ticket",
			title: "append then index",
			concept: "list.append",
			prompt: "tix starts as [10, 11]. Append 12. Print tix[2].",
			briefing: "append adds at the end. Indexes start at 0, so the third item is [2].",
			example: "tix.append(12)\nprint(tix[2])",
			starter: "tix = [10, 11]\n",
			expected: "12\n",
			solution: "tix = [10, 11]\ntix.append(12)\nprint(tix[2])",
			hints: [
				"tix.append(12)",
				"print(tix[2])",
				"append returns None — print the list item"
			]
		})
	}),
	gig({
		id: "gig-replace-item",
		title: "Menu swap",
		client: "Mina Cho",
		company: "Northshore Cafe",
		category: "utility",
		lane: "lists",
		unlockAfter: 15,
		difficulty: "Easy / Medium",
		pay: 660,
		xp: 110,
		skills: ["index assign"],
		summary: "Change bread to rice.",
		brief: "menu = [soup, bread, tea]. Replace index 1. Print the new index 1.",
		challenge: ch({
			id: "gig-replace-item",
			title: "Assign at an index",
			concept: "list[i] = value",
			prompt: "Set menu[1] to \"rice\". Print menu[1].",
			briefing: "You can replace an existing slot. You cannot assign past the end — use append for that.",
			example: "menu[1] = \"rice\"\nprint(menu[1])",
			starter: "menu = [\"soup\", \"bread\", \"tea\"]\n",
			expected: "rice\n",
			solution: "menu = [\"soup\", \"bread\", \"tea\"]\nmenu[1] = \"rice\"\nprint(menu[1])",
			hints: [
				"menu[1] = \"rice\"",
				"print(menu[1])",
				"Index 1 is the second item"
			]
		})
	}),
	gig({
		id: "gig-slice-log",
		title: "Log window",
		client: "Rae Quinn",
		company: "Fieldkit Labs",
		category: "data",
		lane: "lists",
		unlockAfter: 15,
		difficulty: "Medium",
		pay: 720,
		xp: 120,
		skills: ["slices"],
		summary: "Print the first two log lines.",
		brief: "A file-like list of lines. Slice [0:2] and print both.",
		challenge: ch({
			id: "gig-slice-log",
			title: "Slice start:end",
			concept: "list slices",
			prompt: "log = [\"boot\", \"ok\", \"sync\"]. Take log[0:2]. Print both items, one per line.",
			briefing: "start:end goes up to but not including end. [0:2] is indexes 0 and 1.",
			example: "part = log[0:2]\nprint(part[0])\nprint(part[1])",
			starter: "log = [\"boot\", \"ok\", \"sync\"]\n",
			expected: "boot\nok\n",
			solution: "log = [\"boot\", \"ok\", \"sync\"]\npart = log[0:2]\nprint(part[0])\nprint(part[1])",
			hints: [
				"log[0:2]",
				"Print part[0] then part[1]",
				"boot then ok"
			]
		})
	}),
	gig({
		id: "gig-top-score",
		title: "High score",
		client: "Kenji Mori",
		company: "Pixel & Co",
		category: "game",
		lane: "lists",
		unlockAfter: 15,
		difficulty: "Easy",
		pay: 640,
		xp: 100,
		skills: ["max()"],
		summary: "Best of 4, 17, 9.",
		brief: "Print max of the list. Arcade prototype.",
		challenge: ch({
			id: "gig-top-score",
			title: "max of a list",
			concept: "max",
			prompt: "Print max([4, 17, 9])",
			briefing: "max returns the largest number.",
			example: "print(max(scores))",
			starter: "scores = [4, 17, 9]\n",
			expected: "17\n",
			solution: "scores = [4, 17, 9]\nprint(max(scores))",
			hints: [
				"max(scores)",
				"print it",
				"17"
			]
		})
	}),
	gig({
		id: "gig-index-swap",
		title: "Rotate the rack",
		client: "Chris Vale",
		company: "Harbor Logistics",
		category: "automation",
		lane: "lists",
		unlockAfter: 15,
		difficulty: "Medium",
		pay: 740,
		xp: 125,
		skills: ["indexes", "swap"],
		summary: "Swap first and last of [1, 2, 3].",
		brief: "Print the new first, then the new last. Should be 3 then 1.",
		challenge: ch({
			id: "gig-index-swap",
			title: "Swap ends",
			concept: "temporary swap",
			prompt: "a = [1, 2, 3]. Swap a[0] and a[2]. Print a[0] then a[2].",
			briefing: "Use a tmp box, or a[0], a[2] = a[2], a[0].",
			example: "tmp = a[0]\na[0] = a[2]\na[2] = tmp",
			starter: "a = [1, 2, 3]\n",
			expected: "3\n1\n",
			solution: "a = [1, 2, 3]\ntmp = a[0]\na[0] = a[2]\na[2] = tmp\nprint(a[0])\nprint(a[2])",
			hints: [
				"Save a[0] in tmp",
				"a[0] = a[2], then a[2] = tmp",
				"Print 3 then 1"
			]
		})
	}),
	gig({
		id: "gig-lookup-role",
		title: "Staff lookup",
		client: "Jules Adeyemi",
		company: "Harbor Helpdesk",
		category: "api",
		lane: "records",
		unlockAfter: 20,
		difficulty: "Easy / Medium",
		pay: 780,
		xp: 130,
		skills: ["dictionaries"],
		summary: "Print Ada's role from a dict.",
		brief: "A tiny simulated API payload. Print Engineer.",
		challenge: ch({
			id: "gig-lookup-role",
			title: "Dict key access",
			concept: "dict[key]",
			prompt: "staff maps Ada to Engineer. Print staff[\"Ada\"].",
			briefing: "Keys are strings. Spell the key exactly.",
			example: "print(staff[\"Ada\"])",
			starter: "staff = {\"Ada\": \"Engineer\"}\n",
			expected: "Engineer\n",
			solution: "staff = {\"Ada\": \"Engineer\"}\nprint(staff[\"Ada\"])",
			hints: [
				"staff[\"Ada\"]",
				"Quotes around Ada",
				"print the role"
			]
		})
	}),
	gig({
		id: "gig-safe-get",
		title: "Missing field",
		client: "Rae Quinn",
		company: "Fieldkit Labs",
		category: "api",
		lane: "records",
		unlockAfter: 20,
		difficulty: "Medium",
		pay: 800,
		xp: 140,
		skills: [".get()"],
		summary: "Look up a key that is not there.",
		brief: "user has name only. Print user.get(\"role\") which is None — no crash.",
		challenge: ch({
			id: "gig-safe-get",
			title: "get never explodes",
			concept: "dict.get",
			prompt: "Print user.get(\"role\") for a user that only has name.",
			briefing: ".get(key) returns None when the key is missing. [] would raise KeyError.",
			example: "print(user.get(\"role\"))",
			starter: "user = {\"name\": \"Nia\"}\n",
			expected: "None\n",
			solution: "user = {\"name\": \"Nia\"}\nprint(user.get(\"role\"))",
			hints: [
				"user.get(\"role\")",
				"Missing keys become None",
				"print it"
			]
		})
	}),
	gig({
		id: "gig-report-fn",
		title: "ID labeler",
		client: "Kenji Mori",
		company: "Pixel & Co",
		category: "report",
		lane: "records",
		unlockAfter: 20,
		difficulty: "Medium",
		pay: 820,
		xp: 145,
		skills: ["functions", "str()"],
		summary: "A function that returns id=7.",
		brief: "Write label(n) that returns \"id=\" + str(n). Print label(7).",
		challenge: ch({
			id: "gig-report-fn",
			title: "def + return",
			concept: "functions",
			prompt: "Define label(n) that returns id= plus the number. Print label(7).",
			briefing: "str(n) turns a number into text so you can add it to a string.",
			example: "def label(n):\n    return \"id=\" + str(n)\nprint(label(7))",
			starter: "def label(n):\n    return \"\"\n",
			expected: "id=7\n",
			solution: "def label(n):\n    return \"id=\" + str(n)\nprint(label(7))",
			hints: [
				"return \"id=\" + str(n)",
				"Call print(label(7))",
				"No extra spaces"
			]
		})
	}),
	gig({
		id: "gig-filter-roster",
		title: "Active roster",
		client: "Chris Vale",
		company: "Harbor Logistics",
		category: "data",
		lane: "records",
		unlockAfter: 20,
		difficulty: "Medium",
		pay: 860,
		xp: 150,
		skills: ["list of dicts", "for"],
		summary: "Print names where ok is True.",
		brief: "Simulated crew list. Print Ada only.",
		challenge: ch({
			id: "gig-filter-roster",
			title: "Walk records",
			concept: "nested fields",
			prompt: "Loop people. If p[\"ok\"], print p[\"name\"].",
			briefing: "Each p is a dictionary. p[\"ok\"] is True or False.",
			example: "for p in people:\n    if p[\"ok\"]:\n        print(p[\"name\"])",
			starter: "people = [{\"name\": \"Ada\", \"ok\": True}, {\"name\": \"Ben\", \"ok\": False}]\n",
			expected: "Ada\n",
			solution: "people = [{\"name\": \"Ada\", \"ok\": True}, {\"name\": \"Ben\", \"ok\": False}]\nfor p in people:\n    if p[\"ok\"]:\n        print(p[\"name\"])",
			hints: [
				"for p in people:",
				"if p[\"ok\"]:",
				"print(p[\"name\"])"
			]
		})
	}),
	gig({
		id: "gig-merge-keys",
		title: "Patch a record",
		client: "Owen Park",
		company: "Drift Market",
		category: "api",
		lane: "records",
		unlockAfter: 20,
		difficulty: "Easy / Medium",
		pay: 760,
		xp: 130,
		skills: ["dict assign"],
		summary: "Change city from Oslo to Bergen.",
		brief: "Simulated profile patch. Print the new city.",
		challenge: ch({
			id: "gig-merge-keys",
			title: "Overwrite a key",
			concept: "dict assignment",
			prompt: "Set rec[\"city\"] = \"Bergen\". Print rec[\"city\"].",
			briefing: "Assigning an existing key replaces the value.",
			example: "rec[\"city\"] = \"Bergen\"\nprint(rec[\"city\"])",
			starter: "rec = {\"city\": \"Oslo\"}\n",
			expected: "Bergen\n",
			solution: "rec = {\"city\": \"Oslo\"}\nrec[\"city\"] = \"Bergen\"\nprint(rec[\"city\"])",
			hints: [
				"rec[\"city\"] = \"Bergen\"",
				"print(rec[\"city\"])",
				"Spelling and capitals matter"
			]
		})
	}),
	gig({
		id: "gig-domain-email",
		title: "Email domain",
		client: "Jules Adeyemi",
		company: "Harbor Helpdesk",
		category: "data",
		lane: "methods",
		unlockAfter: 30,
		difficulty: "Medium",
		pay: 900,
		xp: 160,
		skills: [".split()"],
		summary: "Take the part after @.",
		brief: "Print lumen.dev from ada@lumen.dev. Practice parser, not a real inbox.",
		challenge: ch({
			id: "gig-domain-email",
			title: "split on @",
			concept: "str.split",
			prompt: "Split the email on \"@\" and print index 1.",
			briefing: "split returns a list. [0] is the name, [1] is the domain.",
			example: "print(email.split(\"@\")[1])",
			starter: "email = \"ada@lumen.dev\"\n",
			expected: "lumen.dev\n",
			solution: "email = \"ada@lumen.dev\"\nprint(email.split(\"@\")[1])",
			hints: [
				"email.split(\"@\")",
				"Take [1]",
				"print the domain"
			]
		})
	}),
	gig({
		id: "gig-replace-word",
		title: "Redact a phrase",
		client: "Priya Shah",
		company: "Brightlane School",
		category: "automation",
		lane: "methods",
		unlockAfter: 30,
		difficulty: "Easy / Medium",
		pay: 860,
		xp: 150,
		skills: [".replace()"],
		summary: "Replace buy with view.",
		brief: "Print view now view. Content filter prototype.",
		challenge: ch({
			id: "gig-replace-word",
			title: "replace all matches",
			concept: "str.replace",
			prompt: "Replace \"buy\" with \"view\" in \"buy now buy\". Print the result.",
			briefing: "replace returns a new string. It does not change the original in place.",
			example: "print(msg.replace(\"buy\", \"view\"))",
			starter: "msg = \"buy now buy\"\n",
			expected: "view now view\n",
			solution: "msg = \"buy now buy\"\nprint(msg.replace(\"buy\", \"view\"))",
			hints: [
				"msg.replace(\"buy\", \"view\")",
				"print the new string",
				"Both buys change"
			]
		})
	}),
	gig({
		id: "gig-count-letter",
		title: "Letter tally",
		client: "Kenji Mori",
		company: "Pixel & Co",
		category: "data",
		lane: "methods",
		unlockAfter: 30,
		difficulty: "Easy",
		pay: 820,
		xp: 140,
		skills: [".count()"],
		summary: "How many a in banana?",
		brief: "Print 3.",
		challenge: ch({
			id: "gig-count-letter",
			title: "count a character",
			concept: "str.count",
			prompt: "Print how many times \"a\" appears in \"banana\".",
			briefing: "count returns a number.",
			example: "print(\"banana\".count(\"a\"))",
			starter: "word = \"banana\"\n",
			expected: "3\n",
			solution: "word = \"banana\"\nprint(word.count(\"a\"))",
			hints: [
				"word.count(\"a\")",
				"print it",
				"3"
			]
		})
	}),
	gig({
		id: "gig-startswith-ok",
		title: "Path gate",
		client: "Rae Quinn",
		company: "Fieldkit Labs",
		category: "automation",
		lane: "methods",
		unlockAfter: 30,
		difficulty: "Easy / Medium",
		pay: 880,
		xp: 155,
		skills: [".startswith()"],
		summary: "Allow paths under img/.",
		brief: "If the path starts with img/ print OK else NO.",
		challenge: ch({
			id: "gig-startswith-ok",
			title: "startswith check",
			concept: "str.startswith",
			prompt: "path is img/cat.png. Print OK if it startswith img/, else NO.",
			briefing: "startswith asks a yes/no about the beginning of a string.",
			example: "if path.startswith(\"img/\"):\n    print(\"OK\")",
			starter: "path = \"img/cat.png\"\n",
			expected: "OK\n",
			solution: "path = \"img/cat.png\"\nif path.startswith(\"img/\"):\n    print(\"OK\")\nelse:\n    print(\"NO\")",
			hints: [
				"path.startswith(\"img/\")",
				"print OK",
				"Include the slash"
			]
		})
	}),
	gig({
		id: "gig-guess-hint",
		title: "Guessing-game hint",
		client: "Kenji Mori",
		company: "Pixel & Co",
		category: "game",
		lane: "methods",
		unlockAfter: 30,
		difficulty: "Medium",
		pay: 940,
		xp: 165,
		skills: ["if / elif", "compare"],
		summary: "Secret 7, guess 4 — Too low.",
		brief: "Print Too low, Too high, or Correct. Mini-game logic.",
		challenge: ch({
			id: "gig-guess-hint",
			title: "Compare guess to secret",
			concept: "elif chain",
			prompt: "secret 7, guess 4. Print Too low / Too high / Correct.",
			briefing: "if guess < secret, elif guess > secret, else Correct.",
			example: "if guess < secret:\n    print(\"Too low\")\nelif guess > secret:\n    print(\"Too high\")\nelse:\n    print(\"Correct\")",
			starter: "secret = 7\nguess = 4\n",
			expected: "Too low\n",
			solution: "secret = 7\nguess = 4\nif guess < secret:\n    print(\"Too low\")\nelif guess > secret:\n    print(\"Too high\")\nelse:\n    print(\"Correct\")",
			hints: [
				"if guess < secret",
				"Print Too low",
				"Match the capital T and the space"
			]
		})
	}),
	gig({
		id: "gig-zip-labels",
		title: "Score sheet",
		client: "Priya Shah",
		company: "Brightlane School",
		category: "report",
		lane: "studio",
		unlockAfter: 50,
		difficulty: "Medium",
		pay: 1100,
		xp: 190,
		skills: ["zip", "loops"],
		summary: "Pair names with points.",
		brief: "Print Ada 90 then Ben 70. Simulated class sheet.",
		challenge: ch({
			id: "gig-zip-labels",
			title: "zip two lists",
			concept: "zip",
			prompt: "zip names with pts. Print name, space, score on each line.",
			briefing: "zip walks two lists in lockstep. Unpack the pair.",
			example: "for n, p in zip(names, pts):\n    print(n + \" \" + str(p))",
			starter: "names = [\"Ada\", \"Ben\"]\npts = [90, 70]\n",
			expected: "Ada 90\nBen 70\n",
			solution: "names = [\"Ada\", \"Ben\"]\npts = [90, 70]\nfor n, p in zip(names, pts):\n    print(n + \" \" + str(p))",
			hints: [
				"for n, p in zip(names, pts):",
				"str(p) to join with the name",
				"Space between"
			]
		})
	}),
	gig({
		id: "gig-fizz-tag",
		title: "Ticket tags",
		client: "Jules Adeyemi",
		company: "Harbor Helpdesk",
		category: "automation",
		lane: "studio",
		unlockAfter: 50,
		difficulty: "Medium",
		pay: 1150,
		xp: 200,
		skills: ["%", "elif"],
		summary: "15 should print FIZZBUZZ.",
		brief: "Priority tags: 15→FIZZBUZZ, 3→FIZZ, 5→BUZZ, else the number.",
		challenge: ch({
			id: "gig-fizz-tag",
			title: "FizzBuzz one shot",
			concept: "remainder chain",
			prompt: "n is 15. Print FIZZBUZZ / FIZZ / BUZZ / n using % 15, % 3, % 5.",
			briefing: "Check % 15 first so 15 is not tagged FIZZ only.",
			example: "if n % 15 == 0:\n    print(\"FIZZBUZZ\")",
			starter: "n = 15\n",
			expected: "FIZZBUZZ\n",
			solution: "n = 15\nif n % 15 == 0:\n    print(\"FIZZBUZZ\")\nelif n % 3 == 0:\n    print(\"FIZZ\")\nelif n % 5 == 0:\n    print(\"BUZZ\")\nelse:\n    print(n)",
			hints: [
				"Test % 15 first",
				"print FIZZBUZZ",
				"All caps, no space"
			]
		})
	}),
	gig({
		id: "gig-unique-merge",
		title: "Merge unique IDs",
		client: "Chris Vale",
		company: "Harbor Logistics",
		category: "data",
		lane: "studio",
		unlockAfter: 50,
		difficulty: "Medium / Hard",
		pay: 1200,
		xp: 210,
		skills: [
			"in",
			"append",
			"concat"
		],
		summary: "Merge [1, 2] and [2, 3] without duplicates.",
		brief: "Print 1 then 2 then 3. First-seen order.",
		challenge: ch({
			id: "gig-unique-merge",
			title: "Keep first of each",
			concept: "membership",
			prompt: "Walk a + b. If x not in out, append it. Print each item of out.",
			briefing: "not in asks whether a value is already in the list.",
			example: "for x in a + b:\n    if x not in out:\n        out.append(x)",
			starter: "a = [1, 2]\nb = [2, 3]\nout = []\n",
			expected: "1\n2\n3\n",
			solution: "a = [1, 2]\nb = [2, 3]\nout = []\nfor x in a + b:\n    if x not in out:\n        out.append(x)\nfor x in out:\n    print(x)",
			hints: [
				"for x in a + b",
				"if x not in out: out.append(x)",
				"Then print each of out"
			]
		})
	}),
	gig({
		id: "gig-clamp",
		title: "Volume clamp",
		client: "Kenji Mori",
		company: "Pixel & Co",
		category: "utility",
		lane: "studio",
		unlockAfter: 50,
		difficulty: "Medium",
		pay: 1080,
		xp: 185,
		skills: ["if", "bounds"],
		summary: "Keep 140 inside 0..100.",
		brief: "If n > 100 set 100. If n < 0 set 0. Print n. Audio mixer prototype.",
		challenge: ch({
			id: "gig-clamp",
			title: "Clamp a number",
			concept: "min/max bounds",
			prompt: "n is 140. Clamp to 0..100 and print n.",
			briefing: "Two ifs, or min(100, max(0, n)).",
			example: "if n > 100:\n    n = 100\nif n < 0:\n    n = 0\nprint(n)",
			starter: "n = 140\n",
			expected: "100\n",
			solution: "n = 140\nif n > 100:\n    n = 100\nif n < 0:\n    n = 0\nprint(n)",
			hints: [
				"if n > 100: n = 100",
				"Then print n",
				"140 becomes 100"
			]
		})
	}),
	gig({
		id: "gig-any-ready",
		title: "Ready check",
		client: "Rae Quinn",
		company: "Fieldkit Labs",
		category: "api",
		lane: "studio",
		unlockAfter: 50,
		difficulty: "Medium",
		pay: 1120,
		xp: 190,
		skills: ["any()", "all()"],
		summary: "any flags True, all flags False.",
		brief: "flags = [False, True, False]. Print any(flags) then all(flags).",
		challenge: ch({
			id: "gig-any-ready",
			title: "any and all",
			concept: "bulk truth",
			prompt: "Print any(flags) on the first line and all(flags) on the second.",
			briefing: "any is True if at least one item is true. all needs every item true.",
			example: "print(any(flags))\nprint(all(flags))",
			starter: "flags = [False, True, False]\n",
			expected: "True\nFalse\n",
			solution: "flags = [False, True, False]\nprint(any(flags))\nprint(all(flags))",
			hints: [
				"print(any(flags))",
				"print(all(flags))",
				"True then False"
			]
		})
	}),
	gig({
		id: "gig-freq-a",
		title: "Letter frequency",
		client: "Priya Shah",
		company: "Brightlane School",
		category: "data",
		lane: "craft",
		unlockAfter: 75,
		difficulty: "Medium / Hard",
		pay: 1400,
		xp: 240,
		skills: ["dicts", "counters"],
		summary: "Count each letter in ada.",
		brief: "Build a dict. Print the count for a, then d. Cipher lab — simulated.",
		challenge: ch({
			id: "gig-freq-a",
			title: "Frequency table",
			concept: "dict counters",
			prompt: "Count letters in \"ada\". Print freq[\"a\"] then freq[\"d\"].",
			briefing: "If the key is missing, start at 0, then add 1.",
			example: "for ch in word:\n    freq[ch] = freq.get(ch, 0) + 1",
			starter: "word = \"ada\"\nfreq = {}\n",
			expected: "2\n1\n",
			solution: "word = \"ada\"\nfreq = {}\nfor ch in word:\n    freq[ch] = freq.get(ch, 0) + 1\nprint(freq[\"a\"])\nprint(freq[\"d\"])",
			hints: [
				"freq.get(ch, 0) + 1",
				"Loop every character",
				"Print a then d"
			]
		})
	}),
	gig({
		id: "gig-caesar-one",
		title: "Shift a letter",
		client: "Kenji Mori",
		company: "Pixel & Co",
		category: "game",
		lane: "craft",
		unlockAfter: 75,
		difficulty: "Hard",
		pay: 1500,
		xp: 260,
		skills: ["ord", "chr"],
		summary: "Move A one place to B.",
		brief: "Toy cipher. Print chr(ord(\"A\") + 1).",
		challenge: ch({
			id: "gig-caesar-one",
			title: "ord and chr",
			concept: "character codes",
			prompt: "Print the character after A using ord and chr.",
			briefing: "ord(\"A\") is 65. chr(66) is B.",
			example: "print(chr(ord(\"A\") + 1))",
			starter: "letter = \"A\"\n",
			expected: "B\n",
			solution: "letter = \"A\"\nprint(chr(ord(letter) + 1))",
			hints: [
				"ord(letter) + 1",
				"Wrap with chr(...)",
				"B"
			]
		})
	}),
	gig({
		id: "gig-nested-pass",
		title: "Open tickets",
		client: "Jules Adeyemi",
		company: "Harbor Helpdesk",
		category: "report",
		lane: "craft",
		unlockAfter: 75,
		difficulty: "Medium / Hard",
		pay: 1450,
		xp: 250,
		skills: ["nested records"],
		summary: "Print ids of tickets with status open.",
		brief: "Simulated ticket bay. Print 1 then 3.",
		challenge: ch({
			id: "gig-nested-pass",
			title: "Filter nested dicts",
			concept: "nested loops of records",
			prompt: "Loop tickets. If t[\"status\"] == \"open\", print t[\"id\"].",
			briefing: "Each ticket is a dictionary inside a list.",
			example: "for t in tickets:\n    if t[\"status\"] == \"open\":\n        print(t[\"id\"])",
			starter: "tickets = [{\"id\": 1, \"status\": \"open\"}, {\"id\": 2, \"status\": \"done\"}, {\"id\": 3, \"status\": \"open\"}]\n",
			expected: "1\n3\n",
			solution: "tickets = [{\"id\": 1, \"status\": \"open\"}, {\"id\": 2, \"status\": \"done\"}, {\"id\": 3, \"status\": \"open\"}]\nfor t in tickets:\n    if t[\"status\"] == \"open\":\n        print(t[\"id\"])",
			hints: [
				"for t in tickets:",
				"if t[\"status\"] == \"open\"",
				"print(t[\"id\"])"
			]
		})
	}),
	gig({
		id: "gig-histo",
		title: "Star chart",
		client: "Owen Park",
		company: "Drift Market",
		category: "report",
		lane: "craft",
		unlockAfter: 75,
		difficulty: "Medium / Hard",
		pay: 1380,
		xp: 240,
		skills: ["string * int", "loops"],
		summary: "Print *** then ** then *****.",
		brief: "Tiny histogram from counts [3, 2, 5]. Repeat \"*\" n times.",
		challenge: ch({
			id: "gig-histo",
			title: "Stars for counts",
			concept: "string repeat",
			prompt: "For each n in [3, 2, 5], print \"*\" * n.",
			briefing: "A string times a number repeats the string.",
			example: "for n in counts:\n    print(\"*\" * n)",
			starter: "counts = [3, 2, 5]\n",
			expected: "***\n**\n*****\n",
			solution: "counts = [3, 2, 5]\nfor n in counts:\n    print(\"*\" * n)",
			hints: [
				"for n in counts:",
				"print(\"*\" * n)",
				"Three lines"
			]
		})
	}),
	gig({
		id: "gig-pipe-two",
		title: "Helper pipeline",
		client: "Rae Quinn",
		company: "Fieldkit Labs",
		category: "automation",
		lane: "craft",
		unlockAfter: 75,
		difficulty: "Hard",
		pay: 1600,
		xp: 280,
		skills: ["functions", "composition"],
		summary: "clean then tag a name.",
		brief: "clean strips and uppercases. tag adds ID:. Print ID:ADA for \"  ada  \".",
		challenge: ch({
			id: "gig-pipe-two",
			title: "One function calls another",
			concept: "composition",
			prompt: "Write clean(s) = s.strip().upper(). Write tag(s) = \"ID:\" + clean(s). Print tag(\"  ada  \").",
			briefing: "tag calls clean. The inner function finishes first.",
			example: "def clean(s):\n    return s.strip().upper()\ndef tag(s):\n    return \"ID:\" + clean(s)",
			starter: "def clean(s):\n    return s\n\ndef tag(s):\n    return s\n",
			expected: "ID:ADA\n",
			solution: "def clean(s):\n    return s.strip().upper()\n\ndef tag(s):\n    return \"ID:\" + clean(s)\nprint(tag(\"  ada  \"))",
			hints: [
				"clean: strip then upper",
				"tag: \"ID:\" + clean(s)",
				"print(tag(\"  ada  \"))"
			]
		})
	})
];
function gigById(id) {
	return GIGS.find((g) => g.id === id);
}
function maxCompleted(completed) {
	return completed.length ? Math.max(...completed) : 0;
}
function isGigUnlocked(job, completed) {
	return maxCompleted(completed) >= job.unlockAfter;
}
function unlockedGigs(completed) {
	return GIGS.filter((g) => isGigUnlocked(g, completed));
}
function gigsNewlyUnlocked(prevMax, nextMax) {
	return GIGS.filter((g) => g.unlockAfter > prevMax && g.unlockAfter <= nextMax);
}
function categoryLabel(c) {
	switch (c) {
		case "bugfix": return "Bugfix";
		case "utility": return "Utility";
		case "game": return "Mini-game";
		case "data": return "Data";
		case "automation": return "Automation";
		case "api": return "API sim";
		case "report": return "Report";
	}
}
function featuredGig(completed, doneIds) {
	const open = unlockedGigs(completed).filter((g) => !doneIds.has(g.id));
	if (!open.length) return null;
	return open[0];
}
var SIM_DISCLAIMER = "Simulated clients, ratings, and pay. Practice only — not real employment.";
var FIVE = [
	"Clean, readable, and exactly on brief. Would hire again for the next sprint.",
	"Shipped on the first pass. The script does one job and does it well.",
	"Precise output, no extra noise. This is how a tiny tool should look.",
	"Solid craft. We dropped this straight into the practice sandbox."
];
var FOUR = [
	"Works as specified. A couple of extra tries, but the result is trustworthy.",
	"Good delivery. Next time, aim to land it with fewer hints.",
	"Correct and tidy. Close to a five — just a little slower to land.",
	"We can use this. Small wobble on the way, then a clean finish."
];
var THREE = [
	"It passes. The path was bumpier than we'd like, but the output matches.",
	"Acceptable. Consider solving without opening the working code next time.",
	"Done. Functional, not elegant — still meets the contract.",
	"Thanks for pushing through. Review the briefing once more on similar gigs."
];
var TWO = [
	"Output is correct, process was rough. Revisit the concept before the next client job.",
	"We accepted it, with notes. Try the hints one at a time instead of the full solution.",
	"It works. Let's tighten the first attempt on the next one."
];
var ONE = ["Barely cleared. Replay a learning mission on this topic before more client work."];
function hash(s) {
	let h = 0;
	for (let i = 0; i < s.length; i++) h = h * 31 + s.charCodeAt(i) >>> 0;
	return h;
}
function pick(id, stars, list) {
	return list[(hash(id) + stars) % list.length];
}
function scoreGig(job, stats) {
	let stars;
	if (stats.attempts === 1 && stats.hintsUsed === 0 && !stats.showedSolution) stars = 5;
	else if (stats.showedSolution) stars = stats.attempts >= 8 ? 1 : stats.attempts >= 5 ? 2 : 3;
	else if (stats.attempts <= 2 && stats.hintsUsed <= 1) stars = 4;
	else if (stats.attempts <= 4 && stats.hintsUsed <= 2) stars = 4;
	else if (stats.attempts <= 6) stars = 3;
	else stars = 2;
	stars = Math.max(1, Math.min(5, stars));
	const bonusPct = stars === 5 ? .2 : stars === 4 ? .1 : 0;
	const bonus = Math.round(job.pay * bonusPct);
	const pool = stars >= 5 ? FIVE : stars === 4 ? FOUR : stars === 3 ? THREE : stars === 2 ? TWO : ONE;
	return {
		stars,
		bonus,
		title: stars >= 5 ? "Excellent" : stars === 4 ? "Great work" : stars === 3 ? "Accepted" : stars === 2 ? "Needs polish" : "Barely cleared",
		review: pick(job.id, stars, pool)
	};
}
function reliabilityFromStars(stars) {
	if (!stars.length) return 0;
	const avg = stars.reduce((a, b) => a + b, 0) / stars.length;
	return Math.round(avg * 10) / 10;
}
function deliveredGigs(records) {
	return records.filter((g) => !g.practice);
}
function gigEarnings(records) {
	return deliveredGigs(records).reduce((n, r) => n + r.pay + r.bonus, 0);
}
function skillCounts(records) {
	const map = /* @__PURE__ */ new Map();
	for (const r of deliveredGigs(records)) for (const skill of r.skills) map.set(skill, (map.get(skill) ?? 0) + 1);
	return [...map.entries()].map(([skill, count]) => ({
		skill,
		count
	})).sort((a, b) => b.count - a.count || a.skill.localeCompare(b.skill));
}
function pickCareer(a, b) {
	const ra = CAREERS.find((c) => c.id === a)?.rank ?? 0;
	return (CAREERS.find((c) => c.id === b)?.rank ?? 0) > ra ? b : a;
}
function mergeGigs(a, b) {
	const byKey = /* @__PURE__ */ new Map();
	const put = (r) => {
		const key = r.practice ? `p:${r.jobId}:${r.completedAt}` : r.jobId;
		const prev = byKey.get(key);
		if (!prev) {
			byKey.set(key, r);
			return;
		}
		if (r.stars > prev.stars || r.stars === prev.stars && r.completedAt > prev.completedAt) byKey.set(key, r);
	};
	for (const r of a) put(r);
	for (const r of b) put(r);
	return [...byKey.values()].sort((x, y) => y.completedAt - x.completedAt);
}
function mergeById(a, b) {
	const map = /* @__PURE__ */ new Map();
	for (const item of [...b, ...a]) map.set(item.id, item);
	return [...map.values()].sort((x, y) => {
		const ax = "at" in x ? Number(x.at) : 0;
		return ("at" in y ? Number(y.at) : 0) - ax;
	});
}
function nicerName(a, b) {
	const an = a.trim();
	const bn = b.trim();
	if (an && an !== "Player") return an.slice(0, 24);
	if (bn && bn !== "Player") return bn.slice(0, 24);
	return an || bn || "Player";
}
function snapshotSave(s) {
	return {
		version: 2,
		playerName: s.playerName,
		hasStarted: s.hasStarted,
		coins: s.coins,
		xp: s.xp,
		completedLevels: [...s.completedLevels],
		unlockedRewards: [...s.unlockedRewards],
		career: s.career,
		highestLevel: s.highestLevel,
		muted: s.muted,
		gigCompletions: [...s.gigCompletions],
		walletLedger: [...s.walletLedger],
		phoneMessages: [...s.phoneMessages],
		unreadGigIds: [...s.unreadGigIds]
	};
}
function mergeSaves(local, remote) {
	const completedLevels = [.../* @__PURE__ */ new Set([...local.completedLevels, ...remote.completedLevels])].sort((a, b) => a - b);
	const gigCompletions = mergeGigs(local.gigCompletions, remote.gigCompletions);
	const walletLedger = mergeById(local.walletLedger, remote.walletLedger);
	const phoneMessages = mergeById(local.phoneMessages, remote.phoneMessages);
	return {
		version: 2,
		playerName: nicerName(local.playerName, remote.playerName),
		hasStarted: local.hasStarted || remote.hasStarted,
		coins: Math.max(local.coins, remote.coins),
		xp: Math.max(local.xp, remote.xp),
		completedLevels,
		unlockedRewards: [.../* @__PURE__ */ new Set([...local.unlockedRewards, ...remote.unlockedRewards])],
		career: pickCareer(local.career, remote.career),
		highestLevel: Math.max(local.highestLevel, remote.highestLevel, ...completedLevels, 0),
		muted: local.muted,
		gigCompletions,
		walletLedger,
		phoneMessages,
		unreadGigIds: [.../* @__PURE__ */ new Set([...local.unreadGigIds, ...remote.unreadGigIds])]
	};
}
function portfolioSummaryText(opts) {
	const delivered = deliveredGigs(opts.records);
	const earned = gigEarnings(delivered);
	return [
		`${opts.name} · ${opts.career}`,
		`${delivered.length} simulated freelance project${delivered.length === 1 ? "" : "s"} · ${earned.toLocaleString()} virtual coins`,
		...delivered.slice(0, 12).map((r) => {
			return `• ${opts.titles[r.jobId] ?? r.jobId} — ${r.stars}/5`;
		}),
		"Simulated clients and pay. Python practice only — not real employment."
	].join("\n");
}
var KEY = "jarvis_career_save";
var defaults = () => ({
	version: 2,
	playerName: "Player",
	hasStarted: false,
	coins: 500,
	xp: 0,
	completedLevels: [],
	unlockedRewards: [],
	career: "rookie",
	highestLevel: 0,
	muted: false,
	gigCompletions: [],
	walletLedger: [],
	phoneMessages: [],
	unreadGigIds: []
});
function asGigRecords(raw) {
	if (!Array.isArray(raw)) return [];
	const out = [];
	for (const item of raw) {
		if (!item || typeof item !== "object") continue;
		const r = item;
		if (typeof r.jobId !== "string") continue;
		out.push({
			jobId: r.jobId,
			completedAt: Number(r.completedAt) || Date.now(),
			stars: Math.max(1, Math.min(5, Math.floor(Number(r.stars) || 3))),
			review: typeof r.review === "string" ? r.review : "",
			skills: Array.isArray(r.skills) ? r.skills.filter((x) => typeof x === "string") : [],
			difficulty: r.difficulty ?? "Easy",
			pay: Math.max(0, Math.floor(Number(r.pay) || 0)),
			bonus: Math.max(0, Math.floor(Number(r.bonus) || 0)),
			xp: Math.max(0, Math.floor(Number(r.xp) || 0)),
			attempts: Math.max(1, Math.floor(Number(r.attempts) || 1)),
			hintsUsed: Math.max(0, Math.floor(Number(r.hintsUsed) || 0)),
			showedSolution: Boolean(r.showedSolution),
			durationSec: Math.max(0, Math.floor(Number(r.durationSec) || 0)),
			practice: Boolean(r.practice)
		});
	}
	return out;
}
function asLedger(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.filter((x) => x && typeof x === "object" && typeof x.id === "string").map((x) => {
		const e = x;
		return {
			id: String(e.id),
			at: Number(e.at) || Date.now(),
			amount: Math.floor(Number(e.amount) || 0),
			label: typeof e.label === "string" ? e.label : "Payment",
			kind: e.kind === "bonus" ? "bonus" : "gig"
		};
	});
}
function asMessages(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.filter((x) => x && typeof x === "object" && typeof x.id === "string").map((x) => {
		const m = x;
		return {
			id: String(m.id),
			from: typeof m.from === "string" ? m.from : "Client",
			company: typeof m.company === "string" ? m.company : "",
			body: typeof m.body === "string" ? m.body : "",
			at: Number(m.at) || Date.now(),
			kind: m.kind === "thanks" || m.kind === "system" ? m.kind : "offer",
			jobId: typeof m.jobId === "string" ? m.jobId : void 0,
			read: Boolean(m.read)
		};
	});
}
function migrate(raw) {
	const base = defaults();
	if (!raw || typeof raw !== "object") return base;
	const s = raw;
	const completed = Array.isArray(s.completedLevels) ? s.completedLevels.filter((n) => typeof n === "number" && n >= 1 && n <= LEVELS.length) : [];
	const rewards = Array.isArray(s.unlockedRewards) ? s.unlockedRewards.filter((x) => typeof x === "string") : [];
	const career = CAREERS.some((c) => c.id === s.career) ? s.career : "rookie";
	const next = {
		...base,
		version: 2,
		playerName: typeof s.playerName === "string" && s.playerName.trim() ? s.playerName.trim().slice(0, 24) : "Player",
		hasStarted: Boolean(s.hasStarted),
		coins: Math.max(0, Math.floor(Number(s.coins) || 0)),
		xp: Math.max(0, Math.floor(Number(s.xp) || 0)),
		completedLevels: [...new Set(completed)],
		unlockedRewards: [...new Set(rewards)],
		career,
		highestLevel: Math.max(0, ...completed, Number(s.highestLevel) || 0),
		muted: Boolean(s.muted),
		gigCompletions: asGigRecords(s.gigCompletions),
		walletLedger: asLedger(s.walletLedger),
		phoneMessages: asMessages(s.phoneMessages),
		unreadGigIds: Array.isArray(s.unreadGigIds) ? s.unreadGigIds.filter((x) => typeof x === "string") : []
	};
	if (!next.unreadGigIds.length && !next.phoneMessages.length && next.highestLevel > 0) {
		const done = new Set(next.gigCompletions.filter((g) => !g.practice).map((g) => g.jobId));
		next.unreadGigIds = unlockedGigs(next.completedLevels).map((g) => g.id).filter((id) => !done.has(id));
	}
	return next;
}
var toastTimer;
function champClaim(p) {
	if (!p.firstClear) return null;
	if (levelById(p.levelId)?.championship) return {
		id: "claim",
		levelId: p.levelId
	};
	return null;
}
function nextAfterComplete(p) {
	if (p.nextLevel > p.prevLevel) return {
		id: "levelup",
		from: p.prevLevel,
		to: p.nextLevel
	};
	if (p.firstClear && p.nextCareer !== p.prevCareer) return {
		id: "hired",
		career: p.nextCareer
	};
	return champClaim(p) ?? { id: "home" };
}
function nextAfterLevelUp(p) {
	if (p.firstClear && p.nextCareer !== p.prevCareer) return {
		id: "hired",
		career: p.nextCareer
	};
	return champClaim(p) ?? { id: "home" };
}
function nextAfterHired(p) {
	return champClaim(p) ?? { id: "home" };
}
function offerMessages(jobs, at) {
	return jobs.map((job) => ({
		id: `offer-${job.id}-${at}`,
		from: job.client,
		company: job.company,
		body: `Posted a gig: ${job.title}. ${job.summary} Simulated listing — not a real job.`,
		at,
		kind: "offer",
		jobId: job.id,
		read: false
	}));
}
var useGame = create()(persist((set, get) => ({
	...defaults(),
	screen: { id: "welcome" },
	tab: "home",
	toast: null,
	hydrated: false,
	shakeLock: 0,
	pending: null,
	phoneOpen: false,
	phoneApp: "home",
	setHydrated: () => {
		const s = get();
		const onGate = s.screen.id === "boot" || s.screen.id === "welcome" || s.screen.id === "home";
		set({
			hydrated: true,
			screen: s.hasStarted ? onGate ? { id: "home" } : s.screen : { id: "welcome" },
			tab: onGate ? "home" : s.tab
		});
		audio.setMuted(s.muted);
	},
	startCareer: () => {
		audio.unlock();
		audio.success();
		set({
			hasStarted: true,
			screen: { id: "home" },
			tab: "home"
		});
	},
	setTab: (tab) => {
		audio.click();
		set({
			tab,
			screen: { id: tab },
			phoneOpen: false
		});
	},
	setName: (name) => {
		set({ playerName: name.trim().slice(0, 24) || "Player" });
	},
	toggleMute: () => {
		const muted = !get().muted;
		audio.setMuted(muted);
		if (!muted) audio.click();
		set({ muted });
	},
	tryPlay: () => {
		const { completedLevels } = get();
		const next = LEVELS.find((l) => !completedLevels.includes(l.id)) ?? LEVELS[LEVELS.length - 1];
		get().openLevel(next.id);
	},
	openLevel: (id) => {
		audio.unlock();
		const { completedLevels } = get();
		if (!isLevelUnlocked(id, completedLevels)) {
			audio.fail();
			set({ shakeLock: Date.now() });
			get().flash(`Complete Level ${id - 1} to unlock.`);
			return;
		}
		audio.click();
		set({
			screen: {
				id: "intro",
				levelId: id
			},
			tab: "home",
			phoneOpen: false
		});
	},
	beginMission: (id) => {
		audio.click();
		const { completedLevels } = get();
		if (!isLevelUnlocked(id, completedLevels)) {
			get().flash("That level is locked.");
			return;
		}
		set({
			screen: {
				id: "play",
				levelId: id
			},
			phoneOpen: false
		});
	},
	abortMission: () => {
		audio.click();
		set({
			screen: { id: "home" },
			tab: "home"
		});
	},
	finishMission: (id, score) => {
		const level = levelById(id);
		if (!level) return;
		const s = get();
		const firstClear = !s.completedLevels.includes(id);
		const prevLevel = playerLevelFromXp(s.xp);
		const prevCareer = s.career;
		const prevMax = s.highestLevel;
		let coins = 0;
		let xp = 0;
		let career = s.career;
		let completedLevels = s.completedLevels;
		let unlockedRewards = s.unlockedRewards;
		let newXp = s.xp;
		let newCoins = s.coins;
		if (firstClear) {
			coins = level.rewardCoins;
			xp = level.rewardXp;
			newXp = s.xp + xp;
			newCoins = s.coins + coins;
			completedLevels = [...s.completedLevels, id];
			if (!unlockedRewards.includes(level.unlockRewardId)) unlockedRewards = [...unlockedRewards, level.unlockRewardId];
			career = level.careerUnlock;
		}
		const pending = {
			firstClear,
			levelId: id,
			prevLevel,
			nextLevel: playerLevelFromXp(newXp),
			prevCareer,
			nextCareer: career
		};
		const nextMax = Math.max(s.highestLevel, id);
		const fresh = firstClear ? gigsNewlyUnlocked(prevMax, nextMax) : [];
		const at = Date.now();
		const phoneMessages = fresh.length ? [...offerMessages(fresh, at), ...s.phoneMessages] : s.phoneMessages;
		const unreadGigIds = fresh.length ? [.../* @__PURE__ */ new Set([...fresh.map((g) => g.id), ...s.unreadGigIds])] : s.unreadGigIds;
		audio.complete();
		set({
			coins: newCoins,
			xp: newXp,
			completedLevels,
			unlockedRewards,
			career,
			highestLevel: nextMax,
			pending,
			phoneMessages,
			unreadGigIds,
			screen: {
				id: "complete",
				levelId: id,
				firstClear,
				coins,
				xp,
				score
			}
		});
		if (fresh.length) get().flash(`${fresh.length} new gig${fresh.length === 1 ? "" : "s"} on your phone.`);
	},
	continueFrom: () => {
		audio.click();
		const { screen, pending } = get();
		if (screen.id === "complete") {
			if (pending) {
				const next = nextAfterComplete(pending);
				if (next.id === "levelup") audio.levelup();
				if (next.id === "hired") audio.unlockReward();
				set({
					screen: next,
					tab: next.id === "home" ? "home" : get().tab
				});
				return;
			}
			set({
				screen: { id: "home" },
				tab: "home"
			});
			return;
		}
		if (screen.id === "levelup") {
			const next = pending ? nextAfterLevelUp(pending) : { id: "home" };
			if (next.id === "hired") audio.unlockReward();
			set({
				screen: next,
				tab: next.id === "home" ? "home" : get().tab
			});
			return;
		}
		if (screen.id === "hired") {
			const next = pending ? nextAfterHired(pending) : { id: "home" };
			set({
				screen: next,
				tab: next.id === "home" ? "home" : get().tab
			});
			return;
		}
		if (screen.id === "claimed") {
			set({
				screen: { id: "home" },
				tab: "home"
			});
			return;
		}
		if (screen.id === "gig-complete") {
			set({
				screen: { id: "home" },
				tab: "home",
				phoneOpen: true,
				phoneApp: "portfolio"
			});
			return;
		}
		set({
			screen: { id: "home" },
			tab: "home"
		});
	},
	claimFinal: () => {
		audio.unlockReward();
		set({ screen: { id: "claimed" } });
	},
	resetProgress: () => {
		const muted = get().muted;
		const playerName = get().playerName;
		set({
			...defaults(),
			muted,
			playerName,
			hasStarted: true,
			screen: { id: "home" },
			tab: "home",
			hydrated: true,
			pending: null,
			phoneOpen: false,
			phoneApp: "home"
		});
		get().flash("Progress reset.");
	},
	flash: (msg) => {
		set({ toast: msg });
		if (toastTimer) clearTimeout(toastTimer);
		toastTimer = setTimeout(() => set({ toast: null }), 2200);
	},
	openPhone: (app) => {
		audio.unlock();
		audio.click();
		const nextApp = app ?? "home";
		const patch = {
			phoneOpen: true,
			phoneApp: nextApp
		};
		if (nextApp === "freelance") patch.unreadGigIds = [];
		if (nextApp === "messages") patch.phoneMessages = get().phoneMessages.map((m) => ({
			...m,
			read: true
		}));
		set(patch);
	},
	closePhone: () => {
		audio.click();
		set({
			phoneOpen: false,
			phoneApp: "home"
		});
	},
	setPhoneApp: (app) => {
		audio.click();
		const patch = { phoneApp: app };
		if (app === "freelance") patch.unreadGigIds = [];
		if (app === "messages") patch.phoneMessages = get().phoneMessages.map((m) => ({
			...m,
			read: true
		}));
		if (app === "learn") {
			set({
				phoneOpen: false,
				phoneApp: "home"
			});
			get().tryPlay();
			return;
		}
		set(patch);
	},
	markMessagesRead: () => {
		set({ phoneMessages: get().phoneMessages.map((m) => ({
			...m,
			read: true
		})) });
	},
	openGig: (jobId) => {
		const job = gigById(jobId);
		if (!job) return;
		const { completedLevels } = get();
		if ((completedLevels.length ? Math.max(...completedLevels) : 0) < job.unlockAfter) {
			audio.fail();
			get().flash(`Clear Level ${job.unlockAfter} to unlock this gig.`);
			return;
		}
		audio.click();
		set({
			phoneOpen: false,
			screen: {
				id: "gig-intro",
				jobId
			},
			tab: "home"
		});
	},
	beginGig: (jobId) => {
		audio.click();
		set({
			screen: {
				id: "gig-play",
				jobId
			},
			phoneOpen: false
		});
	},
	abortGig: () => {
		audio.click();
		set({
			screen: { id: "home" },
			tab: "home",
			phoneOpen: true,
			phoneApp: "freelance"
		});
	},
	finishGig: (jobId, stats) => {
		const job = gigById(jobId);
		if (!job) return;
		const s = get();
		const firstClear = !s.gigCompletions.some((g) => g.jobId === jobId && !g.practice);
		const scored = scoreGig(job, stats);
		const pay = firstClear ? job.pay : 0;
		const bonus = firstClear ? scored.bonus : 0;
		const xp = firstClear ? job.xp : 0;
		const at = Date.now();
		const record = {
			jobId,
			completedAt: at,
			stars: scored.stars,
			review: scored.review,
			skills: job.skills,
			difficulty: job.difficulty,
			pay,
			bonus,
			xp,
			attempts: stats.attempts,
			hintsUsed: stats.hintsUsed,
			showedSolution: stats.showedSolution,
			durationSec: Math.max(1, Math.round(stats.elapsedMs / 1e3)),
			practice: !firstClear
		};
		const ledger = firstClear ? [
			{
				id: `pay-${jobId}-${at}`,
				at,
				amount: pay,
				label: job.title,
				kind: "gig"
			},
			...bonus ? [{
				id: `bonus-${jobId}-${at}`,
				at,
				amount: bonus,
				label: `${scored.stars}-star bonus`,
				kind: "bonus"
			}] : [],
			...s.walletLedger
		] : s.walletLedger;
		const thanks = {
			id: `thanks-${jobId}-${at}`,
			from: job.client,
			company: job.company,
			body: firstClear ? `${scored.review} ${scored.stars} of 5. Simulated review.` : "Practice run received. Pay was already sent on the first delivery.",
			at,
			kind: "thanks",
			jobId,
			read: false
		};
		audio.complete();
		set({
			coins: s.coins + pay + bonus,
			xp: s.xp + xp,
			gigCompletions: [record, ...s.gigCompletions],
			walletLedger: ledger,
			phoneMessages: [thanks, ...s.phoneMessages],
			unreadGigIds: s.unreadGigIds.filter((id) => id !== jobId),
			screen: {
				id: "gig-complete",
				jobId,
				firstClear,
				stars: scored.stars,
				pay,
				bonus,
				xp,
				review: scored.review
			}
		});
	},
	applyRemoteSave: (remote, displayName) => {
		const local = snapshotSave(get());
		const named = displayName && local.playerName === "Player" ? {
			...local,
			playerName: displayName.trim().slice(0, 24) || local.playerName
		} : local;
		const next = remote ? mergeSaves(named, migrate(remote)) : named;
		const screen = get().screen;
		const jumpHome = next.hasStarted && (screen.id === "welcome" || screen.id === "boot");
		set({
			...next,
			screen: jumpHome ? { id: "home" } : screen,
			tab: jumpHome ? "home" : get().tab
		});
	}
}), {
	name: KEY,
	storage: createJSONStorage(() => {
		if (typeof window === "undefined") return {
			getItem: () => null,
			setItem: () => {},
			removeItem: () => {}
		};
		return localStorage;
	}),
	version: 2,
	partialize: (s) => snapshotSave(s),
	merge: (persisted, current) => ({
		...current,
		...migrate(persisted)
	}),
	skipHydration: true
}));
function phoneBadgeCount(s) {
	return s.phoneMessages.filter((m) => !m.read).length + s.unreadGigIds.length;
}
function MissionView({ levelId }) {
	const level = levelById(levelId);
	const abortMission = useGame((s) => s.abortMission);
	if (!level) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Unknown mission." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			onClick: abortMission,
			children: "Back"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionPlay, { level });
}
function MissionPlay({ level }) {
	const finishMission = useGame((s) => s.finishMission);
	const abortMission = useGame((s) => s.abortMission);
	const [step, setStep] = (0, import_react.useState)(0);
	const [failed, setFailed] = (0, import_react.useState)(false);
	const [mistakes, setMistakes] = (0, import_react.useState)(0);
	const [codeDone, setCodeDone] = (0, import_react.useState)(0);
	const [runId, setRunId] = (0, import_react.useState)(0);
	const startedAt = (0, import_react.useRef)(Date.now());
	const totalCode = codeStepCount(level);
	const current = level.steps[step];
	const timed = Boolean(level.timeLimitSec) && current?.type === "code";
	function next() {
		if (step + 1 >= level.steps.length) {
			const elapsed = (Date.now() - startedAt.current) / 1e3;
			const timeBonus = level.championship ? Math.max(0, 10 - Math.floor(elapsed / 12)) : 0;
			const score = level.championship ? Math.max(0, Math.min(100, codeDone * 30 + timeBonus - mistakes * 5)) : void 0;
			finishMission(level.id, score);
			return;
		}
		setStep((s) => s + 1);
	}
	function failTime() {
		audio.fail();
		setFailed(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-10 flex items-center gap-3 border-b border-border bg-bg/95 px-4 py-3 backdrop-blur-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "Abort mission",
						onClick: abortMission,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
							children: ["Level ", String(level.id).padStart(2, "0")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-semibold",
							children: level.title
						})]
					}),
					level.timeLimitSec ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionTimer, {
						seconds: level.timeLimitSec,
						running: timed && !failed,
						onExpire: failTime,
						freeze: failed
					}, runId) : null
				]
			}),
			totalCode > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex gap-2 overflow-x-auto px-4 py-3",
				children: level.steps.filter((s) => s.type === "code").map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cn("flex items-center gap-2 rounded-full px-3 py-1 text-xs", i < codeDone ? "bg-success/15 text-success" : "bg-surface text-muted"),
					children: [i < codeDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }), s.challenge.title.split("—")[0]]
				}, s.challenge.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-xl flex-1 px-4 py-4 pb-10",
				children: failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailCard, {
					championship: Boolean(level.championship),
					onRetry: () => {
						setFailed(false);
						setStep(level.steps.findIndex((s) => s.type === "code"));
						setCodeDone(0);
						setRunId((n) => n + 1);
						startedAt.current = Date.now();
					},
					onQuit: abortMission
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepView, {
					step: current,
					onNext: next,
					onCodePass: () => {
						setCodeDone((n) => n + 1);
						next();
					},
					onMistake: () => setMistakes((n) => n + 1)
				}, step)
			})
		]
	});
}
function StepView({ step, onNext, onCodePass, onMistake }) {
	if (step.type === "brief") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
				children: "Briefing"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-2xl font-semibold tracking-tight",
				children: step.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-[15px] leading-relaxed text-muted",
				children: step.body
			}),
			step.example && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-4 overflow-x-auto rounded-xl bg-surface-2 p-4 font-mono text-sm text-accent",
				children: step.example
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-8 w-full",
				size: "lg",
				onClick: onNext,
				children: "Continue"
			})
		]
	});
	if (step.type === "reaction") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactionStep, {
		title: step.title,
		body: step.body,
		onPass: onNext
	});
	if (step.type === "choice") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceStep, {
		step,
		onPass: onNext
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
		challenge: step.challenge,
		onPass: onCodePass,
		onFail: onMistake
	});
}
function ReactionStep({ title, body, onPass }) {
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [ms, setMs] = (0, import_react.useState)(0);
	const goAt = (0, import_react.useRef)(0);
	const timer = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		return () => window.clearTimeout(timer.current);
	}, []);
	function arm() {
		audio.click();
		setPhase("wait");
		const delay = 800 + Math.random() * 1600;
		goAt.current = Date.now() + delay;
		timer.current = window.setTimeout(() => {
			audio.go();
			setPhase("go");
			goAt.current = Date.now();
		}, delay);
	}
	function tap() {
		if (phase === "wait") {
			window.clearTimeout(timer.current);
			audio.fail();
			setPhase("early");
			return;
		}
		if (phase === "go") {
			const t = Date.now() - goAt.current;
			setMs(t);
			setPhase("done");
			audio.success();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-rise text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-10 flex size-56 items-center justify-center rounded-full bg-surface shadow-[var(--shadow-card)]",
				children: [
					phase === "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium text-muted",
						children: "Ready"
					}),
					phase === "wait" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium tracking-[0.2em] text-subtle",
						children: "WAIT"
					}),
					phase === "go" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-5xl font-semibold tracking-tight text-accent",
						style: { animation: "pulse-ring 0.9s ease-out" },
						children: "GO"
					}),
					phase === "early" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium text-danger",
						children: "Too soon"
					}),
					phase === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-3xl font-semibold tabular text-success",
						children: [ms, " ms"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: ms < 250 ? "Perfect" : ms < 400 ? "Great" : ms < 600 ? "Good" : "Cleared"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [
					phase === "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: arm,
						children: "Arm signal"
					}),
					(phase === "wait" || phase === "go") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "h-16 w-full text-lg",
						onClick: tap,
						variant: phase === "go" ? "primary" : "secondary",
						children: "Action"
					}),
					phase === "early" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: arm,
						children: "Try again"
					}),
					phase === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: onPass,
						children: "Continue"
					})
				]
			})
		]
	});
}
function ChoiceStep({ step, onPass }) {
	const [picked, setPicked] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
				children: step.concept
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-xl font-semibold leading-snug",
				children: step.question
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-col gap-2",
				children: step.options.map((opt) => {
					const shown = picked !== null;
					const isThis = picked?.id === opt.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: shown,
						onClick: () => {
							setPicked(opt);
							if (opt.correct) audio.success();
							else audio.fail();
						},
						className: cn("min-h-12 rounded-lg px-4 py-3 text-left font-mono text-sm shadow-[var(--shadow-card)] transition-transform active:scale-[0.98]", !shown && "bg-surface text-fg hover:shadow-[var(--shadow-card-hover)]", shown && opt.correct && "bg-success/15 text-success", shown && isThis && !opt.correct && "animate-shake bg-danger/15 text-danger", shown && !opt.correct && !isThis && "bg-surface text-subtle"),
						children: opt.label
					}, opt.id);
				})
			}),
			picked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-xl bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: picked.correct ? "Correct" : "Try again"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-muted",
						children: picked.explain
					}),
					!picked.correct && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: ["The right idea: ", step.options.find((o) => o.correct)?.explain]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4 w-full",
						onClick: () => {
							if (picked.correct) onPass();
							else setPicked(null);
						},
						children: picked.correct ? "Continue" : "Choose again"
					})
				]
			})
		]
	});
}
function MissionTimer({ seconds, running, onExpire, freeze }) {
	const [left, setLeft] = (0, import_react.useState)(seconds);
	const origin = (0, import_react.useRef)(null);
	const expired = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!running || freeze) return;
		if (origin.current === null) origin.current = Date.now();
		let raf = 0;
		const tick = () => {
			const elapsed = (Date.now() - origin.current) / 1e3;
			const remain = Math.max(0, seconds - elapsed);
			setLeft(remain);
			if (remain <= 0 && !expired.current) {
				expired.current = true;
				onExpire();
				return;
			}
			raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [
		running,
		freeze,
		seconds,
		onExpire
	]);
	(0, import_react.useEffect)(() => {
		origin.current = Date.now();
		expired.current = false;
		setLeft(seconds);
	}, [seconds]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-1.5 rounded-full bg-surface px-3 py-1.5 font-mono text-sm tabular", left <= 10 && "text-danger"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-4" }), Math.ceil(left)]
	});
}
function FailCard({ championship, onRetry, onQuit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-rise rounded-xl bg-surface p-6 text-center shadow-[var(--shadow-card)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-danger",
				children: "Time"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-2xl font-semibold",
				children: championship ? "Championship timed out" : "Mission failed"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "The clock hit zero. Progress in this attempt is not saved. Retry the timed tasks."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: onRetry,
					children: "Retry"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onQuit,
					children: "Return home"
				})]
			})
		]
	});
}
function LevelIntro({ levelId }) {
	const level = levelById(levelId);
	const beginMission = useGame((s) => s.beginMission);
	const abortMission = useGame((s) => s.abortMission);
	const completed = useGame((s) => s.completedLevels);
	if (!level) return null;
	const practice = completed.includes(level.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "flex items-center gap-3 px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": "Back",
				onClick: abortMission,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-xl flex-1 px-5 pb-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
					children: ["Level ", String(level.id).padStart(2, "0")]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-semibold tracking-tight",
					children: level.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: level.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-8 space-y-3 rounded-xl bg-surface p-5 shadow-[var(--shadow-card)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							k: "Difficulty",
							v: level.difficulty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							k: "Objective",
							v: level.objective
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							k: "Reward",
							v: `+${level.rewardCoins.toLocaleString()} coins  ·  +${level.rewardXp} XP`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							k: "Unlock",
							v: level.unlockReward
						}),
						practice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
							k: "Status",
							v: "Practice — rewards already claimed"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "mt-8 w-full",
					onClick: () => beginMission(level.id),
					children: "Start mission"
				})
			]
		})]
	});
}
function Row$1({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs uppercase tracking-[0.12em] text-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "max-w-[60%] text-right text-sm font-medium",
			children: v
		})]
	});
}
function StarRow({ value, size = "sm" }) {
	const cls = size === "md" ? "size-5" : "size-3.5";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex items-center gap-0.5",
		"aria-label": `${value} of 5 stars`,
		children: [
			1,
			2,
			3,
			4,
			5
		].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn(cls, n <= value ? "fill-accent text-accent" : "text-lock") }, n))
	});
}
function GigIntro({ jobId }) {
	const job = gigById(jobId);
	const beginGig = useGame((s) => s.beginGig);
	const abortGig = useGame((s) => s.abortGig);
	const done = useGame((s) => s.gigCompletions.some((g) => g.jobId === jobId && !g.practice));
	if (!job) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "flex items-center gap-3 px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": "Back",
				onClick: abortGig,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-xl flex-1 px-5 pb-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
					children: ["Simulated gig · ", categoryLabel(job.category)]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-semibold tracking-tight",
					children: job.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted",
					children: [
						job.client,
						" · ",
						job.company
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-[15px] leading-relaxed text-muted",
					children: job.brief
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-8 space-y-3 rounded-xl bg-surface p-5 shadow-[var(--shadow-card)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Difficulty",
							v: job.difficulty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Skills",
							v: job.skills.join(" · ")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Pay",
							v: done ? "Practice — pay already sent" : `+${job.pay.toLocaleString()} coins  ·  +${job.xp} XP`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Bonus",
							v: "Up to 20% for a 5-star first delivery"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs leading-relaxed text-subtle",
					children: SIM_DISCLAIMER
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "mt-8 w-full",
					onClick: () => beginGig(job.id),
					children: done ? "Practice the contract" : "Accept contract"
				})
			]
		})]
	});
}
function GigPlay({ jobId }) {
	const job = gigById(jobId);
	const abortGig = useGame((s) => s.abortGig);
	const finishGig = useGame((s) => s.finishGig);
	if (!job) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Unknown gig." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			onClick: abortGig,
			children: "Back"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-10 flex items-center gap-3 border-b border-border bg-bg/95 px-4 py-3 backdrop-blur-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Abort gig",
					onClick: abortGig,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
						children: job.company
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-semibold",
						children: job.title
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs tabular text-accent",
					children: ["+", job.pay.toLocaleString()]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-xl flex-1 px-4 py-4 pb-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm leading-relaxed text-muted",
				children: job.brief
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
				challenge: job.challenge,
				fileName: "contract.py",
				onPass: (stats) => finishGig(job.id, stats)
			})]
		})]
	});
}
function GigCompleteScreen() {
	const screen = useGame((s) => s.screen);
	const continueFrom = useGame((s) => s.continueFrom);
	if (screen.id !== "gig-complete") return null;
	const job = gigById(screen.jobId);
	if (!job) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center bg-bg px-6 py-10 text-center text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "animate-rise w-full max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
					children: screen.firstClear ? "Payment received" : "Practice run"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-3xl font-semibold tracking-tight",
					children: job.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						job.client,
						" · ",
						job.company
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarRow, {
						value: screen.stars,
						size: "md"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 rounded-xl bg-surface p-4 text-left shadow-[var(--shadow-card)]",
					children: [
						screen.firstClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-lg tabular text-accent",
								children: [
									"+",
									screen.pay.toLocaleString(),
									" coins"
								]
							}),
							screen.bonus > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-sm tabular text-accent",
								children: [
									"+",
									screen.bonus.toLocaleString(),
									" quality bonus"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-lg tabular text-accent",
								children: [
									"+",
									screen.xp,
									" XP"
								]
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Practice run. Pay and XP were already claimed."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed",
							children: screen.review
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-subtle",
							children: SIM_DISCLAIMER
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "mt-8 w-full",
					onClick: continueFrom,
					children: "Add to portfolio"
				})
			]
		})
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs uppercase tracking-[0.12em] text-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "max-w-[62%] text-right text-sm font-medium",
			children: v
		})]
	});
}
function PortfolioApp() {
	const gigCompletions = useGame((s) => s.gigCompletions);
	const xp = useGame((s) => s.xp);
	const name = useGame((s) => s.playerName);
	const career = useGame((s) => s.career);
	const setPhoneApp = useGame((s) => s.setPhoneApp);
	const flash = useGame((s) => s.flash);
	const [sort, setSort] = (0, import_react.useState)("recent");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const delivered = (0, import_react.useMemo)(() => deliveredGigs(gigCompletions), [gigCompletions]);
	const prog = xpProgress(xp);
	const avg = reliabilityFromStars(delivered.map((r) => r.stars));
	const earned = gigEarnings(delivered);
	const skills = (0, import_react.useMemo)(() => skillCounts(gigCompletions).slice(0, 6), [gigCompletions]);
	const sorted = (0, import_react.useMemo)(() => {
		const rows = [...delivered];
		if (sort === "stars") rows.sort((a, b) => b.stars - a.stars || b.completedAt - a.completedAt);
		else if (sort === "pay") rows.sort((a, b) => b.pay + b.bonus - (a.pay + a.bonus) || b.completedAt - a.completedAt);
		else rows.sort((a, b) => b.completedAt - a.completedAt);
		return rows;
	}, [delivered, sort]);
	if (!delivered.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface px-4 py-6 text-center shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-auto flex size-12 items-center justify-center rounded-md bg-accent/15 text-accent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderKanban, { className: "size-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-semibold",
					children: "No projects yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Finish a learning mission, take a freelance gig, and the client review lands here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4 w-full",
					onClick: () => setPhoneApp("freelance"),
					children: "Open freelance desk"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] leading-relaxed text-subtle",
			children: SIM_DISCLAIMER
		})]
	});
	const copy = async () => {
		const titles = {};
		for (const r of delivered) {
			const job = gigById(r.jobId);
			if (job) titles[r.jobId] = job.title;
		}
		const text = portfolioSummaryText({
			name,
			career: careerById(career).title,
			records: delivered,
			titles
		});
		try {
			await navigator.clipboard.writeText(text);
			flash("Portfolio copied.");
		} catch {
			flash("Could not copy.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-card)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
						children: "Career experience"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-lg font-semibold tracking-tight",
						children: [
							name,
							" · ",
							careerById(career).title
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-sm tabular text-muted",
						children: [
							delivered.length,
							" project",
							delivered.length === 1 ? "" : "s",
							" · LV ",
							String(prog.level).padStart(2, "0")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
								k: "Reliability",
								v: avg ? `${avg}` : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
								k: "Earned",
								v: earned.toLocaleString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
								k: "Stars",
								v: avg ? `${avg}/5` : "—"
							})
						]
					}),
					skills.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-wrap gap-1.5",
						children: skills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-full bg-bg-elevated px-2.5 py-1 text-[11px] font-medium text-muted",
							children: s.skill
						}, s.skill))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [[
					"recent",
					"stars",
					"pay"
				].map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSort(key),
					className: cn("h-9 rounded-full px-3 text-[11px] font-medium uppercase tracking-[0.12em]", sort === key ? "bg-surface-2 text-accent" : "bg-surface text-subtle"),
					children: key === "recent" ? "Recent" : key === "stars" ? "Stars" : "Pay"
				}, key)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void copy(),
					className: "ml-auto flex size-9 items-center justify-center rounded-md text-muted",
					"aria-label": "Copy portfolio",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: sorted.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortfolioCard, {
					record: r,
					latest: i === 0 && sort === "recent",
					open: openId === `${r.jobId}-${r.completedAt}`,
					onToggle: () => setOpenId((cur) => cur === `${r.jobId}-${r.completedAt}` ? null : `${r.jobId}-${r.completedAt}`)
				}, `${r.jobId}-${r.completedAt}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] leading-relaxed text-subtle",
				children: SIM_DISCLAIMER
			})
		]
	});
}
function Stat$1({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-bg-elevated px-2 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-[10px] uppercase tracking-[0.12em] text-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-0.5 font-mono text-sm tabular",
			children: v
		})]
	});
}
function PortfolioCard({ record, latest, open, onToggle }) {
	const job = gigById(record.jobId);
	const title = job?.title ?? "Retired listing";
	const client = job?.client ?? "Client";
	const company = job?.company ?? "Studio";
	const when = new Date(record.completedAt).toLocaleDateString(void 0, {
		month: "short",
		day: "numeric"
	});
	const initial = company.slice(0, 1).toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-card)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onToggle,
			className: "w-full px-3 py-3 text-left",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-md bg-accent/15 font-semibold text-accent",
							children: initial
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate font-semibold",
										children: title
									}), latest && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "shrink-0 text-[10px] font-medium uppercase tracking-[0.12em] text-accent",
										children: "Latest"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block truncate text-xs text-muted",
									children: [
										client,
										" · ",
										company
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarRow, { value: record.stars }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-[11px] tabular text-accent",
										children: ["+", (record.pay + record.bonus).toLocaleString()]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("mt-1 size-4 shrink-0 text-subtle transition-transform", open && "rotate-180") })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-snug text-fg",
					children: record.review
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-[11px] text-subtle",
					children: [
						(record.skills.length ? record.skills : job?.skills ?? []).join(" · "),
						" · ",
						record.difficulty,
						" · ",
						when
					]
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-border px-3 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: job?.brief ?? job?.summary ?? "Listing retired from the desk."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-3 grid grid-cols-2 gap-2 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "uppercase tracking-[0.12em] text-subtle",
						children: "Category"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-0.5",
						children: job ? categoryLabel(job.category) : "—"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "uppercase tracking-[0.12em] text-subtle",
						children: "Time"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-0.5 font-mono tabular",
						children: [record.durationSec, "s"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "uppercase tracking-[0.12em] text-subtle",
						children: "Attempts"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-0.5 font-mono tabular",
						children: record.attempts
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "uppercase tracking-[0.12em] text-subtle",
						children: "Hints"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-0.5",
						children: record.showedSolution ? "Used working code" : `${record.hintsUsed} used`
					})] })
				]
			})]
		})]
	});
}
function PortfolioTeaser() {
	const openPhone = useGame((s) => s.openPhone);
	const n = deliveredGigs(useGame((s) => s.gigCompletions)).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => openPhone("portfolio"),
		className: "mt-4 flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-card)] active:scale-[0.99]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
				children: "Portfolio"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 font-semibold",
				children: n ? `${n} shipped project${n === 1 ? "" : "s"}` : "Build a client book"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: n ? "Reviews, pay, and skills from simulated gigs." : "Deliver a freelance gig to pin it here."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 text-subtle" })]
	});
}
function resolveSignInGateState(input) {
	if (input.isPending) return "pending";
	return input.hasUser ? "signed_in" : "signed_out";
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
function SignInGate({ children, fallback }) {
	const { user, isPending } = useCurrentUserState();
	const state = resolveSignInGateState({
		isPending,
		hasUser: user !== null
	});
	if (state === "pending") return null;
	if (state === "signed_in") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: fallback ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInButtons, {}) });
}
function SignInButtons() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex w-full max-w-sm flex-col gap-2",
		children: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => signIn(p.providerId, {
				callbackURL: "/",
				errorCallbackURL: "/login"
			}),
			className: "w-full cursor-pointer rounded-md border border-neutral-300 px-4 py-2 hover:bg-neutral-100 dark:border-neutral-700 dark:hover:bg-neutral-900",
			children: ["Continue with ", p.label]
		}, p.providerId))
	});
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
function AccountCard({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-card)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
			children: "Account"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInGate, {
			fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2",
				children: [!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "Sign in with Google to keep your missions and portfolio on this account."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					className: "inline-flex h-11 w-full items-center justify-center rounded-md bg-accent px-4 text-sm font-medium text-accent-fg",
					children: "Sign in with Google"
				})]
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-relaxed text-muted",
					children: "Progress syncs to this Google account across devices."
				})]
			})
		})]
	});
}
function useClock() {
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const t = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 15e3);
		return () => window.clearInterval(t);
	}, []);
	return now.toLocaleTimeString([], {
		hour: "numeric",
		minute: "2-digit"
	});
}
function PhoneHost() {
	const open = useGame((s) => s.phoneOpen);
	const closePhone = useGame((s) => s.closePhone);
	const screen = useGame((s) => s.screen);
	if (!useGame((s) => s.hasStarted) || screen.id === "welcome" || screen.id === "boot" || screen.id === "play" || screen.id === "gig-play" || !open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Close phone",
			className: "absolute inset-0 bg-bg/85",
			onClick: closePhone
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "phone-rise relative z-[1] mb-[max(0.5rem,env(safe-area-inset-bottom))] w-[min(24.5rem,calc(100vw-1.25rem))] sm:mb-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneDevice, {})
		})]
	});
}
function PhoneDevice() {
	const app = useGame((s) => s.phoneApp);
	const closePhone = useGame((s) => s.closePhone);
	const setPhoneApp = useGame((s) => s.setPhoneApp);
	const time = useClock();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden rounded-[2rem] border border-border bg-bg-elevated shadow-[var(--shadow-phone)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-1/2 top-2 z-10 h-5 w-24 -translate-x-1/2 rounded-full bg-bg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-[min(44rem,calc(100dvh-2.5rem))] flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-6 pb-1 pt-8 text-[11px] font-medium text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular",
							children: time
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tracking-[0.14em] text-subtle",
							children: "JARVISNET"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular",
							children: "84%"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 overflow-y-auto px-3 pb-2 pt-1",
					children: app === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeGrid, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFrame, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-2 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-1",
					children: [app !== "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setPhoneApp("home"),
						className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
						children: "Home"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Put phone away",
						onClick: closePhone,
						className: "h-1.5 w-28 rounded-full bg-subtle/80"
					})]
				})
			]
		})]
	});
}
var APPS = [
	{
		id: "messages",
		label: "Inbox",
		icon: MessageSquare
	},
	{
		id: "freelance",
		label: "Gigs",
		icon: Briefcase,
		dock: true
	},
	{
		id: "portfolio",
		label: "Portfolio",
		icon: FolderKanban,
		dock: true
	},
	{
		id: "wallet",
		label: "Wallet",
		icon: Wallet,
		dock: true
	},
	{
		id: "reviews",
		label: "Reviews",
		icon: Star
	},
	{
		id: "learn",
		label: "Learn",
		icon: BookOpen,
		dock: true
	},
	{
		id: "settings",
		label: "Settings",
		icon: Settings
	}
];
function HomeGrid() {
	const setPhoneApp = useGame((s) => s.setPhoneApp);
	const name = useGame((s) => s.playerName);
	const career = useGame((s) => s.career);
	const unreadGigs = useGame((s) => s.unreadGigIds.length);
	const unreadMail = useGame((s) => s.phoneMessages.filter((m) => !m.read).length);
	const completed = useGame((s) => s.completedLevels);
	const gigDone = useGame((s) => s.gigCompletions);
	const nextLearn = nextLevelId(completed);
	const featured = featuredGig(completed, (0, import_react.useMemo)(() => new Set(gigDone.filter((g) => !g.practice).map((g) => g.jobId)), [gigDone]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col px-1 pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.16em] text-subtle",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-0.5 text-2xl font-semibold tracking-tight",
				children: careerById(career).title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: featured ? `Open gig · ${featured.title}` : completed.length ? "All unlocked gigs delivered. Keep learning." : "Clear Level 01 to open the freelance desk."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-5 grid grid-cols-4 gap-x-2 gap-y-4",
				children: APPS.filter((a) => !a.dock).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
					label: a.label,
					icon: a.icon,
					badge: a.id === "messages" ? unreadMail : 0,
					onClick: () => setPhoneApp(a.id)
				}) }, a.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-auto rounded-[1.4rem] bg-surface p-2 shadow-[var(--shadow-card)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-4",
					children: APPS.filter((a) => a.dock).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
						label: a.label,
						icon: a.icon,
						badge: a.id === "freelance" ? unreadGigs : 0,
						onClick: () => setPhoneApp(a.id)
					}) }, a.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-center text-[10px] text-subtle",
				children: ["Next lesson · Level ", String(nextLearn).padStart(2, "0")]
			})
		]
	});
}
function AppIcon({ label, icon: Icon, badge, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex w-full flex-col items-center gap-1.5 active:scale-[0.96]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "relative flex size-12 items-center justify-center rounded-2xl bg-surface-2 text-fg shadow-[var(--shadow-card)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), badge > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-1 font-mono text-[10px] text-fg",
				children: badge > 9 ? "9+" : badge
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[10px] font-medium text-muted",
			children: label
		})]
	});
}
function AppFrame() {
	const app = useGame((s) => s.phoneApp);
	const setPhoneApp = useGame((s) => s.setPhoneApp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-center gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setPhoneApp("home"),
				className: "flex size-10 items-center justify-center rounded-md text-muted",
				"aria-label": "Back to home",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold tracking-tight",
				children: app === "messages" ? "Inbox" : app === "freelance" ? "Freelance" : app === "portfolio" ? "Portfolio" : app === "wallet" ? "Wallet" : app === "reviews" ? "Reviews" : app === "settings" ? "Settings" : app === "learn" ? "Learn" : "Phone"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pb-2",
			children: [
				app === "messages" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesApp, {}),
				app === "freelance" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FreelanceApp, {}),
				app === "portfolio" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortfolioApp, {}),
				app === "wallet" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletApp, {}),
				app === "reviews" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewsApp, {}),
				app === "learn" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LearnApp, {}),
				app === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsApp, {})
			]
		})]
	});
}
function MessagesApp() {
	const messages = useGame((s) => s.phoneMessages);
	const openGig = useGame((s) => s.openGig);
	if (!messages.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		title: "No messages yet",
		body: "Finish a learning level to get simulated client pings when gigs unlock."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => m.jobId && openGig(m.jobId),
			className: "w-full rounded-xl bg-surface px-3 py-3 text-left shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-semibold",
						children: m.from
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "shrink-0 text-[10px] uppercase tracking-[0.12em] text-subtle",
						children: m.kind === "offer" ? "Offer" : m.kind === "thanks" ? "Review" : "Note"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-muted",
					children: m.company
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-snug text-muted",
					children: m.body
				})
			]
		}) }, m.id))
	});
}
function FreelanceApp() {
	const completed = useGame((s) => s.completedLevels);
	const done = useGame((s) => s.gigCompletions);
	const openGig = useGame((s) => s.openGig);
	const doneIds = (0, import_react.useMemo)(() => new Set(done.filter((g) => !g.practice).map((g) => g.jobId)), [done]);
	const openCount = unlockedGigs(completed).filter((g) => !doneIds.has(g.id)).length;
	const max = completed.length ? Math.max(...completed) : 0;
	if (max < 1) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		title: "Desk is closed",
		body: "Complete Level 01 in Learn. Freelance gigs unlock with each skill."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted",
			children: [
				openCount,
				" open · ",
				doneIds.size,
				" delivered. ",
				SIM_DISCLAIMER
			]
		}), GIG_LANES.map((lane) => {
			const locked = max < lane.unlockAfter;
			const jobs = locked ? [] : unlockedGigs(completed).filter((g) => g.lane === lane.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
					children: lane.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs text-muted",
					children: lane.blurb
				}),
				locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-xl bg-surface px-3 py-3 text-sm text-subtle shadow-[var(--shadow-card)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }),
						"Clear Level ",
						String(lane.unlockAfter).padStart(2, "0"),
						" to open this desk."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: jobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GigRow, {
						job,
						done: doneIds.has(job.id),
						onOpen: () => openGig(job.id)
					}, job.id))
				})
			] }, lane.id);
		})]
	});
}
function LearnApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		title: "Opening a mission",
		body: "Learn jumps into your next unlocked Python level."
	});
}
function GigRow({ job, done, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onOpen,
		className: "flex w-full items-center gap-3 rounded-xl bg-surface px-3 py-3 text-left shadow-[var(--shadow-card)] active:scale-[0.99]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block truncate font-medium",
				children: job.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "block text-xs text-muted",
				children: [
					job.company,
					" · ",
					categoryLabel(job.category),
					" · ",
					job.difficulty
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "shrink-0 text-right",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "block font-mono text-xs tabular text-accent",
				children: ["+", job.pay.toLocaleString()]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-[10px] uppercase tracking-[0.12em] text-subtle",
				children: done ? "Replay" : "Open"
			})]
		})]
	}) });
}
function WalletApp() {
	const coins = useGame((s) => s.coins);
	const ledger = useGame((s) => s.walletLedger);
	const earned = ledger.reduce((n, e) => n + e.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface px-4 py-4 shadow-[var(--shadow-card)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.14em] text-subtle",
						children: "Balance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-mono text-3xl tabular text-accent",
						children: coins.toLocaleString()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							"Virtual coins. Freelance earned ",
							earned.toLocaleString(),
							"."
						]
					})
				]
			}),
			ledger.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-card)]",
				children: ledger.slice(0, 20).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between px-3 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm",
							children: e.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase tracking-[0.12em] text-subtle",
							children: e.kind === "bonus" ? "Bonus" : "Gig"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-sm tabular text-accent",
						children: ["+", e.amount.toLocaleString()]
					})]
				}, e.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "No gig payouts yet",
				body: "Deliver a contract from Freelance. Mission coins still sit in this balance."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] leading-relaxed text-subtle",
				children: SIM_DISCLAIMER
			})
		]
	});
}
function ReviewsApp() {
	const records = useGame((s) => s.gigCompletions).filter((g) => !g.practice);
	if (!records.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		title: "No reviews yet",
		body: "Clients write a simulated review after you ship a gig."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
		className: "flex flex-col gap-2",
		children: [records.map((r) => {
			const job = gigById(r.jobId);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-card)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-semibold",
							children: job?.client ?? "Client"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarRow, { value: r.stars })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: job?.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-snug",
						children: r.review
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[11px] text-subtle",
						children: [
							r.difficulty,
							" · ",
							r.showedSolution ? "Used working code" : `${r.attempts} attempt${r.attempts === 1 ? "" : "s"}`
						]
					})
				]
			}, r.jobId + r.completedAt);
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] leading-relaxed text-subtle",
			children: SIM_DISCLAIMER
		})]
	});
}
function SettingsApp() {
	const muted = useGame((s) => s.muted);
	const toggleMute = useGame((s) => s.toggleMute);
	const name = useGame((s) => s.playerName);
	const setName = useGame((s) => s.setName);
	const [draft, setDraft] = (0, import_react.useState)(name);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountCard, { compact: true }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block rounded-xl bg-surface px-3 py-3 text-[11px] font-medium uppercase tracking-[0.14em] text-subtle shadow-[var(--shadow-card)]",
				children: ["Player", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: draft,
					maxLength: 24,
					onChange: (e) => setDraft(e.target.value),
					onBlur: () => setName(draft),
					className: "mt-1 h-11 w-full rounded-md bg-bg-elevated px-3 text-base font-normal normal-case tracking-normal text-fg outline-none"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: toggleMute,
				className: "flex h-12 items-center justify-between rounded-xl bg-surface px-3 text-left shadow-[var(--shadow-card)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm",
					children: "Sound"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: muted ? "Muted" : "On"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl bg-surface px-3 py-3 text-xs leading-relaxed text-muted shadow-[var(--shadow-card)]",
				children: ["The phone, freelance board, coins, and reviews are a game simulation. Learning missions are real Python practice in a safe in-browser interpreter. ", SIM_DISCLAIMER]
			})
		]
	});
}
function Empty({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-4 py-6 text-center shadow-[var(--shadow-card)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-semibold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: body
		})]
	});
}
function PhoneFab() {
	const openPhone = useGame((s) => s.openPhone);
	const phoneOpen = useGame((s) => s.phoneOpen);
	const screen = useGame((s) => s.screen);
	const hasStarted = useGame((s) => s.hasStarted);
	const badge = phoneBadgeCount({
		unreadGigIds: useGame((s) => s.unreadGigIds),
		phoneMessages: useGame((s) => s.phoneMessages)
	});
	if (!hasStarted || phoneOpen || screen.id === "welcome" || screen.id === "boot" || screen.id === "play" || screen.id === "gig-play" || screen.id === "intro" || screen.id === "gig-intro") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => openPhone("home"),
		"aria-label": badge ? `Open phone, ${badge} new` : "Open phone",
		className: "fixed bottom-[5.5rem] right-4 z-30 flex size-14 items-center justify-center rounded-full bg-accent text-accent-fg shadow-[var(--shadow-play)] active:scale-[0.96] sm:bottom-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-6" }), badge > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-danger px-1 font-mono text-[11px] text-fg",
			children: badge > 9 ? "9+" : badge
		})]
	});
}
function PhoneHeaderButton() {
	const openPhone = useGame((s) => s.openPhone);
	const badge = phoneBadgeCount({
		unreadGigIds: useGame((s) => s.unreadGigIds),
		phoneMessages: useGame((s) => s.phoneMessages)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => openPhone("home"),
		"aria-label": badge ? `Open phone, ${badge} new` : "Open phone",
		className: "relative flex size-11 items-center justify-center rounded-md text-muted hover:text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-5" }), badge > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-1.5 top-1.5 size-2 rounded-full bg-danger" })]
	});
}
function PhoneTeaser() {
	const openPhone = useGame((s) => s.openPhone);
	const completed = useGame((s) => s.completedLevels);
	const unread = useGame((s) => s.unreadGigIds.length);
	const max = completed.length ? Math.max(...completed) : 0;
	const open = unlockedGigs(completed).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => openPhone(max < 1 ? "home" : "freelance"),
		className: "mt-4 flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-card)] active:scale-[0.99]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
				children: "In-game phone"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 font-semibold",
				children: max < 1 ? "Unlock freelance after Level 01" : "Freelance desk"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: max < 1 ? "Learn first, then take simulated client gigs." : unread ? `${unread} new listing${unread === 1 ? "" : "s"} · ${open} unlocked` : `${open} gigs unlocked · simulated clients`
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-subtle" })]
	});
}
var loadCareerSave = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("324e8bfefafe55cfcbd7a484a30a1b0ec2f14251e8fba8afa43f0dcfc8f85ef4"));
var saveCareerSave = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("832a0ef1c5e5f85cdf5206a9245c7ed780c084f88142d28a17f27d07ae4a6612"));
function isUnauthorized(err) {
	if (!err || typeof err !== "object") return false;
	const e = err;
	return e.status === 401 || e.message === "Unauthorized";
}
function CloudSaveSync() {
	const { user, isPending } = useCurrentUserState();
	const hydrated = useGame((s) => s.hydrated);
	const applyRemoteSave = useGame((s) => s.applyRemoteSave);
	const userId = user && !user.isDevFallback ? user.id : null;
	const displayName = user?.displayName ?? null;
	const pulling = (0, import_react.useRef)(false);
	const lastJson = (0, import_react.useRef)("");
	const timer = (0, import_react.useRef)(void 0);
	(0, import_react.useEffect)(() => {
		if (isPending || !hydrated || !userId) return;
		let alive = true;
		pulling.current = true;
		loadCareerSave().then((remote) => {
			if (!alive) return;
			applyRemoteSave(remote, displayName);
			const snap = snapshotSave(useGame.getState());
			lastJson.current = JSON.stringify(snap);
			return saveCareerSave({ data: snap });
		}).catch((err) => {
			if (!isUnauthorized(err)) console.warn("career save load failed", err);
		}).finally(() => {
			pulling.current = false;
		});
		return () => {
			alive = false;
		};
	}, [
		applyRemoteSave,
		displayName,
		hydrated,
		isPending,
		userId
	]);
	(0, import_react.useEffect)(() => {
		if (!userId) return;
		const unsub = useGame.subscribe((state) => {
			if (!state.hydrated || pulling.current) return;
			const snap = snapshotSave(state);
			const json = JSON.stringify(snap);
			if (json === lastJson.current) return;
			lastJson.current = json;
			if (timer.current) clearTimeout(timer.current);
			timer.current = setTimeout(() => {
				saveCareerSave({ data: snap }).catch((err) => {
					if (!isUnauthorized(err)) console.warn("career save write failed", err);
				});
			}, 700);
		});
		return () => {
			unsub();
			if (timer.current) clearTimeout(timer.current);
		};
	}, [userId]);
	return null;
}
function AppHeader() {
	const playerName = useGame((s) => s.playerName);
	const xp = useGame((s) => s.xp);
	const coins = useGame((s) => s.coins);
	const muted = useGame((s) => s.muted);
	const toggleMute = useGame((s) => s.toggleMute);
	const prog = xpProgress(xp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-20 border-b border-border bg-bg/95 px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))] backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-xl items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-[11px] font-medium uppercase tracking-[0.16em] text-subtle",
						children: playerName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-lg font-semibold tabular leading-tight",
						children: ["LV ", String(prog.level).padStart(2, "0")]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-surface px-3 py-1.5 text-right shadow-[var(--shadow-card)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.14em] text-subtle",
						children: "Coins"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm tabular text-accent",
						children: coins.toLocaleString()
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneHeaderButton, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: toggleMute,
					"aria-label": muted ? "Unmute" : "Mute",
					className: "flex size-11 items-center justify-center rounded-md text-muted hover:text-fg",
					children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
				})
			]
		})
	});
}
function XpBar({ compact }) {
	const prog = xpProgress(useGame((s) => s.xp));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1.5 flex items-baseline justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
			children: "XP"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-mono text-xs tabular text-muted",
			children: [
				prog.current,
				" / ",
				prog.needed
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 overflow-hidden rounded-full bg-surface-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative h-full rounded-full bg-accent transition-[width] duration-500 ease-[var(--ease-out)]",
			style: { width: `${Math.max(4, prog.ratio * 100)}%` },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-0 overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute inset-y-0 w-8 bg-fg/25",
					style: { animation: "bar-shine 1.8s ease-in-out infinite" }
				})
			})
		})
	})] });
}
var TABS = [
	{
		id: "home",
		label: "Home",
		icon: House
	},
	{
		id: "career",
		label: "Career",
		icon: Briefcase
	},
	{
		id: "rewards",
		label: "Rewards",
		icon: Gift
	},
	{
		id: "profile",
		label: "Profile",
		icon: User
	}
];
function BottomNav() {
	const tab = useGame((s) => s.tab);
	const setTab = useGame((s) => s.setTab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "sticky bottom-0 z-20 border-t border-border bg-bg-elevated/95 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mx-auto grid max-w-xl grid-cols-4",
			children: TABS.map((t) => {
				const Icon = t.icon;
				const on = tab === t.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab(t.id),
					className: cn("flex h-14 w-full flex-col items-center justify-center gap-0.5 text-[11px] font-medium", on ? "text-accent" : "text-subtle hover:text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: on ? 2.4 : 2
					}), t.label]
				}) }, t.id);
			})
		})
	});
}
function ToastHost() {
	const toast = useGame((s) => s.toast);
	if (!toast) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 top-16 z-40 flex justify-center px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "animate-rise rounded-full bg-surface-2 px-4 py-2 text-sm text-fg shadow-[var(--shadow-card)]",
			children: toast
		})
	});
}
function Shell({ children }) {
	const title = careerById(useGame((s) => s.career)).title;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-xl flex-1 px-4 pb-6 pt-4",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "sr-only",
				children: ["Current career ", title]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToastHost, {})
		]
	});
}
function CarMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 120 48",
		className,
		"aria-hidden": "true",
		fill: "none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 32h84c2 0 6-2 8-6 1-3-1-6-4-7l-14-4-8-9H42L28 19H14c-4 0-8 3-8 7v4c0 1 1 2 3 2h9",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "34",
				cy: "34",
				r: "7",
				stroke: "currentColor",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "86",
				cy: "34",
				r: "7",
				stroke: "currentColor",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M44 20h28l6 8H36l8-8z",
				stroke: "currentColor",
				strokeWidth: "2"
			})
		]
	});
}
function HomeScreen() {
	const career = useGame((s) => s.career);
	const completed = useGame((s) => s.completedLevels);
	const tryPlay = useGame((s) => s.tryPlay);
	const openLevel = useGame((s) => s.openLevel);
	const cur = careerById(career);
	const nxt = nextCareer(career);
	const nextId = nextLevelId(completed);
	const nextLv = LEVELS.find((l) => l.id === nextId);
	const allDone = completed.length >= LEVELS.length;
	const reward = nextLv.unlockReward;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "animate-rise rounded-3xl bg-surface p-5 shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-subtle",
					children: "Current career"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-semibold tracking-tight",
					children: cur.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: nxt ? `Next job · ${nxt.title}` : "Peak rank reached"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(XpBar, {})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "lg",
			className: "mt-5 h-14 w-full text-lg",
			onClick: tryPlay,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 translate-x-px" }), allDone ? "Replay last mission" : "Play"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneTeaser, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortfolioTeaser, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => openLevel(nextLv.id),
			className: "mt-4 flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-card)] active:scale-[0.99]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
					children: allDone ? "Last reward" : "Next reward"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 font-semibold",
					children: reward
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: allDone ? "Championship cleared" : `${nextLv.title} · +${nextLv.rewardCoins.toLocaleString()} coins`
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-subtle" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 flex flex-col gap-6",
			children: CHAPTERS.map((ch) => {
				const rows = LEVELS.filter((lv) => lv.chapter === ch.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
						children: ch.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs text-muted",
						children: ch.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: rows.map((lv) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionRow, {
							level: lv,
							locked: !isLevelUnlocked(lv.id, completed),
							done: completed.includes(lv.id),
							current: !completed.includes(lv.id) && isLevelUnlocked(lv.id, completed),
							onOpen: () => openLevel(lv.id)
						}, lv.id))
					})
				] }, ch.id);
			})
		})
	] });
}
function MissionRow({ level, locked, done, current, onOpen }) {
	const shakeLock = useGame((s) => s.shakeLock);
	const [shake, setShake] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (locked && shakeLock) {
			setShake(true);
			const t = window.setTimeout(() => setShake(false), 320);
			return () => window.clearTimeout(t);
		}
	}, [shakeLock, locked]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onOpen,
		className: cn("flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left shadow-[var(--shadow-card)] active:scale-[0.99]", current ? "bg-surface-2" : "bg-surface", locked && "opacity-70", shake && "animate-shake"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("flex size-10 items-center justify-center rounded-md font-mono text-sm", done && "bg-success/15 text-success", current && "bg-accent/15 text-accent", locked && "bg-bg-elevated text-subtle", !done && !current && !locked && "bg-bg-elevated text-muted"),
				children: locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }) : done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : String(level.id).padStart(2, "0")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate font-medium",
					children: level.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted",
					children: locked ? `Complete Level ${level.id - 1} to unlock` : `${level.difficulty} · ${level.job}`
				})]
			}),
			current && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] font-medium uppercase tracking-[0.12em] text-accent",
				children: "Next"
			})
		]
	}) });
}
function CareerScreen() {
	const career = useGame((s) => s.career);
	const openLevel = useGame((s) => s.openLevel);
	const cur = careerById(career);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight",
			children: "Career path"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Complete missions to get hired and promoted."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-6",
			children: CAREERS.map((c, i) => {
				const state = c.rank < cur.rank ? "done" : c.rank === cur.rank ? "now" : "lock";
				const linked = LEVELS.find((l) => l.careerUnlock === c.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative flex gap-4 pb-6 last:pb-0",
					children: [
						i < CAREERS.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute left-[15px] top-8 h-[calc(100%-12px)] w-px", state === "done" ? "bg-accent" : "bg-border") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("relative z-[1] mt-0.5 flex size-8 items-center justify-center rounded-full", state === "done" && "bg-accent text-accent-fg", state === "now" && "bg-accent/20 text-accent ring-2 ring-accent", state === "lock" && "bg-surface text-subtle"),
							children: state === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : state === "lock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: state === "lock" || c.id === "rookie",
							onClick: () => linked && openLevel(linked.id),
							className: "min-w-0 flex-1 rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-card)] disabled:opacity-60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: c.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-sm text-muted",
									children: c.blurb
								}),
								state === "now" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
									children: "Current"
								})
							]
						})
					]
				}, c.id);
			})
		})
	] });
}
function RewardsScreen() {
	const unlocked = useGame((s) => s.unlockedRewards);
	const openLevel = useGame((s) => s.openLevel);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight",
			children: "Rewards"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Milestones unlock as you clear missions."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 flex flex-col gap-3",
			children: REWARDS.map((r) => {
				const on = unlocked.includes(r.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => openLevel(r.levelId),
					className: cn("flex w-full items-center gap-4 rounded-xl px-4 py-4 text-left shadow-[var(--shadow-card)]", r.featured ? "bg-surface-2" : "bg-surface", !on && "opacity-75"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("flex size-12 items-center justify-center rounded-md", on ? "bg-accent/15 text-accent" : "bg-bg-elevated text-subtle"),
						children: r.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarMark, { className: "size-7" }) : on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: r.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted",
								children: [
									"Level ",
									r.levelId,
									" · ",
									r.blurb
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-1 block text-[11px] font-medium uppercase tracking-[0.12em]", on ? "text-success" : "text-subtle"),
								children: on ? "Unlocked" : "Locked"
							})
						]
					})]
				}) }, r.id);
			})
		})
	] });
}
function ProfileScreen() {
	const name = useGame((s) => s.playerName);
	const setName = useGame((s) => s.setName);
	const career = useGame((s) => s.career);
	const xp = useGame((s) => s.xp);
	const coins = useGame((s) => s.coins);
	const completed = useGame((s) => s.completedLevels);
	const rewards = useGame((s) => s.unlockedRewards);
	const highest = useGame((s) => s.highestLevel);
	const gigCount = useGame((s) => s.gigCompletions).filter((g) => !g.practice).length;
	const resetProgress = useGame((s) => s.resetProgress);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(name);
	const prog = xpProgress(xp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight",
			children: "Profile"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountCard, {})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-5 block text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
			children: ["Player", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: draft,
				maxLength: 24,
				onChange: (e) => setDraft(e.target.value),
				onBlur: () => setName(draft),
				className: "mt-1 h-12 w-full rounded-md bg-surface px-3 text-base text-fg shadow-[var(--shadow-card)] outline-none focus:shadow-[var(--shadow-card-hover)]"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "mt-6 divide-y divide-border rounded-xl bg-surface px-4 shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Career",
					v: careerById(career).title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Level",
					v: String(prog.level).padStart(2, "0")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "XP",
					v: `${prog.current} / ${prog.needed}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Coins",
					v: coins.toLocaleString()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Completed",
					v: `${completed.length} / ${LEVELS.length}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Highest level",
					v: String(highest)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Freelance gigs",
					v: String(gigCount)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Rewards",
					v: `${rewards.length} / ${REWARDS.length}`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 rounded-xl bg-surface p-4 shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Reset test progress"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "This erases local prototype progress on this device."
				}),
				!confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					className: "mt-4 w-full",
					onClick: () => setConfirm(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset test progress"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Reset all progress?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							className: "flex-1",
							onClick: () => setConfirm(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							className: "flex-1",
							onClick: () => {
								setConfirm(false);
								resetProgress();
								audio.fail();
							},
							children: "Reset"
						})]
					})]
				})
			]
		})
	] });
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-sm text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-mono text-sm tabular",
			children: v
		})]
	});
}
function WelcomeScreen() {
	const startCareer = useGame((s) => s.startCareer);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh flex-col bg-bg px-6 pb-10 pt-[max(3rem,env(safe-area-inset-top))] text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-1 flex-col justify-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-accent",
					children: "Python career"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-4xl font-semibold tracking-tight",
					children: "Jarvis Career"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-[28ch] text-lg leading-relaxed text-muted",
					children: "Build your career. Complete missions. Earn rewards. Rise to Immortal."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-8 space-y-3 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 text-accent" }), "100 playable Python missions"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 text-accent" }), "Mistakes explained, with the fix"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 text-accent" }), "XP, coins, promotions, local save"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 text-accent" }), "In-game phone with simulated freelance gigs"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "mt-10 h-14 w-full text-lg",
					onClick: startCareer,
					children: "Start career"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInGate, {
					fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "mt-3 inline-flex h-12 w-full items-center justify-center rounded-md bg-surface text-sm font-medium text-fg shadow-[var(--shadow-card)]",
						children: "Sign in with Google"
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-center text-xs text-subtle",
						children: "Signed in. Progress saves to your account."
					})
				})
			]
		})
	});
}
function CompleteScreen() {
	const screen = useGame((s) => s.screen);
	const continueFrom = useGame((s) => s.continueFrom);
	const career = useGame((s) => s.career);
	if (screen.id !== "complete") return null;
	const level = LEVELS.find((l) => l.id === screen.levelId);
	if (!level) return null;
	const champ = level.championship;
	const finale = Boolean(level.finale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
			children: champ ? finale ? "Mastery complete" : "Championship complete" : "Level complete"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto mt-5 flex size-16 items-center justify-center rounded-full bg-success/15 text-success",
			children: champ ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-8" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-8" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-4 text-3xl font-semibold tracking-tight",
			children: level.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: ["Level ", String(level.id).padStart(2, "0")]
		}),
		screen.score !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 font-mono text-2xl tabular text-accent",
			children: [screen.score, " pts"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 rounded-xl bg-surface p-4 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
				children: "Rewards"
			}), screen.firstClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 font-mono text-lg tabular text-accent",
					children: [
						"+",
						screen.coins.toLocaleString(),
						" coins"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-lg tabular text-accent",
					children: [
						"+",
						screen.xp,
						" XP"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: ["Unlocked · ", level.unlockReward]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: ["Career · ", careerById(career).title]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "New simulated gigs may be waiting on your phone."
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Practice run. Rewards were already claimed."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-8 w-full",
			onClick: continueFrom,
			children: "Continue"
		})
	] });
}
function LevelUpScreen() {
	const screen = useGame((s) => s.screen);
	const continueFrom = useGame((s) => s.continueFrom);
	if (screen.id !== "levelup") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
			children: "Level up"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
			className: "mt-4 text-4xl font-semibold tracking-tight",
			children: [
				"LV ",
				String(screen.from).padStart(2, "0"),
				" → LV ",
				String(screen.to).padStart(2, "0")
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-muted",
			children: "Your player level increased. XP carries into the next bar."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-10 w-full",
			onClick: continueFrom,
			children: "Continue"
		})
	] });
}
function HiredScreen() {
	const screen = useGame((s) => s.screen);
	const continueFrom = useGame((s) => s.continueFrom);
	if (screen.id !== "hired") return null;
	const c = careerById(screen.career);
	const hired = screen.career === "trainee";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
			children: hired ? "Congratulations" : "Promotion unlocked"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-4 text-3xl font-semibold tracking-tight",
			children: hired ? "You've been hired" : c.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-2xl font-medium text-accent",
			children: hired ? c.title : "New title confirmed"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-muted",
			children: hired ? "Your career has officially started." : c.blurb
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-10 w-full",
			onClick: continueFrom,
			children: "Continue"
		})
	] });
}
function ClaimScreen() {
	const screen = useGame((s) => s.screen);
	const claimFinal = useGame((s) => s.claimFinal);
	const levelId = screen.id === "claim" ? screen.levelId : 5;
	const level = LEVELS.find((l) => l.id === levelId);
	const reward = level ? rewardById(level.unlockRewardId) : void 0;
	const isCar = reward?.id === "m8-apex";
	const finale = Boolean(level?.finale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
			children: finale ? "Python mastery complete" : "Elite championship complete"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 text-3xl font-semibold tracking-tight",
			children: "You did it"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-muted",
			children: ["Career · ", level ? careerById(level.careerUnlock).title : "Elite Professional"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-8 w-full max-w-xs rounded-xl bg-surface-2 p-6",
			children: [
				isCar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarMark, { className: "mx-auto h-16 w-full text-accent" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "mx-auto size-16 text-accent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg font-semibold",
					children: reward?.name ?? level?.unlockReward
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: reward?.blurb ?? "In-game bonus. Not a real-world prize."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-[11px] uppercase tracking-[0.14em] text-subtle",
			children: "Milestone reward"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-6 w-full",
			onClick: claimFinal,
			children: "Claim reward"
		})
	] });
}
function ClaimedScreen() {
	const continueFrom = useGame((s) => s.continueFrom);
	const pending = useGame((s) => s.pending);
	const level = pending ? LEVELS.find((l) => l.id === pending.levelId) : void 0;
	const reward = level ? rewardById(level.unlockRewardId) : rewardById("m8-apex");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex size-16 items-center justify-center rounded-full bg-success/15 text-success",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-8" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-4 text-3xl font-semibold tracking-tight",
			children: reward?.name ?? "Reward"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-success",
			children: "Unlocked"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-sm text-muted",
			children: ["Added to your in-game collection. ", reward?.id === "m8-apex" ? "A garage can show it in a later update — no driving sim in this prototype." : "Wear it on the Rewards tab. It is an in-game unlock, not a real-world prize."]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-10 w-full",
			onClick: continueFrom,
			children: "Continue"
		})
	] });
}
function Overlay({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center bg-bg px-6 py-10 text-center text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "animate-rise w-full max-w-md",
			children
		})
	});
}
function GameApp() {
	const screen = useGame((s) => s.screen);
	const setHydrated = useGame((s) => s.setHydrated);
	(0, import_react.useEffect)(() => {
		let alive = true;
		const finish = () => {
			if (alive) setHydrated();
		};
		try {
			Promise.resolve(useGame.persist.rehydrate()).then(finish, finish);
		} catch {
			finish();
		}
		const t = window.setTimeout(finish, 80);
		return () => {
			alive = false;
			window.clearTimeout(t);
		};
	}, [setHydrated]);
	let body;
	if (screen.id === "boot" || screen.id === "welcome") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomeScreen, {});
	else if (screen.id === "home") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {});
	else if (screen.id === "career") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CareerScreen, {});
	else if (screen.id === "rewards") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RewardsScreen, {});
	else if (screen.id === "profile") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileScreen, {});
	else if (screen.id === "intro") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelIntro, { levelId: screen.levelId });
	else if (screen.id === "play") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionView, { levelId: screen.levelId });
	else if (screen.id === "complete") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompleteScreen, {});
	else if (screen.id === "levelup") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelUpScreen, {});
	else if (screen.id === "hired") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HiredScreen, {});
	else if (screen.id === "claim") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimScreen, {});
	else if (screen.id === "claimed") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimedScreen, {});
	else if (screen.id === "gig-intro") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GigIntro, { jobId: screen.jobId });
	else if (screen.id === "gig-play") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GigPlay, { jobId: screen.jobId });
	else if (screen.id === "gig-complete") body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GigCompleteScreen, {});
	else body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudSaveSync, {}),
		body,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneHost, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneFab, {})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
