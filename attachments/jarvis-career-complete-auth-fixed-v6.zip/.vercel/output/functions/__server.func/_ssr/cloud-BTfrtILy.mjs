import { n as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
import { r as getSql } from "./db-B3l4nfx9.mjs";
import { t as authMiddleware } from "./middleware--Bh-fiPH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cloud-BTfrtILy.js
function asPayload(raw) {
	if (!raw) return null;
	if (typeof raw === "string") try {
		return JSON.parse(raw);
	} catch {
		return null;
	}
	if (typeof raw === "object") return raw;
	return null;
}
var loadCareerSave_createServerFn_handler = createServerRpc({
	id: "324e8bfefafe55cfcbd7a484a30a1b0ec2f14251e8fba8afa43f0dcfc8f85ef4",
	name: "loadCareerSave",
	filename: "src/lib/game/cloud.ts"
}, (opts) => loadCareerSave.__executeServer(opts));
var loadCareerSave = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(loadCareerSave_createServerFn_handler, async ({ context }) => {
	return asPayload((await (await getSql())`
      select payload from career_saves where user_id = ${context.userId} limit 1
    `)[0]?.payload);
});
var saveCareerSave_createServerFn_handler = createServerRpc({
	id: "832a0ef1c5e5f85cdf5206a9245c7ed780c084f88142d28a17f27d07ae4a6612",
	name: "saveCareerSave",
	filename: "src/lib/game/cloud.ts"
}, (opts) => saveCareerSave.__executeServer(opts));
var saveCareerSave = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(saveCareerSave_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const payload = JSON.stringify(data);
	await sql.query(`insert into career_saves (user_id, payload, updated_at)
       values ($1, $2::jsonb, now())
       on conflict (user_id) do update set payload = excluded.payload, updated_at = now()`, [context.userId, payload]);
	return { ok: true };
});
//#endregion
export { loadCareerSave_createServerFn_handler, saveCareerSave_createServerFn_handler };
