import { o as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, b as Navigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn } from "./client-CIsDoSCY.mjs";
import { a as useCurrentUserState, n as GROK_PROVIDERS, t as Button } from "./use-current-user-BC3XEmPf.mjs";
import { n as Route } from "./router-DP9j9bPm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DWTNn20q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function friendlyAuthError(code, description) {
	if (!code && !description) return null;
	const key = (code ?? "").toLowerCase();
	if (key === "access_denied" || key === "user_cancelled") return "Google sign-in was cancelled. Try again when you are ready.";
	if (key.includes("provider") || key === "provider_not_found") return "Google login is not configured on this deployment. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.";
	if (key.includes("state") || key.includes("csrf") || key.includes("origin")) return "Sign-in could not be verified (origin or CSRF). Check BETTER_AUTH_URL matches this site.";
	if (description) return description;
	return `Google sign-in failed (${code}).`;
}
function GoogleMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className: "size-5 shrink-0",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "currentColor",
				d: "M21.6 12.23c0-.74-.06-1.28-.2-1.84H12v3.34h5.48c-.11.9-.7 2.26-2.01 3.18l-.02.12 2.92 2.22.2.02c1.86-1.68 2.93-4.15 2.93-7.04z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "currentColor",
				opacity: "0.85",
				d: "M12 22c2.7 0 4.96-.87 6.62-2.37l-3.15-2.4c-.85.58-1.98 1-3.47 1-2.65 0-4.9-1.73-5.7-4.13l-.12.01-3.08 2.35-.04.11C4.67 19.99 8.09 22 12 22z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "currentColor",
				opacity: "0.7",
				d: "M6.3 13.11A6.04 6.04 0 0 1 6 12c0-.39.05-.76.08-1.11l-.01-.12-3.12-2.38-.1.05A9.99 9.99 0 0 0 2 12c0 1.61.39 3.13 1.07 4.48l3.23-2.37z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "currentColor",
				opacity: "0.55",
				d: "M12 5.94c1.88 0 3.15.8 3.87 1.46l2.83-2.71C16.95 3.05 14.7 2 12 2 8.09 2 4.67 4.01 3.07 7.52l3.22 2.37C7.1 7.49 9.35 5.94 12 5.94z"
			})
		]
	});
}
function Login() {
	const { user, isPending } = useCurrentUserState();
	const search = Route.useSearch();
	const status = Route.useLoaderData();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [clickError, setClickError] = (0, import_react.useState)(null);
	const callbackError = friendlyAuthError(search.error, search.error_description);
	const error = clickError ?? callbackError;
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-bg px-6 text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-48 animate-pulse rounded-md bg-surface" })
	});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	async function handleGoogle(providerId) {
		setClickError(null);
		if (!status.googleConfigured) {
			setClickError("Google login is not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET on this deployment, then redeploy.");
			return;
		}
		setBusy(true);
		try {
			await signIn(providerId, {
				callbackURL: "/",
				errorCallbackURL: "/login"
			});
		} catch (err) {
			setBusy(false);
			setClickError(err instanceof Error ? err.message : "Google sign-in failed. Please try again.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh flex-col bg-bg px-6 py-10 text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-sm flex-1 flex-col justify-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-widest text-accent",
					children: "Jarvis Career"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-3xl font-semibold tracking-tight",
					children: "Sign in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: "Continue with Google to keep missions, freelance gigs, and your portfolio on this account. You can still play as a guest on this device."
				}),
				!status.googleConfigured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "status",
					className: "mt-6 rounded-md bg-warn/15 px-3 py-3 text-sm leading-relaxed text-warn",
					children: "Google login is not configured on this deployment yet. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET, then redeploy. Guest play still works."
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "alert",
					className: "mt-6 rounded-md bg-danger/15 px-3 py-3 text-sm leading-relaxed text-danger",
					children: error
				}) : null,
				!status.persistSessions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm leading-relaxed text-warn",
					children: "BETTER_AUTH_SECRET is missing, so sessions may not survive a refresh. Set it in the deployment environment."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex flex-col gap-3",
					children: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						variant: "primary",
						className: "w-full",
						disabled: busy,
						onClick: () => void handleGoogle(p.providerId),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleMark, {}), busy ? "Redirecting to Google…" : `Continue with ${p.label}`]
					}, p.providerId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-6 inline-flex h-11 items-center justify-center text-sm font-medium text-muted hover:text-fg",
					children: "Continue as guest"
				})
			]
		})
	});
}
//#endregion
export { Login as component };
