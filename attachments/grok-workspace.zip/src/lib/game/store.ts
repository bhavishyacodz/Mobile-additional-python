import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { CAREERS, LEVELS, STARTING_COINS, isLevelUnlocked, levelById, playerLevelFromXp } from "./data.ts";
import type { CareerId, SaveState, Screen, TabId } from "./types.ts";
import { SAVE_VERSION } from "./types.ts";
import { audio } from "./audio.ts";

const KEY = "jarvis_career_save";

const defaults = (): SaveState => ({
  version: SAVE_VERSION,
  playerName: "Player",
  hasStarted: false,
  coins: STARTING_COINS,
  xp: 0,
  completedLevels: [],
  unlockedRewards: [],
  career: "rookie",
  highestLevel: 0,
  muted: false,
});

function migrate(raw: unknown): SaveState {
  const base = defaults();
  if (!raw || typeof raw !== "object") return base;
  const s = raw as Partial<SaveState>;
  const completed = Array.isArray(s.completedLevels)
    ? s.completedLevels.filter((n) => typeof n === "number" && n >= 1 && n <= LEVELS.length)
    : [];
  const rewards = Array.isArray(s.unlockedRewards) ? s.unlockedRewards.filter((x) => typeof x === "string") : [];
  const career = CAREERS.some((c) => c.id === s.career) ? (s.career as CareerId) : "rookie";
  return {
    ...base,
    version: SAVE_VERSION,
    playerName: typeof s.playerName === "string" && s.playerName.trim() ? s.playerName.trim().slice(0, 24) : "Player",
    hasStarted: Boolean(s.hasStarted),
    coins: Math.max(0, Math.floor(Number(s.coins) || 0)),
    xp: Math.max(0, Math.floor(Number(s.xp) || 0)),
    completedLevels: [...new Set(completed)],
    unlockedRewards: [...new Set(rewards)],
    career,
    highestLevel: Math.max(0, ...completed, Number(s.highestLevel) || 0),
    muted: Boolean(s.muted),
  };
}

export type PendingFlow = {
  firstClear: boolean;
  levelId: number;
  prevLevel: number;
  nextLevel: number;
  prevCareer: CareerId;
  nextCareer: CareerId;
};

type GameStore = SaveState & {
  screen: Screen;
  tab: TabId;
  toast: string | null;
  hydrated: boolean;
  shakeLock: number;
  pending: PendingFlow | null;
  setHydrated: () => void;
  startCareer: () => void;
  setTab: (tab: TabId) => void;
  setName: (name: string) => void;
  toggleMute: () => void;
  tryPlay: () => void;
  openLevel: (id: number) => void;
  beginMission: (id: number) => void;
  abortMission: () => void;
  finishMission: (id: number, score?: number) => void;
  continueFrom: () => void;
  claimFinal: () => void;
  resetProgress: () => void;
  flash: (msg: string) => void;
};

let toastTimer: ReturnType<typeof setTimeout> | undefined;

function champClaim(p: PendingFlow): Screen | null {
  if (!p.firstClear) return null;
  const lv = levelById(p.levelId);
  if (lv?.championship) return { id: "claim", levelId: p.levelId };
  return null;
}

function nextAfterComplete(p: PendingFlow): Screen {
  if (p.nextLevel > p.prevLevel) {
    return { id: "levelup", from: p.prevLevel, to: p.nextLevel };
  }
  if (p.firstClear && p.nextCareer !== p.prevCareer) {
    return { id: "hired", career: p.nextCareer };
  }
  return champClaim(p) ?? { id: "home" };
}

function nextAfterLevelUp(p: PendingFlow): Screen {
  if (p.firstClear && p.nextCareer !== p.prevCareer) {
    return { id: "hired", career: p.nextCareer };
  }
  return champClaim(p) ?? { id: "home" };
}

function nextAfterHired(p: PendingFlow): Screen {
  return champClaim(p) ?? { id: "home" };
}

export const useGame = create<GameStore>()(
  persist(
    (set, get) => ({
      ...defaults(),
      screen: { id: "welcome" },
      tab: "home",
      toast: null,
      hydrated: false,
      shakeLock: 0,
      pending: null,

      setHydrated: () => {
        const s = get();
        const onGate = s.screen.id === "boot" || s.screen.id === "welcome" || s.screen.id === "home";
        set({
          hydrated: true,
          screen: s.hasStarted ? (onGate ? { id: "home" } : s.screen) : { id: "welcome" },
          tab: onGate ? "home" : s.tab,
        });
        audio.setMuted(s.muted);
      },

      startCareer: () => {
        audio.unlock();
        audio.success();
        set({ hasStarted: true, screen: { id: "home" }, tab: "home" });
      },

      setTab: (tab) => {
        audio.click();
        set({ tab, screen: { id: tab } });
      },

      setName: (name) => {
        const playerName = name.trim().slice(0, 24) || "Player";
        set({ playerName });
      },

      toggleMute: () => {
        const muted = !get().muted;
        audio.setMuted(muted);
        if (!muted) audio.click();
        set({ muted });
      },

      tryPlay: () => {
        const { completedLevels } = get();
        const next = LEVELS.find((l) => !completedLevels.includes(l.id)) ?? LEVELS[LEVELS.length - 1];
        get().openLevel(next.id);
      },

      openLevel: (id) => {
        audio.unlock();
        const { completedLevels } = get();
        if (!isLevelUnlocked(id, completedLevels)) {
          audio.fail();
          set({ shakeLock: Date.now() });
          get().flash(`Complete Level ${id - 1} to unlock.`);
          return;
        }
        audio.click();
        set({ screen: { id: "intro", levelId: id }, tab: "home" });
      },

      beginMission: (id) => {
        audio.click();
        const { completedLevels } = get();
        if (!isLevelUnlocked(id, completedLevels)) {
          get().flash("That level is locked.");
          return;
        }
        set({ screen: { id: "play", levelId: id } });
      },

      abortMission: () => {
        audio.click();
        set({ screen: { id: "home" }, tab: "home" });
      },

      finishMission: (id, score) => {
        const level = levelById(id);
        if (!level) return;
        const s = get();
        const firstClear = !s.completedLevels.includes(id);
        const prevLevel = playerLevelFromXp(s.xp);
        const prevCareer = s.career;

        let coins = 0;
        let xp = 0;
        let career = s.career;
        let completedLevels = s.completedLevels;
        let unlockedRewards = s.unlockedRewards;
        let newXp = s.xp;
        let newCoins = s.coins;

        if (firstClear) {
          coins = level.rewardCoins;
          xp = level.rewardXp;
          newXp = s.xp + xp;
          newCoins = s.coins + coins;
          completedLevels = [...s.completedLevels, id];
          if (!unlockedRewards.includes(level.unlockRewardId)) {
            unlockedRewards = [...unlockedRewards, level.unlockRewardId];
          }
          career = level.careerUnlock;
        }

        const nextLevel = playerLevelFromXp(newXp);
        const pending: PendingFlow = {
          firstClear,
          levelId: id,
          prevLevel,
          nextLevel,
          prevCareer,
          nextCareer: career,
        };

        audio.complete();
        set({
          coins: newCoins,
          xp: newXp,
          completedLevels,
          unlockedRewards,
          career,
          highestLevel: Math.max(s.highestLevel, id),
          pending,
          screen: {
            id: "complete",
            levelId: id,
            firstClear,
            coins,
            xp,
            score,
          },
        });
      },

      continueFrom: () => {
        audio.click();
        const { screen, pending } = get();

        if (screen.id === "complete") {
          if (pending) {
            const next = nextAfterComplete(pending);
            if (next.id === "levelup") audio.levelup();
            if (next.id === "hired") audio.unlockReward();
            set({ screen: next, tab: next.id === "home" ? "home" : get().tab });
            return;
          }
          set({ screen: { id: "home" }, tab: "home" });
          return;
        }

        if (screen.id === "levelup") {
          const next = pending ? nextAfterLevelUp(pending) : { id: "home" as const };
          if (next.id === "hired") audio.unlockReward();
          set({ screen: next, tab: next.id === "home" ? "home" : get().tab });
          return;
        }

        if (screen.id === "hired") {
          const next = pending ? nextAfterHired(pending) : { id: "home" as const };
          set({ screen: next, tab: next.id === "home" ? "home" : get().tab });
          return;
        }

        if (screen.id === "claimed") {
          set({ screen: { id: "home" }, tab: "home" });
          return;
        }

        set({ screen: { id: "home" }, tab: "home" });
      },

      claimFinal: () => {
        audio.unlockReward();
        set({ screen: { id: "claimed" } });
      },

      resetProgress: () => {
        const muted = get().muted;
        const playerName = get().playerName;
        set({
          ...defaults(),
          muted,
          playerName,
          hasStarted: true,
          screen: { id: "home" },
          tab: "home",
          hydrated: true,
          pending: null,
        });
        get().flash("Progress reset.");
      },

      flash: (msg) => {
        set({ toast: msg });
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(() => set({ toast: null }), 2200);
      },
    }),
    {
      name: KEY,
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      version: SAVE_VERSION,
      partialize: (s) => ({
        version: s.version,
        playerName: s.playerName,
        hasStarted: s.hasStarted,
        coins: s.coins,
        xp: s.xp,
        completedLevels: s.completedLevels,
        unlockedRewards: s.unlockedRewards,
        career: s.career,
        highestLevel: s.highestLevel,
        muted: s.muted,
      }),
      merge: (persisted, current) => ({
        ...current,
        ...migrate(persisted),
      }),
      skipHydration: true,
    },
  ),
);
