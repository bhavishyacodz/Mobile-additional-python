import { useEffect } from "react";
import { LevelIntro, MissionView } from "@/components/game/mission";
import {
  CareerScreen,
  ClaimedScreen,
  ClaimScreen,
  CompleteScreen,
  HiredScreen,
  HomeScreen,
  LevelUpScreen,
  ProfileScreen,
  RewardsScreen,
  WelcomeScreen,
} from "@/components/game/screens";
import { useGame } from "@/lib/game/store";

export function GameApp() {
  const screen = useGame((s) => s.screen);
  const setHydrated = useGame((s) => s.setHydrated);

  useEffect(() => {
    let alive = true;
    const finish = () => {
      if (alive) setHydrated();
    };
    try {
      void Promise.resolve(useGame.persist.rehydrate()).then(finish, finish);
    } catch {
      finish();
    }
    const t = window.setTimeout(finish, 80);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
  }, [setHydrated]);

  useEffect(() => {
    const flush = () => {
      try {
        void useGame.persist.rehydrate();
      } catch {
        /* ignore */
      }
    };
    const onHide = () => {
      if (document.visibilityState === "hidden") flush();
    };
    document.addEventListener("visibilitychange", onHide);
    window.addEventListener("pagehide", flush);
    return () => {
      document.removeEventListener("visibilitychange", onHide);
      window.removeEventListener("pagehide", flush);
    };
  }, []);

  if (screen.id === "boot" || screen.id === "welcome") return <WelcomeScreen />;
  if (screen.id === "home") return <HomeScreen />;
  if (screen.id === "career") return <CareerScreen />;
  if (screen.id === "rewards") return <RewardsScreen />;
  if (screen.id === "profile") return <ProfileScreen />;
  if (screen.id === "intro") return <LevelIntro levelId={screen.levelId} />;
  if (screen.id === "play") return <MissionView levelId={screen.levelId} />;
  if (screen.id === "complete") return <CompleteScreen />;
  if (screen.id === "levelup") return <LevelUpScreen />;
  if (screen.id === "hired") return <HiredScreen />;
  if (screen.id === "claim") return <ClaimScreen />;
  if (screen.id === "claimed") return <ClaimedScreen />;
  return <HomeScreen />;
}
