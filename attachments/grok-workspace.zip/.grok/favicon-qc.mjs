import { chromium } from "playwright";
import { writeFileSync } from "node:fs";

const html = `<!doctype html><html><body style="margin:0;background:#111">
<img src="file:///workspace/public/favicon.svg" width="32" height="32" id="i32">
<img src="file:///workspace/public/favicon.svg" width="16" height="16" id="i16">
</body></html>`;
writeFileSync("/workspace/.grok/favicon-qc.html", html);

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 80, height: 80 }, deviceScaleFactor: 2 });
await page.goto("file:///workspace/.grok/favicon-qc.html");
await page.locator("#i32").screenshot({ path: "/workspace/.grok/favicon-32.png" });
await page.locator("#i16").screenshot({ path: "/workspace/.grok/favicon-16.png" });
await browser.close();
console.log("favicon rasterized");
