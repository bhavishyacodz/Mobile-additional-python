//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DBKRWB2t.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-lSnj_uIO.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-lSnj_uIO.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BAGlPI1q.js"]
	}
} });
//#endregion
export { tsrStartManifest };
