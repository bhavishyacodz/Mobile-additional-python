import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Award, c as Play, d as House, f as Gift, g as Briefcase, h as Check, i as Trophy, l as Lock, m as ChevronRight, n as Volume2, o as Timer, p as CircleAlert, r as User, s as RotateCcw, t as VolumeX, u as Lightbulb, v as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CJh20OSP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium tracking-tight transition-[transform,background-color,opacity,box-shadow] duration-150 ease-[var(--ease-out)] active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40 select-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg shadow-[var(--shadow-play)] hover:brightness-110",
			secondary: "bg-surface-2 text-fg shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-card-hover)]",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-surface",
			danger: "bg-danger/90 text-fg hover:bg-danger",
			outline: "bg-transparent text-fg shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-card-hover)]"
		},
		size: {
			lg: "h-12 min-h-12 px-6 rounded-md text-base",
			md: "h-11 min-h-11 px-4 rounded-md text-sm",
			sm: "h-9 min-h-9 px-3 rounded-sm text-sm",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(function Button({ className, variant, size, type = "button", ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
});
var KEYWORDS = /* @__PURE__ */ new Set([
	"if",
	"elif",
	"else",
	"for",
	"while",
	"def",
	"return",
	"in",
	"not",
	"and",
	"or",
	"True",
	"False",
	"None",
	"pass",
	"break",
	"continue"
]);
function err(kind, message, line, hint, fix) {
	return {
		kind,
		message,
		line,
		hint,
		fix
	};
}
function tokenize(source) {
	const src = source.replace(/\r\n/g, "\n").replace(/\t/g, "    ");
	const tokens = [];
	const indents = [0];
	const lines = src.split("\n");
	for (let li = 0; li < lines.length; li++) {
		const lineNo = li + 1;
		const raw = lines[li];
		const trimmed = raw.trim();
		if (trimmed === "" || trimmed.startsWith("#")) continue;
		const indent = raw.match(/^ */)?.[0].length ?? 0;
		if (indent > indents[indents.length - 1]) {
			indents.push(indent);
			tokens.push({
				type: "INDENT",
				value: "",
				line: lineNo,
				col: 1
			});
		} else {
			while (indent < indents[indents.length - 1]) {
				indents.pop();
				tokens.push({
					type: "DEDENT",
					value: "",
					line: lineNo,
					col: 1
				});
			}
			if (indent !== indents[indents.length - 1]) throw err("IndentationError", "Indentation does not match any outer level.", lineNo, "Python uses spaces at the start of a line to group code. Keep the same number of spaces for lines in the same block.", "Use 4 spaces for each indent level. Do not mix random spacing.");
		}
		let i = indent;
		const line = raw;
		while (i < line.length) {
			const ch = line[i];
			if (ch === " ") {
				i++;
				continue;
			}
			if (ch === "#") break;
			if (ch === "\"" || ch === "'") {
				const quote = ch;
				let j = i + 1;
				let val = "";
				while (j < line.length) {
					if (line[j] === "\\") {
						const n = line[j + 1];
						if (n === "n") val += "\n";
						else if (n === "t") val += "	";
						else if (n === quote || n === "\\") val += n;
						else val += n ?? "";
						j += 2;
						continue;
					}
					if (line[j] === quote) break;
					val += line[j];
					j++;
				}
				if (j >= line.length || line[j] !== quote) throw err("SyntaxError", "String is missing a closing quote.", lineNo, "Every string must start and end with the same quote mark.", `Close the string: ${quote}your text${quote}`);
				tokens.push({
					type: "STRING",
					value: val,
					line: lineNo,
					col: i + 1
				});
				i = j + 1;
				continue;
			}
			if (/[0-9]/.test(ch) || ch === "." && /[0-9]/.test(line[i + 1] ?? "")) {
				const m = line.slice(i).match(/^[0-9]+(\.[0-9]+)?/);
				if (!m) throw err("SyntaxError", "Invalid number.", lineNo, "Numbers look like 10 or 3.14.", "Write a number such as 42.");
				tokens.push({
					type: "NUMBER",
					value: m[0],
					line: lineNo,
					col: i + 1
				});
				i += m[0].length;
				continue;
			}
			if (/[A-Za-z_]/.test(ch)) {
				const name = line.slice(i).match(/^[A-Za-z_][A-Za-z0-9_]*/)[0];
				tokens.push({
					type: KEYWORDS.has(name) ? name : "NAME",
					value: name,
					line: lineNo,
					col: i + 1
				});
				i += name.length;
				continue;
			}
			const two = line.slice(i, i + 2);
			if ([
				"==",
				"!=",
				"<=",
				">=",
				"+=",
				"-=",
				"*=",
				"/=",
				"//",
				"**"
			].includes(two)) {
				tokens.push({
					type: two,
					value: two,
					line: lineNo,
					col: i + 1
				});
				i += 2;
				continue;
			}
			const one = ch;
			if ("+-*/%=<>()[]{},:.".includes(one)) {
				tokens.push({
					type: one,
					value: one,
					line: lineNo,
					col: i + 1
				});
				i += 1;
				continue;
			}
			if (one === ";") {
				tokens.push({
					type: "NEWLINE",
					value: "",
					line: lineNo,
					col: i + 1
				});
				i += 1;
				continue;
			}
			throw err("SyntaxError", `Unexpected character '${ch}'.`, lineNo, "Python does not use that symbol here.", "Remove it, or check you didn't paste JavaScript / Java code.");
		}
		tokens.push({
			type: "NEWLINE",
			value: "",
			line: lineNo,
			col: line.length + 1
		});
	}
	while (indents.length > 1) {
		indents.pop();
		tokens.push({
			type: "DEDENT",
			value: "",
			line: lines.length,
			col: 1
		});
	}
	tokens.push({
		type: "EOF",
		value: "",
		line: lines.length,
		col: 1
	});
	return tokens;
}
var Parser = class {
	i = 0;
	toks;
	constructor(toks) {
		this.toks = toks;
	}
	peek() {
		return this.toks[this.i];
	}
	at(type) {
		return this.peek().type === type;
	}
	eat(type) {
		const t = this.peek();
		if (type && t.type !== type) throw err("SyntaxError", `Expected ${humanTok(type)}, found ${humanTok(t.type)}.`, t.line, hintForExpected(type, t), fixForExpected(type, t));
		this.i++;
		return t;
	}
	skipNewlines() {
		while (this.at("NEWLINE")) this.i++;
	}
	parse() {
		const body = [];
		this.skipNewlines();
		while (!this.at("EOF") && !this.at("DEDENT")) {
			body.push(this.stmt());
			this.skipNewlines();
		}
		return body;
	}
	stmt() {
		const t = this.peek();
		if (t.type === "if") return this.ifStmt();
		if (t.type === "for") return this.forStmt();
		if (t.type === "while") return this.whileStmt();
		if (t.type === "def") return this.defStmt();
		if (t.type === "return") {
			this.eat("return");
			if (this.at("NEWLINE") || this.at("DEDENT") || this.at("EOF")) {
				this.eat("NEWLINE");
				return {
					k: "return",
					e: null,
					line: t.line
				};
			}
			const e = this.expr();
			this.endline();
			return {
				k: "return",
				e,
				line: t.line
			};
		}
		if (t.type === "pass") {
			this.eat("pass");
			this.endline();
			return {
				k: "pass",
				line: t.line
			};
		}
		if (t.type === "break") {
			this.eat("break");
			this.endline();
			return {
				k: "break",
				line: t.line
			};
		}
		if (t.type === "continue") {
			this.eat("continue");
			this.endline();
			return {
				k: "continue",
				line: t.line
			};
		}
		if (t.type === "NAME" && (this.toks[this.i + 1]?.type === "=" || isAug(this.toks[this.i + 1]?.type))) {
			const name = this.eat("NAME").value;
			const op = this.eat().type;
			const e = this.expr();
			this.endline();
			return {
				k: "assign",
				name,
				e,
				op,
				line: t.line
			};
		}
		const e = this.expr();
		if (this.at("=") && e.k === "index") {
			this.eat("=");
			const val = this.expr();
			this.endline();
			return {
				k: "setitem",
				target: e.target,
				index: e.index,
				e: val,
				line: t.line
			};
		}
		this.endline();
		return {
			k: "expr",
			e,
			line: t.line
		};
	}
	endline() {
		if (this.at("NEWLINE") || this.at("EOF") || this.at("DEDENT")) {
			if (this.at("NEWLINE")) this.eat("NEWLINE");
			return;
		}
		throw err("SyntaxError", "This line has extra code Python does not understand.", this.peek().line, "Each statement should be on its own line (or use a colon to start a block).", "Check for a missing colon, missing quote, or leftover character.");
	}
	suite() {
		if (!this.at("NEWLINE")) return [this.stmt()];
		this.eat("NEWLINE");
		this.skipNewlines();
		if (!this.at("INDENT")) throw err("IndentationError", "Expected an indented block.", this.peek().line, "After a colon (:) the next line must be indented with spaces.", "Press space four times before the next line, like:\n    print(\"hello\")");
		this.eat("INDENT");
		const body = [];
		this.skipNewlines();
		while (!this.at("DEDENT") && !this.at("EOF")) {
			body.push(this.stmt());
			this.skipNewlines();
		}
		if (this.at("DEDENT")) this.eat("DEDENT");
		if (body.length === 0) throw err("SyntaxError", "A block cannot be empty.", this.peek().line, "Every if / for / def needs at least one line inside it.", "Put a statement inside, or write pass.");
		return body;
	}
	ifStmt() {
		const line = this.peek().line;
		this.eat("if");
		const cond = this.expr();
		this.eat(":");
		const branches = [{
			cond,
			body: this.suite()
		}];
		while (this.at("elif")) {
			this.eat("elif");
			const c = this.expr();
			this.eat(":");
			branches.push({
				cond: c,
				body: this.suite()
			});
		}
		if (this.at("else")) {
			this.eat("else");
			this.eat(":");
			branches.push({
				cond: null,
				body: this.suite()
			});
		}
		return {
			k: "if",
			branches,
			line
		};
	}
	forStmt() {
		const line = this.peek().line;
		this.eat("for");
		const names = [this.eat("NAME").value];
		while (this.at(",")) {
			this.eat(",");
			names.push(this.eat("NAME").value);
		}
		this.eat("in");
		const iter = this.expr();
		this.eat(":");
		return {
			k: "for",
			names,
			iter,
			body: this.suite(),
			line
		};
	}
	whileStmt() {
		const line = this.peek().line;
		this.eat("while");
		const cond = this.expr();
		this.eat(":");
		return {
			k: "while",
			cond,
			body: this.suite(),
			line
		};
	}
	defStmt() {
		const line = this.peek().line;
		this.eat("def");
		const name = this.eat("NAME").value;
		this.eat("(");
		const params = [];
		if (!this.at(")")) {
			params.push(this.eat("NAME").value);
			while (this.at(",")) {
				this.eat(",");
				params.push(this.eat("NAME").value);
			}
		}
		this.eat(")");
		this.eat(":");
		return {
			k: "def",
			name,
			params,
			body: this.suite(),
			line
		};
	}
	expr() {
		return this.or();
	}
	or() {
		let a = this.and();
		while (this.at("or")) {
			const op = this.eat("or");
			a = {
				k: "bin",
				op: "or",
				a,
				b: this.and(),
				line: op.line
			};
		}
		return a;
	}
	and() {
		let a = this.not();
		while (this.at("and")) {
			const op = this.eat("and");
			a = {
				k: "bin",
				op: "and",
				a,
				b: this.not(),
				line: op.line
			};
		}
		return a;
	}
	not() {
		if (this.at("not")) {
			const op = this.eat("not");
			return {
				k: "unary",
				op: "not",
				x: this.not(),
				line: op.line
			};
		}
		return this.comparison();
	}
	comparison() {
		const first = this.arith();
		const ops = [];
		const items = [first];
		while ([
			"==",
			"!=",
			"<",
			">",
			"<=",
			">=",
			"in"
		].includes(this.peek().type) || this.at("not") && this.toks[this.i + 1]?.type === "in") {
			if (this.at("not")) {
				this.eat("not");
				this.eat("in");
				ops.push("not in");
			} else ops.push(this.eat().type);
			items.push(this.arith());
		}
		if (ops.length === 0) return first;
		return {
			k: "compare",
			ops,
			items,
			line: first.line
		};
	}
	arith() {
		let a = this.term();
		while (this.at("+") || this.at("-")) {
			const op = this.eat();
			a = {
				k: "bin",
				op: op.type,
				a,
				b: this.term(),
				line: op.line
			};
		}
		return a;
	}
	term() {
		let a = this.power();
		while (this.at("*") || this.at("/") || this.at("//") || this.at("%")) {
			const op = this.eat();
			a = {
				k: "bin",
				op: op.type,
				a,
				b: this.power(),
				line: op.line
			};
		}
		return a;
	}
	power() {
		const a = this.unary();
		if (this.at("**")) {
			const op = this.eat("**");
			return {
				k: "bin",
				op: "**",
				a,
				b: this.power(),
				line: op.line
			};
		}
		return a;
	}
	unary() {
		if (this.at("+") || this.at("-")) {
			const op = this.eat();
			return {
				k: "unary",
				op: op.type,
				x: this.unary(),
				line: op.line
			};
		}
		return this.trailer();
	}
	trailer() {
		let a = this.atom();
		while (true) if (this.at("(")) {
			const line = this.peek().line;
			this.eat("(");
			const args = [];
			if (!this.at(")")) {
				args.push(this.expr());
				while (this.at(",")) {
					this.eat(",");
					if (this.at(")")) break;
					args.push(this.expr());
				}
			}
			this.eat(")");
			a = {
				k: "call",
				fn: a,
				args,
				line
			};
		} else if (this.at("[")) {
			const line = this.peek().line;
			this.eat("[");
			if (this.at(":")) {
				this.eat(":");
				let end = null;
				let step = null;
				if (!this.at("]") && !this.at(":")) end = this.expr();
				if (this.at(":")) {
					this.eat(":");
					if (!this.at("]")) step = this.expr();
				}
				this.eat("]");
				a = {
					k: "slice",
					target: a,
					start: null,
					end,
					step,
					line
				};
			} else {
				const first = this.expr();
				if (this.at(":")) {
					this.eat(":");
					let end = null;
					let step = null;
					if (!this.at("]") && !this.at(":")) end = this.expr();
					if (this.at(":")) {
						this.eat(":");
						if (!this.at("]")) step = this.expr();
					}
					this.eat("]");
					a = {
						k: "slice",
						target: a,
						start: first,
						end,
						step,
						line
					};
				} else {
					this.eat("]");
					a = {
						k: "index",
						target: a,
						index: first,
						line
					};
				}
			}
		} else if (this.at(".")) {
			const line = this.peek().line;
			this.eat(".");
			const name = this.eat("NAME").value;
			a = {
				k: "attr",
				target: a,
				name,
				line
			};
		} else break;
		return a;
	}
	atom() {
		const t = this.peek();
		if (t.type === "NUMBER") {
			this.eat();
			return {
				k: "num",
				n: Number(t.value),
				line: t.line
			};
		}
		if (t.type === "STRING") {
			this.eat();
			return {
				k: "str",
				s: t.value,
				line: t.line
			};
		}
		if (t.type === "True" || t.type === "False") {
			this.eat();
			return {
				k: "const",
				v: t.type === "True",
				line: t.line
			};
		}
		if (t.type === "None") {
			this.eat();
			return {
				k: "const",
				v: null,
				line: t.line
			};
		}
		if (t.type === "NAME") {
			this.eat();
			return {
				k: "name",
				id: t.value,
				line: t.line
			};
		}
		if (t.type === "(") {
			this.eat("(");
			const e = this.expr();
			this.eat(")");
			return e;
		}
		if (t.type === "[") {
			this.eat("[");
			const items = [];
			if (!this.at("]")) {
				items.push(this.expr());
				while (this.at(",")) {
					this.eat(",");
					if (this.at("]")) break;
					items.push(this.expr());
				}
			}
			this.eat("]");
			return {
				k: "list",
				items,
				line: t.line
			};
		}
		if (t.type === "{") {
			this.eat("{");
			const keys = [];
			const vals = [];
			if (!this.at("}")) {
				keys.push(this.expr());
				this.eat(":");
				vals.push(this.expr());
				while (this.at(",")) {
					this.eat(",");
					if (this.at("}")) break;
					keys.push(this.expr());
					this.eat(":");
					vals.push(this.expr());
				}
			}
			this.eat("}");
			return {
				k: "dict",
				keys,
				vals,
				line: t.line
			};
		}
		throw err("SyntaxError", `Python did not expect ${humanTok(t.type)} here.`, t.line, "Check for a missing quote, missing parenthesis, or a word Python does not know.", "Look at the example in the briefing and match its shape.");
	}
};
function isAug(t) {
	return t === "+=" || t === "-=" || t === "*=" || t === "/=";
}
function humanTok(t) {
	return {
		NEWLINE: "end of line",
		INDENT: "indent",
		DEDENT: "dedent",
		EOF: "end of file",
		NAME: "a name",
		STRING: "a string",
		NUMBER: "a number",
		":": "a colon ':'",
		"(": "'('",
		")": "')'",
		"{": "'{'",
		"}": "'}'"
	}[t] ?? `'${t}'`;
}
function hintForExpected(expected, got) {
	if (expected === ":") return "if, for, while, def, and else lines must end with a colon (:). Dictionaries also use a colon between key and value.";
	if (expected === ")") return "Every '(' needs a matching ')'.";
	if (expected === "]") return "Every '[' needs a matching ']'.";
	if (expected === "}") return "Every '{' needs a matching '}'.";
	if (expected === "NAME") return "Python expected a variable name here.";
	if (got.type === "EOF") return "The line looks unfinished.";
	return `Python expected ${humanTok(expected)}.`;
}
function fixForExpected(expected, got) {
	if (expected === ":") return "Add a colon at the end, for example:\nif score >= 70:";
	if (expected === ")") return "Add the missing ')'.";
	if (expected === "NAME") return "Use a name like score or items — no quotes, no spaces.";
	return `Add ${humanTok(expected)}. Found ${humanTok(got.type)} instead.`;
}
var Env = class {
	map = /* @__PURE__ */ new Map();
	parent;
	constructor(parent = null) {
		this.parent = parent;
	}
	get(name) {
		if (this.map.has(name)) return this.map.get(name);
		return this.parent?.get(name);
	}
	set(name, v) {
		this.map.set(name, v);
	}
	hasLocal(name) {
		return this.map.has(name);
	}
};
var MAX_STEPS = 8e3;
var Interpreter = class Interpreter {
	stdout = [];
	steps = 0;
	env;
	constructor(env) {
		this.env = env;
	}
	tick(line) {
		this.steps++;
		if (this.steps > MAX_STEPS) throw err("RuntimeError", "This program ran too long (possible infinite loop).", line, "A while loop needs a condition that eventually becomes False.", "Make sure the loop variable changes, for example: i += 1");
	}
	run(body) {
		for (const s of body) {
			const r = this.exec(s);
			if (typeof r === "object") throw err("RuntimeError", "return used outside a function.", s.line, "return belongs in a function.", "Wrap the code in def, or remove return.");
			if (r === "break" || r === "continue") throw err("RuntimeError", `'${r}' used outside a loop.`, s.line, "break/continue belong in loops.", "Move it inside a for or while block.");
		}
	}
	exec(s) {
		this.tick(s.line);
		switch (s.k) {
			case "pass": return "ok";
			case "break": return "break";
			case "continue": return "continue";
			case "return": return { ret: s.e ? this.eval(s.e) : { t: "none" } };
			case "expr":
				this.eval(s.e);
				return "ok";
			case "assign": {
				const val = this.eval(s.e);
				if (s.op === "=") this.env.set(s.name, val);
				else {
					const cur = this.lookup(s.name, s.line);
					this.env.set(s.name, this.applyBin(s.op[0], cur, val, s.line));
				}
				return "ok";
			}
			case "setitem": {
				const target = this.eval(s.target);
				const index = this.eval(s.index);
				const val = this.eval(s.e);
				this.writeIndex(target, index, val, s.line);
				return "ok";
			}
			case "if":
				for (const b of s.branches) if (b.cond === null || isTruthy(this.eval(b.cond))) return this.execBlock(b.body);
				return "ok";
			case "for": {
				const iter = this.asList(this.eval(s.iter), s.line);
				for (const item of iter) {
					this.unpack(s.names, item, s.line);
					const r = this.execBlock(s.body);
					if (r === "break") break;
					if (r === "continue") continue;
					if (typeof r === "object") return r;
				}
				return "ok";
			}
			case "while":
				while (isTruthy(this.eval(s.cond))) {
					const r = this.execBlock(s.body);
					if (r === "break") break;
					if (r === "continue") continue;
					if (typeof r === "object") return r;
				}
				return "ok";
			case "def":
				this.env.set(s.name, {
					t: "fn",
					name: s.name,
					params: s.params,
					body: s.body,
					env: this.env
				});
				return "ok";
		}
	}
	unpack(names, item, line) {
		if (names.length === 1) {
			this.env.set(names[0], item);
			return;
		}
		const row = this.asList(item, line);
		if (row.length !== names.length) throw err("ValueError", `not enough values to unpack (expected ${names.length}, got ${row.length})`, line, "The number of names on the left of in must match each item.", "Example: for k, v in pairs:");
		names.forEach((n, i) => this.env.set(n, row[i]));
	}
	execBlock(body) {
		for (const s of body) {
			const r = this.exec(s);
			if (r !== "ok") return r;
		}
		return "ok";
	}
	lookup(name, line) {
		const v = this.env.get(name);
		if (v !== void 0) return v;
		const names = [];
		let e = this.env;
		while (e) {
			for (const k of e.map.keys()) names.push(k);
			e = e.parent;
		}
		const hint = suggest(name, names);
		throw err("NameError", `name '${name}' is not defined`, line, hint ? `Python does not know '${name}'. Did you mean '${hint}'? Names must be created before you use them.` : `Python does not know '${name}'. You must assign it first, for example: ${name} = 10`, hint ? `Replace '${name}' with '${hint}', or assign ${name} before using it.` : `Add a line above: ${name} = ...`);
	}
	eval(e) {
		this.tick(e.line);
		switch (e.k) {
			case "num": return {
				t: "num",
				v: e.n
			};
			case "str": return {
				t: "str",
				v: e.s
			};
			case "const":
				if (e.v === null) return { t: "none" };
				return {
					t: "bool",
					v: e.v
				};
			case "name": return this.lookup(e.id, e.line);
			case "list": return {
				t: "list",
				v: e.items.map((x) => this.eval(x))
			};
			case "dict": {
				const keys = [];
				const vals = [];
				for (let i = 0; i < e.keys.length; i++) {
					const key = this.eval(e.keys[i]);
					assertHashable(key, e.line);
					const val = this.eval(e.vals[i]);
					const existing = dictIndex(keys, key);
					if (existing >= 0) vals[existing] = val;
					else {
						keys.push(key);
						vals.push(val);
					}
				}
				return {
					t: "dict",
					keys,
					vals
				};
			}
			case "unary": {
				const x = this.eval(e.x);
				if (e.op === "not") return {
					t: "bool",
					v: !isTruthy(x)
				};
				if (e.op === "+") return asNum(x, e.line), x;
				if (e.op === "-") return {
					t: "num",
					v: -asNum(x, e.line)
				};
				throw err("SyntaxError", "Unknown unary operator.", e.line, "", "");
			}
			case "bin":
				if (e.op === "and") {
					const a = this.eval(e.a);
					return isTruthy(a) ? this.eval(e.b) : a;
				}
				if (e.op === "or") {
					const a = this.eval(e.a);
					return isTruthy(a) ? a : this.eval(e.b);
				}
				return this.applyBin(e.op, this.eval(e.a), this.eval(e.b), e.line);
			case "compare":
				for (let i = 0; i < e.ops.length; i++) if (!this.cmp(e.ops[i], this.eval(e.items[i]), this.eval(e.items[i + 1]), e.line)) return {
					t: "bool",
					v: false
				};
				return {
					t: "bool",
					v: true
				};
			case "index": {
				const t = this.eval(e.target);
				const i = this.eval(e.index);
				return this.readIndex(t, i, e.line);
			}
			case "slice": {
				const t = this.eval(e.target);
				const start = e.start ? this.eval(e.start) : null;
				const end = e.end ? this.eval(e.end) : null;
				const step = e.step ? this.eval(e.step) : {
					t: "num",
					v: 1
				};
				return this.readSlice(t, start, end, step, e.line);
			}
			case "attr": throw err("TypeError", `'${e.name}' is a method — call it with parentheses.`, e.line, "Methods do nothing until you add (). print(text.upper) shows the method; print(text.upper()) runs it.", `Write ${e.name}() with parentheses.`);
			case "call": return this.call(e);
		}
	}
	readIndex(t, i, line) {
		if (t.t === "list") {
			const idx = asInt(i, line);
			const n = idx < 0 ? t.v.length + idx : idx;
			if (n < 0 || n >= t.v.length) throw err("IndexError", "list index out of range", line, "List indexes start at 0. The last item is len(list) - 1.", "Use a smaller index, or check len(your_list) first.");
			return t.v[n];
		}
		if (t.t === "str") {
			const idx = asInt(i, line);
			const n = idx < 0 ? t.v.length + idx : idx;
			if (n < 0 || n >= t.v.length) throw err("IndexError", "string index out of range", line, "String indexes start at 0.", "Use a smaller index.");
			return {
				t: "str",
				v: t.v[n]
			};
		}
		if (t.t === "dict") {
			const idx = dictIndex(t.keys, i);
			if (idx < 0) throw err("KeyError", `key ${reprVal(i)} is not in this dictionary`, line, "Dictionary keys must match exactly, including capitals.", "Check the key, or use .get(key) which returns None if missing.");
			return t.vals[idx];
		}
		throw err("TypeError", "This value cannot be indexed with [].", line, "[] is for lists, strings, and dictionaries.", "Index a list, for example items[0], or a dict like user[\"name\"].");
	}
	writeIndex(t, i, val, line) {
		if (t.t === "list") {
			const idx = asInt(i, line);
			const n = idx < 0 ? t.v.length + idx : idx;
			if (n < 0 || n >= t.v.length) throw err("IndexError", "list assignment index out of range", line, "You can only replace an index that already exists.", "Use append() to add a new item.");
			t.v[n] = val;
			return;
		}
		if (t.t === "dict") {
			assertHashable(i, line);
			const idx = dictIndex(t.keys, i);
			if (idx >= 0) t.vals[idx] = val;
			else {
				t.keys.push(i);
				t.vals.push(val);
			}
			return;
		}
		if (t.t === "str") throw err("TypeError", "strings cannot be changed in place", line, "Strings are immutable. Build a new string instead.", "Use replace() or concatenate with +.");
		throw err("TypeError", "This value does not support item assignment.", line, "Only lists and dictionaries can use name[key] = value.", "");
	}
	readSlice(t, start, end, stepV, line) {
		const step = asInt(stepV, line);
		if (step === 0) throw err("ValueError", "slice step cannot be zero", line, "A slice step of 0 never moves.", "Use 1, 2, or -1.");
		const len = t.t === "list" ? t.v.length : t.t === "str" ? t.v.length : -1;
		if (len < 0) throw err("TypeError", "This value cannot be sliced.", line, "Slicing with : works on lists and strings.", "Example: items[1:3]");
		const idx = sliceIndices(len, start ? asInt(start, line) : null, end ? asInt(end, line) : null, step);
		if (t.t === "str") {
			let out = "";
			for (const i of idx) out += t.v[i];
			return {
				t: "str",
				v: out
			};
		}
		if (t.t !== "list") throw err("TypeError", "This value cannot be sliced.", line, "Slicing with : works on lists and strings.", "Example: items[1:3]");
		return {
			t: "list",
			v: idx.map((i) => t.v[i])
		};
	}
	call(e) {
		if (e.fn.k === "attr") {
			const obj = this.eval(e.fn.target);
			const args = e.args.map((a) => this.eval(a));
			return this.method(obj, e.fn.name, args, e.line);
		}
		if (e.fn.k === "name") {
			const builtin = this.builtin(e.fn.id, e.args, e.line);
			if (builtin !== void 0) return builtin;
		}
		const fn = this.eval(e.fn);
		if (fn.t !== "fn") throw err("TypeError", "This value is not a function, so you cannot call it with ().", e.line, "Only functions (and tools like print, len) can be called.", "Check the name you are calling.");
		if (e.args.length !== fn.params.length) throw err("TypeError", `${fn.name}() takes ${fn.params.length} argument(s) but ${e.args.length} were given`, e.line, "The number of values inside the parentheses must match the function parameters.", `Call it like ${fn.name}(${fn.params.join(", ")})`);
		const local = new Env(fn.env);
		e.args.forEach((a, i) => local.set(fn.params[i], this.eval(a)));
		const inner = new Interpreter(local);
		inner.stdout = this.stdout;
		inner.steps = this.steps;
		const r = inner.execBlock(fn.body);
		this.steps = inner.steps;
		if (typeof r === "object") return r.ret;
		return { t: "none" };
	}
	method(obj, name, args, line) {
		if (obj.t === "str") return strMethod(obj.v, name, args, line);
		if (obj.t === "list") return listMethod(obj, name, args, line);
		if (obj.t === "dict") return dictMethod(obj, name, args, line);
		throw err("TypeError", `'${typeName(obj)}' has no method ${name}()`, line, "Methods belong to a type. Strings have upper/lower/strip. Lists have append/pop.", "Check the type of the value before the dot.");
	}
	builtin(name, args, line) {
		const evalArgs = () => args.map((a) => this.eval(a));
		switch (name) {
			case "print": {
				const vals = evalArgs();
				this.stdout.push(vals.map(strVal).join(" "));
				return { t: "none" };
			}
			case "len": {
				const [a] = need(evalArgs(), 1, "len", line);
				if (a.t === "list") return {
					t: "num",
					v: a.v.length
				};
				if (a.t === "str") return {
					t: "num",
					v: a.v.length
				};
				if (a.t === "dict") return {
					t: "num",
					v: a.keys.length
				};
				throw err("TypeError", "len() only works on lists, strings, and dictionaries.", line, "len tells you how many items / characters / keys.", "Use len on a list, string, or dict.");
			}
			case "str": {
				const [a] = need(evalArgs(), 1, "str", line);
				return {
					t: "str",
					v: strVal(a)
				};
			}
			case "int": {
				const [a] = need(evalArgs(), 1, "int", line);
				if (a.t === "num") return {
					t: "num",
					v: Math.trunc(a.v)
				};
				if (a.t === "bool") return {
					t: "num",
					v: a.v ? 1 : 0
				};
				if (a.t === "str") {
					const n = Number(a.v.trim());
					if (!Number.isFinite(n)) throw err("ValueError", `invalid literal for int(): '${a.v}'`, line, "int() needs digits like \"42\".", "Pass a numeric string or a number.");
					return {
						t: "num",
						v: Math.trunc(n)
					};
				}
				throw err("TypeError", "int() cannot convert this value.", line, "Use int on a number or a numeric string.", "Example: int(\"7\")");
			}
			case "range": {
				const a = evalArgs();
				let start = 0, stop = 0, step = 1;
				if (a.length === 1) stop = asInt(a[0], line);
				else if (a.length === 2) {
					start = asInt(a[0], line);
					stop = asInt(a[1], line);
				} else if (a.length === 3) {
					start = asInt(a[0], line);
					stop = asInt(a[1], line);
					step = asInt(a[2], line);
					if (step === 0) throw err("ValueError", "range() step cannot be zero.", line, "Step must be a non-zero integer.", "Use 1 or -1.");
				} else throw err("TypeError", "range() expected 1 to 3 arguments.", line, "range(stop) or range(start, stop).", "Example: range(3) → 0, 1, 2");
				const out = [];
				if (step > 0) for (let i = start; i < stop; i += step) out.push({
					t: "num",
					v: i
				});
				else for (let i = start; i > stop; i += step) out.push({
					t: "num",
					v: i
				});
				return {
					t: "list",
					v: out
				};
			}
			case "sum": {
				const [a] = need(evalArgs(), 1, "sum", line);
				if (a.t !== "list") throw err("TypeError", "sum() needs a list of numbers.", line, "Add numbers in a list.", "Example: sum([1, 2, 3])");
				let n = 0;
				for (const x of a.v) n += asNum(x, line);
				return {
					t: "num",
					v: n
				};
			}
			case "min":
			case "max": {
				const a = evalArgs();
				const nums = a.length === 1 && a[0].t === "list" ? a[0].v : a;
				if (nums.length === 0) throw err("ValueError", `${name}() of empty sequence`, line, "Give at least one number.", "");
				const vals = nums.map((x) => asNum(x, line));
				return {
					t: "num",
					v: name === "min" ? Math.min(...vals) : Math.max(...vals)
				};
			}
			case "abs": {
				const [a] = need(evalArgs(), 1, "abs", line);
				return {
					t: "num",
					v: Math.abs(asNum(a, line))
				};
			}
			case "type": {
				const [a] = need(evalArgs(), 1, "type", line);
				return {
					t: "str",
					v: a.t === "num" ? Number.isInteger(a.v) ? "int" : "float" : a.t === "str" ? "str" : a.t === "bool" ? "bool" : a.t === "list" ? "list" : a.t === "dict" ? "dict" : a.t === "fn" ? "function" : "NoneType"
				};
			}
			case "sorted": {
				const [a] = need(evalArgs(), 1, "sorted", line);
				const items = a.t === "list" ? [...a.v] : a.t === "str" ? [...a.v].map((c) => ({
					t: "str",
					v: c
				})) : a.t === "dict" ? [...a.keys] : null;
				if (!items) throw err("TypeError", "sorted() needs a list, string, or dict.", line, "sorted returns a new list in order.", "Example: sorted([3, 1, 2])");
				items.sort(cmpVals);
				return {
					t: "list",
					v: items
				};
			}
			case "list": {
				const a = evalArgs();
				if (a.length === 0) return {
					t: "list",
					v: []
				};
				const [x] = need(a, 1, "list", line);
				return {
					t: "list",
					v: [...this.asList(x, line)]
				};
			}
			case "enumerate": {
				const [a] = need(evalArgs(), 1, "enumerate", line);
				return {
					t: "list",
					v: this.asList(a, line).map((item, i) => ({
						t: "list",
						v: [{
							t: "num",
							v: i
						}, item]
					}))
				};
			}
			default: return;
		}
	}
	asList(v, line) {
		if (v.t === "list") return v.v;
		if (v.t === "str") return [...v.v].map((c) => ({
			t: "str",
			v: c
		}));
		if (v.t === "dict") return v.keys;
		throw err("TypeError", "This value is not iterable.", line, "for x in ... needs a list, a string, a dict, or range(...).", "Use range(3) or a list like [1, 2, 3].");
	}
	applyBin(op, a, b, line) {
		if (op === "+") {
			if (a.t === "str" && b.t === "str") return {
				t: "str",
				v: a.v + b.v
			};
			if (a.t === "list" && b.t === "list") return {
				t: "list",
				v: [...a.v, ...b.v]
			};
			if (isNumeric(a) && isNumeric(b)) return {
				t: "num",
				v: num(a) + num(b)
			};
			throw err("TypeError", `cannot concatenate ${typeName(a)} and ${typeName(b)}`, line, "Use + with two numbers, two strings, or two lists — not mixed.", a.t === "str" || b.t === "str" ? "Convert the number with str(n), for example: \"Score: \" + str(10)" : "Make both sides numbers, or both strings.");
		}
		if (op === "*") {
			if (a.t === "str" && isNumeric(b)) return {
				t: "str",
				v: a.v.repeat(Math.max(0, Math.trunc(num(b))))
			};
			if (b.t === "str" && isNumeric(a)) return {
				t: "str",
				v: b.v.repeat(Math.max(0, Math.trunc(num(a))))
			};
			if (isNumeric(a) && isNumeric(b)) return {
				t: "num",
				v: num(a) * num(b)
			};
			throw err("TypeError", "Cannot multiply these values.", line, "* is for numbers, or a string times a number.", "Example: 3 * 4  or  \"ha\" * 3");
		}
		if ([
			"-",
			"/",
			"//",
			"%",
			"**"
		].includes(op)) {
			const x = asNum(a, line);
			const y = asNum(b, line);
			if ((op === "/" || op === "//" || op === "%") && y === 0) throw err("RuntimeError", "division by zero", line, "You cannot divide by 0.", "Change the number on the right of / so it is not 0.");
			if (op === "-") return {
				t: "num",
				v: x - y
			};
			if (op === "/") return {
				t: "num",
				v: x / y
			};
			if (op === "//") return {
				t: "num",
				v: Math.floor(x / y)
			};
			if (op === "%") return {
				t: "num",
				v: x % y
			};
			if (op === "**") return {
				t: "num",
				v: x ** y
			};
		}
		throw err("TypeError", `Cannot use '${op}' on these values.`, line, "Check both sides of the operator.", "Use numbers with math operators.");
	}
	cmp(op, a, b, line) {
		if (op === "in" || op === "not in") {
			let found = false;
			if (b.t === "list") found = b.v.some((x) => eq(a, x));
			else if (b.t === "str" && a.t === "str") found = b.v.includes(a.v);
			else if (b.t === "dict") found = dictIndex(b.keys, a) >= 0;
			else throw err("TypeError", "'in' needs a list, string, or dictionary on the right.", line, "Example: \"a\" in \"cat\"  or  2 in [1, 2, 3]  or  \"name\" in user", "");
			return op === "in" ? found : !found;
		}
		if (op === "==") return eq(a, b);
		if (op === "!=") return !eq(a, b);
		if (isNumeric(a) && isNumeric(b)) {
			const x = num(a), y = num(b);
			if (op === "<") return x < y;
			if (op === ">") return x > y;
			if (op === "<=") return x <= y;
			if (op === ">=") return x >= y;
		}
		if (a.t === "str" && b.t === "str") {
			if (op === "<") return a.v < b.v;
			if (op === ">") return a.v > b.v;
			if (op === "<=") return a.v <= b.v;
			if (op === ">=") return a.v >= b.v;
		}
		throw err("TypeError", `Cannot compare ${typeName(a)} and ${typeName(b)} with ${op}.`, line, "Compare the same kinds of values, like two numbers.", "Use == to check equality of any two values.");
	}
};
function strMethod(s, name, args, line) {
	switch (name) {
		case "upper":
			need(args, 0, "upper", line);
			return {
				t: "str",
				v: s.toUpperCase()
			};
		case "lower":
			need(args, 0, "lower", line);
			return {
				t: "str",
				v: s.toLowerCase()
			};
		case "strip":
			need(args, 0, "strip", line);
			return {
				t: "str",
				v: s.trim()
			};
		case "lstrip":
			need(args, 0, "lstrip", line);
			return {
				t: "str",
				v: s.replace(/^\s+/, "")
			};
		case "rstrip":
			need(args, 0, "rstrip", line);
			return {
				t: "str",
				v: s.replace(/\s+$/, "")
			};
		case "capitalize":
			need(args, 0, "capitalize", line);
			return {
				t: "str",
				v: s ? s[0].toUpperCase() + s.slice(1).toLowerCase() : ""
			};
		case "title":
			need(args, 0, "title", line);
			return {
				t: "str",
				v: s.toLowerCase().replace(/(^|[^A-Za-z])([A-Za-z])/g, (_, a, b) => a + b.toUpperCase())
			};
		case "split": {
			if (args.length === 0) return {
				t: "list",
				v: s.trim() ? s.trim().split(/\s+/).map((p) => ({
					t: "str",
					v: p
				})) : []
			};
			const [sep] = need(args, 1, "split", line);
			if (sep.t !== "str") throw err("TypeError", "split() separator must be a string.", line, "", "Example: text.split(\",\")");
			return {
				t: "list",
				v: s.split(sep.v).map((p) => ({
					t: "str",
					v: p
				}))
			};
		}
		case "join": {
			const [seq] = need(args, 1, "join", line);
			if (seq.t !== "list") throw err("TypeError", "join() needs a list of strings.", line, "The separator is the string before the dot.", "Example: \"-\".join([\"a\", \"b\"])");
			return {
				t: "str",
				v: seq.v.map((x) => {
					if (x.t !== "str") throw err("TypeError", "join() list items must be strings.", line, "Convert numbers with str() first.", "\"-\".join([str(1), str(2)])");
					return x.v;
				}).join(s)
			};
		}
		case "replace":
			if (args.length !== 2) throw err("TypeError", "replace() expected 2 arguments.", line, "old text, then new text.", "text.replace(\"a\", \"b\")");
			if (args[0].t !== "str" || args[1].t !== "str") throw err("TypeError", "replace() needs two strings.", line, "", "");
			return {
				t: "str",
				v: s.split(args[0].v).join(args[1].v)
			};
		case "find": {
			const [sub] = need(args, 1, "find", line);
			if (sub.t !== "str") throw err("TypeError", "find() needs a string.", line, "", "");
			return {
				t: "num",
				v: s.indexOf(sub.v)
			};
		}
		case "count": {
			const [sub] = need(args, 1, "count", line);
			if (sub.t !== "str") throw err("TypeError", "count() needs a string.", line, "", "");
			if (!sub.v) return {
				t: "num",
				v: s.length + 1
			};
			let n = 0;
			let i = 0;
			while (true) {
				const j = s.indexOf(sub.v, i);
				if (j < 0) break;
				n++;
				i = j + sub.v.length;
			}
			return {
				t: "num",
				v: n
			};
		}
		case "startswith": {
			const [sub] = need(args, 1, "startswith", line);
			if (sub.t !== "str") throw err("TypeError", "startswith() needs a string.", line, "", "");
			return {
				t: "bool",
				v: s.startsWith(sub.v)
			};
		}
		case "endswith": {
			const [sub] = need(args, 1, "endswith", line);
			if (sub.t !== "str") throw err("TypeError", "endswith() needs a string.", line, "", "");
			return {
				t: "bool",
				v: s.endsWith(sub.v)
			};
		}
		case "isdigit":
			need(args, 0, "isdigit", line);
			return {
				t: "bool",
				v: s.length > 0 && /^[0-9]+$/.test(s)
			};
		case "isalpha":
			need(args, 0, "isalpha", line);
			return {
				t: "bool",
				v: s.length > 0 && /^[A-Za-z]+$/.test(s)
			};
		default: throw err("TypeError", `str has no method ${name}()`, line, "Common string methods: upper, lower, strip, split, join, replace, find, startswith.", `Check the spelling of ${name}.`);
	}
}
function listMethod(obj, name, args, line) {
	switch (name) {
		case "append": {
			const [x] = need(args, 1, "append", line);
			obj.v.push(x);
			return { t: "none" };
		}
		case "pop": {
			if (obj.v.length === 0) throw err("IndexError", "pop from empty list", line, "The list has no items left.", "Check len(list) first.");
			if (args.length === 0) return obj.v.pop();
			const [i] = need(args, 1, "pop", line);
			const idx = asInt(i, line);
			const n = idx < 0 ? obj.v.length + idx : idx;
			if (n < 0 || n >= obj.v.length) throw err("IndexError", "pop index out of range", line, "", "");
			return obj.v.splice(n, 1)[0];
		}
		case "insert": {
			const [i, x] = args.length === 2 ? args : need(args, 2, "insert", line);
			if (args.length !== 2) throw err("TypeError", "insert() expected 2 arguments.", line, "index, then value.", "items.insert(0, \"Ada\")");
			let n = asInt(i, line);
			if (n < 0) n = 0;
			if (n > obj.v.length) n = obj.v.length;
			obj.v.splice(n, 0, x);
			return { t: "none" };
		}
		case "remove": {
			const [x] = need(args, 1, "remove", line);
			const idx = obj.v.findIndex((v) => eq(v, x));
			if (idx < 0) throw err("ValueError", "list.remove(x): x not in list", line, "remove deletes the first matching item.", "Check the value exists first.");
			obj.v.splice(idx, 1);
			return { t: "none" };
		}
		case "extend": {
			const [seq] = need(args, 1, "extend", line);
			if (seq.t !== "list") throw err("TypeError", "extend() needs a list.", line, "", "items.extend([1, 2])");
			obj.v.push(...seq.v);
			return { t: "none" };
		}
		case "clear":
			need(args, 0, "clear", line);
			obj.v.length = 0;
			return { t: "none" };
		case "copy":
			need(args, 0, "copy", line);
			return {
				t: "list",
				v: [...obj.v]
			};
		case "reverse":
			need(args, 0, "reverse", line);
			obj.v.reverse();
			return { t: "none" };
		case "sort":
			need(args, 0, "sort", line);
			obj.v.sort(cmpVals);
			return { t: "none" };
		case "count": {
			const [x] = need(args, 1, "count", line);
			return {
				t: "num",
				v: obj.v.filter((v) => eq(v, x)).length
			};
		}
		case "index": {
			const [x] = need(args, 1, "index", line);
			const idx = obj.v.findIndex((v) => eq(v, x));
			if (idx < 0) throw err("ValueError", `${reprVal(x)} is not in list`, line, "index finds the first position.", "Check the value, or use `x in items` first.");
			return {
				t: "num",
				v: idx
			};
		}
		default: throw err("TypeError", `list has no method ${name}()`, line, "Common list methods: append, pop, insert, remove, sort, reverse.", `Check the spelling of ${name}.`);
	}
}
function dictMethod(obj, name, args, line) {
	switch (name) {
		case "get": {
			if (args.length < 1 || args.length > 2) throw err("TypeError", "get() expected 1 or 2 arguments.", line, "key, and optional default.", "user.get(\"name\")");
			const idx = dictIndex(obj.keys, args[0]);
			if (idx >= 0) return obj.vals[idx];
			return args[1] ?? { t: "none" };
		}
		case "keys":
			need(args, 0, "keys", line);
			return {
				t: "list",
				v: [...obj.keys]
			};
		case "values":
			need(args, 0, "values", line);
			return {
				t: "list",
				v: [...obj.vals]
			};
		case "items":
			need(args, 0, "items", line);
			return {
				t: "list",
				v: obj.keys.map((k, i) => ({
					t: "list",
					v: [k, obj.vals[i]]
				}))
			};
		case "pop": {
			const [key] = need(args, 1, "pop", line);
			const idx = dictIndex(obj.keys, key);
			if (idx < 0) throw err("KeyError", `key ${reprVal(key)} is not in this dictionary`, line, "", "");
			const val = obj.vals[idx];
			obj.keys.splice(idx, 1);
			obj.vals.splice(idx, 1);
			return val;
		}
		case "clear":
			need(args, 0, "clear", line);
			obj.keys.length = 0;
			obj.vals.length = 0;
			return { t: "none" };
		default: throw err("TypeError", `dict has no method ${name}()`, line, "Common dict methods: get, keys, values, items.", `Check the spelling of ${name}.`);
	}
}
function need(args, n, name, line) {
	if (args.length !== n) throw err("TypeError", `${name}() expected ${n} argument(s).`, line, "Check the parentheses.", `Example: ${name}(...)`);
	return args;
}
function isNumeric(v) {
	return v.t === "num" || v.t === "bool";
}
function num(v) {
	if (v.t === "num") return v.v;
	if (v.t === "bool") return v.v ? 1 : 0;
	return 0;
}
function asNum(v, line) {
	if (!isNumeric(v)) throw err("TypeError", `${typeName(v)} is not a number.`, line, "Math operators need numbers.", "Remove quotes if you meant a number: 10 not \"10\".");
	return num(v);
}
function asInt(v, line) {
	return Math.trunc(asNum(v, line));
}
function isTruthy(v) {
	if (v.t === "none") return false;
	if (v.t === "bool") return v.v;
	if (v.t === "num") return v.v !== 0;
	if (v.t === "str") return v.v.length > 0;
	if (v.t === "list") return v.v.length > 0;
	if (v.t === "dict") return v.keys.length > 0;
	return true;
}
function eq(a, b) {
	if (a.t !== b.t) {
		if (isNumeric(a) && isNumeric(b)) return num(a) === num(b);
		return false;
	}
	if (a.t === "none") return true;
	if (a.t === "num" && b.t === "num") return a.v === b.v;
	if (a.t === "str" && b.t === "str") return a.v === b.v;
	if (a.t === "bool" && b.t === "bool") return a.v === b.v;
	if (a.t === "list" && b.t === "list") return a.v.length === b.v.length && a.v.every((x, i) => eq(x, b.v[i]));
	if (a.t === "dict" && b.t === "dict") {
		if (a.keys.length !== b.keys.length) return false;
		return a.keys.every((k, i) => {
			const j = dictIndex(b.keys, k);
			return j >= 0 && eq(a.vals[i], b.vals[j]);
		});
	}
	return false;
}
function typeName(v) {
	if (v.t === "num") return Number.isInteger(v.v) ? "int" : "float";
	if (v.t === "str") return "str";
	if (v.t === "bool") return "bool";
	if (v.t === "list") return "list";
	if (v.t === "dict") return "dict";
	if (v.t === "fn") return "function";
	return "NoneType";
}
function strVal(v) {
	if (v.t === "none") return "None";
	if (v.t === "bool") return v.v ? "True" : "False";
	if (v.t === "num") return Number.isInteger(v.v) ? String(v.v) : String(v.v);
	if (v.t === "str") return v.v;
	if (v.t === "fn") return `<function ${v.name}>`;
	if (v.t === "dict") {
		if (v.keys.length === 0) return "{}";
		return "{" + v.keys.map((k, i) => `${reprVal(k)}: ${reprVal(v.vals[i])}`).join(", ") + "}";
	}
	return "[" + v.v.map(reprVal).join(", ") + "]";
}
function reprVal(v) {
	if (v.t === "str") return "'" + v.v.replace(/'/g, "\\'") + "'";
	return strVal(v);
}
function dictIndex(keys, key) {
	return keys.findIndex((k) => eq(k, key));
}
function assertHashable(key, line) {
	if (key.t === "list" || key.t === "dict" || key.t === "fn") throw err("TypeError", "unhashable type: '" + typeName(key) + "'", line, "Dictionary keys must be simple values — strings, numbers, or True/False.", "Use a string key, for example user[\"name\"].");
}
function sliceIndices(length, start, stop, step) {
	let s;
	let e;
	if (step > 0) {
		s = start === null ? 0 : start;
		e = stop === null ? length : stop;
		if (s < 0) s += length;
		if (e < 0) e += length;
		if (s < 0) s = 0;
		if (e < 0) e = 0;
		if (s > length) s = length;
		if (e > length) e = length;
	} else {
		s = start === null ? length - 1 : start;
		e = stop === null ? -1 : stop;
		if (start !== null) {
			if (s < 0) s += length;
			if (s < 0) s = -1;
			if (s >= length) s = length - 1;
		}
		if (stop !== null) {
			if (e < 0) e += length;
			if (e < -1) e = -1;
			if (e >= length) e = length;
		}
	}
	const out = [];
	if (step > 0) for (let i = s; i < e; i += step) out.push(i);
	else for (let i = s; i > e; i += step) out.push(i);
	return out;
}
function cmpVals(a, b) {
	if (isNumeric(a) && isNumeric(b)) return num(a) - num(b);
	if (a.t === "str" && b.t === "str") return a.v < b.v ? -1 : a.v > b.v ? 1 : 0;
	return typeName(a).localeCompare(typeName(b));
}
function suggest(name, names) {
	let best = null;
	let bestD = 3;
	for (const n of names) {
		const d = levenshtein(name, n);
		if (d < bestD) {
			bestD = d;
			best = n;
		}
	}
	return best;
}
function levenshtein(a, b) {
	const m = [];
	for (let i = 0; i <= a.length; i++) {
		m[i] = [i];
		for (let j = 1; j <= b.length; j++) if (i === 0) m[0][j] = j;
		else m[i][j] = Math.min(m[i - 1][j] + 1, m[i][j - 1] + 1, m[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
	}
	return m[a.length][b.length];
}
var BUILTIN_NAMES = [
	"print",
	"len",
	"str",
	"int",
	"range",
	"sum",
	"min",
	"max",
	"abs",
	"type",
	"sorted",
	"list",
	"enumerate"
];
function builtinsEnv() {
	const e = new Env(null);
	for (const n of BUILTIN_NAMES) e.set(n, {
		t: "fn",
		name: n,
		params: [],
		body: [],
		env: e
	});
	return e;
}
function runPython(source) {
	try {
		if (typeof source !== "string") return {
			ok: false,
			stdout: "",
			error: err("RuntimeError", "No code provided.", 1, "Type some Python in the editor.", "Start with print(\"Hello\")")
		};
		if (!source.trim()) return {
			ok: false,
			stdout: "",
			error: err("SyntaxError", "Your editor is empty.", 1, "Python needs at least one instruction.", "Type: print(\"Hello, Jarvis\")")
		};
		const ast = new Parser(tokenize(source)).parse();
		const interp = new Interpreter(new Env(builtinsEnv()));
		interp.run(ast);
		return {
			ok: true,
			stdout: interp.stdout.join("\n") + (interp.stdout.length ? "\n" : "")
		};
	} catch (e) {
		if (e && typeof e === "object" && "kind" in e) return {
			ok: false,
			stdout: "",
			error: e
		};
		return {
			ok: false,
			stdout: "",
			error: err("RuntimeError", e instanceof Error ? e.message : "Unknown error", 1, "Something unexpected happened.", "Try simplifying your code.")
		};
	}
}
function normalizeOutput(s) {
	return s.replace(/\r\n/g, "\n").replace(/[ \t]+$/gm, "").replace(/\n+$/, "");
}
function outputsMatch(got, expected) {
	return normalizeOutput(got) === normalizeOutput(expected);
}
var HABITS = [
	{
		re: /\bconsole\.log\b/,
		title: "That's JavaScript",
		what: "You used console.log — that's JavaScript, not Python.",
		why: "Python talks to the screen with the print() function.",
		fix: "Replace console.log with print.",
		example: "print(\"Hello\")"
	},
	{
		re: /\bSystem\.out\.print/,
		title: "That's Java",
		what: "System.out.println is Java.",
		why: "Python uses print().",
		fix: "Write print(\"...\") instead.",
		example: "print(\"Hello\")"
	},
	{
		re: /\b(let|const|var)\s+[A-Za-z_]/,
		title: "That's JavaScript",
		what: "let / const / var are JavaScript keywords.",
		why: "In Python you just write the name, then =, then the value.",
		fix: "Drop let/const/var. Use: name = value",
		example: "score = 10"
	},
	{
		re: /\bfunction\s+[A-Za-z_]/,
		title: "That's JavaScript",
		what: "function is how JavaScript defines functions.",
		why: "Python uses def, a colon, then an indented body.",
		fix: "Write: def name(args):",
		example: "def greet(name):\n    return \"Hi \" + name"
	},
	{
		re: /^\s*print\s+["'].+["']\s*$/m,
		title: "Python 3 needs parentheses",
		what: "You wrote a Python 2 print statement.",
		why: "In Python 3, print is a function, so it needs parentheses.",
		fix: "Wrap the text in print(...)",
		example: "print(\"Hello, Jarvis\")"
	},
	{
		re: /\b(if|for|while|elif|else|def|function)\b[^\n]*\{/,
		title: "Python does not use { } for blocks",
		what: "Curly braces after if/for/while look like JavaScript or Java.",
		why: "Python groups code with indentation (spaces) after a colon. { } are only for dictionaries, like {\"name\": \"Ada\"}.",
		fix: "Use a colon and indent the next line with 4 spaces.",
		example: "if score >= 70:\n    print(\"PASS\")"
	}
];
function preScanHabits(source) {
	for (const h of HABITS) if (h.re.test(source)) return {
		status: "error",
		title: h.title,
		what: h.what,
		why: h.why,
		fix: h.fix,
		example: h.example
	};
	return null;
}
function analyzeRun(source, expected) {
	const habit = preScanHabits(source);
	const result = runPython(source);
	if (habit && !result.ok) return {
		result,
		feedback: {
			...habit,
			line: result.error?.line
		}
	};
	if (!result.ok && result.error) return {
		result,
		feedback: fromError(source, result.error)
	};
	if (outputsMatch(result.stdout, expected)) return {
		result,
		feedback: {
			status: "success",
			title: "Correct",
			what: "Your program produced the expected output.",
			why: "Python ran each line from top to bottom and print() showed the result.",
			fix: "On to the next task."
		}
	};
	return {
		result,
		feedback: fromMismatch(source, result.stdout, expected)
	};
}
function fromError(source, error) {
	const extra = extraHints(source, error);
	return {
		status: "error",
		title: error.kind,
		what: error.message,
		why: extra.why || error.hint,
		fix: extra.fix || error.fix,
		example: extra.example,
		line: error.line
	};
}
function extraHints(source, error) {
	const line = source.split("\n")[error.line - 1] ?? "";
	if (error.kind === "NameError") {
		const name = error.message.match(/'([^']+)'/)?.[1];
		if (name && new RegExp(`print\\(\\s*${name}\\s*\\)`).test(source) && !source.includes(`${name} =`) && !source.includes(`"${name}"`) && !source.includes(`'${name}'`)) return {
			why: `Python thinks ${name} is a variable, because it has no quotes. Variables must be created with = first. Text you want to show as-is is a string and needs quotes.`,
			fix: `If you meant to show the word ${name}, wrap it in quotes. If you meant a variable, assign it first.`,
			example: `print("${name}")\n# or\n${name} = "Ada"\nprint(${name})`
		};
	}
	if (error.kind === "SyntaxError" && /if |for |while |def |else/.test(line) && !line.includes(":")) return {
		why: "This kind of line starts a block. Python needs a colon at the end so it knows the next indented lines belong to it.",
		fix: "Add : at the end of the line.",
		example: line.trimEnd() + ":"
	};
	if (error.kind === "TypeError" && /concatenate|str.*int|int.*str/.test(error.message + error.hint)) return {
		why: "Python will not silently mix text and numbers with +.",
		fix: "Wrap the number in str(...) so it becomes text.",
		example: "print(\"Score: \" + str(10))"
	};
	if (error.kind === "IndentationError") return {
		why: "Spaces at the start of a line are part of the language, not decoration.",
		fix: "Use exactly 4 spaces per level. Keep lines in the same block lined up.",
		example: "if True:\n    print(\"indented\")"
	};
	return {};
}
function fromMismatch(source, got, expected) {
	const g = stripEnd(got);
	const e = stripEnd(expected);
	const gq = g.replace(/^['"]|['"]$/g, "");
	const eq = e.replace(/^['"]|['"]$/g, "");
	if (g === `"${e}"` || g === `'${e}'`) return {
		status: "wrong",
		title: "Extra quotes",
		what: "Your program printed quote marks around the text.",
		why: "print already shows the string. If you write extra quotes inside the string, they become part of the output.",
		fix: "Print the text without extra quote characters inside.",
		example: `print("${e}")`,
		got: g,
		expected: e
	};
	if (g.toLowerCase() === e.toLowerCase() && g !== e) return {
		status: "wrong",
		title: "Capital letters matter",
		what: "The letters are right but the capitalization is not.",
		why: "Python treats Hello and hello as different text.",
		fix: "Match the expected text exactly, including capitals.",
		got: g,
		expected: e
	};
	if (gq === e || g === eq) return {
		status: "wrong",
		title: "Almost — check quotes",
		what: "The words are close, but the quotes in the output do not match.",
		why: "Only characters inside print(...) that are part of the string appear. The wrapping quotes of the code do not print — unless you added extra ones.",
		fix: "Copy the expected text exactly inside one pair of quotes.",
		got: g,
		expected: e
	};
	if (g.replace(/\s+/g, "") === e.replace(/\s+/g, "")) return {
		status: "wrong",
		title: "Spacing does not match",
		what: "The words are right, the spaces are not.",
		why: "Python prints exactly the spaces you give it. Extra or missing spaces count as wrong.",
		fix: "Match spaces and line breaks exactly.",
		got: g,
		expected: e
	};
	if (!g) return {
		status: "wrong",
		title: "Nothing was printed",
		what: "The program ran, but print() never showed the required text.",
		why: "Assignments like name = \"Ada\" store a value. They do not show it. print() is what writes to the screen.",
		fix: "Call print(...) with the value you want to show.",
		example: source.includes("=") ? "After you assign, add: print(your_variable)" : `print("${e.split("\n")[0]}")`,
		got: g,
		expected: e
	};
	const gl = g.split("\n");
	const el = e.split("\n");
	if (gl.length !== el.length) return {
		status: "wrong",
		title: gl.length > el.length ? "Extra lines" : "Missing lines",
		what: `Python printed ${gl.length} line(s). The mission expected ${el.length}.`,
		why: "Each print() usually adds one line. A loop prints once per item.",
		fix: gl.length > el.length ? "Remove extra print() calls." : "Add the missing print() so every required line appears.",
		got: g,
		expected: e
	};
	return {
		status: "wrong",
		title: "Output does not match",
		what: "The program ran, but it printed something different from the mission.",
		why: "Read the task again. print() shows exactly what you pass it — numbers calculate, quotes stay as text.",
		fix: "Compare your output with the expected output line by line, then adjust the print() or the calculation.",
		got: g,
		expected: e
	};
}
function stripEnd(s) {
	return s.replace(/\r\n/g, "\n").replace(/[ \t]+$/gm, "").replace(/\n+$/, "");
}
function formatOutput(s) {
	if (!s) return "(empty)";
	return s.replace(/\n+$/, "");
}
var bus = null;
var muted = false;
function getBus() {
	if (typeof window === "undefined") return null;
	if (bus) return bus;
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return null;
	const ctx = new AC({ latencyHint: "interactive" });
	const master = ctx.createGain();
	const sfx = ctx.createGain();
	sfx.gain.value = .28;
	master.gain.value = muted ? 0 : 1;
	sfx.connect(master);
	master.connect(ctx.destination);
	bus = {
		ctx,
		master,
		sfx
	};
	return bus;
}
function resume() {
	const b = getBus();
	if (!b) return;
	if (b.ctx.state === "suspended") b.ctx.resume();
}
function beep(opts) {
	if (muted) return;
	const b = getBus();
	if (!b) return;
	resume();
	const t0 = b.ctx.currentTime + (opts.delay ?? 0);
	const osc = b.ctx.createOscillator();
	const g = b.ctx.createGain();
	osc.type = opts.type ?? "sine";
	osc.frequency.setValueAtTime(opts.freq, t0);
	if (opts.slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, opts.slide), t0 + opts.dur);
	const vol = opts.gain ?? .22;
	g.gain.setValueAtTime(1e-4, t0);
	g.gain.exponentialRampToValueAtTime(vol, t0 + .012);
	g.gain.exponentialRampToValueAtTime(1e-4, t0 + opts.dur);
	osc.connect(g);
	g.connect(b.sfx);
	osc.start(t0);
	osc.stop(t0 + opts.dur + .02);
	osc.onended = () => {
		osc.disconnect();
		g.disconnect();
	};
}
var audio = {
	unlock() {
		resume();
	},
	setMuted(v) {
		muted = v;
		if (bus) bus.master.gain.setTargetAtTime(v ? 0 : 1, bus.ctx.currentTime, .02);
	},
	click() {
		beep({
			freq: 720,
			dur: .05,
			type: "square",
			gain: .08
		});
	},
	success() {
		beep({
			freq: 523,
			dur: .09,
			type: "triangle",
			gain: .16
		});
		beep({
			freq: 784,
			dur: .12,
			type: "triangle",
			gain: .14,
			delay: .07
		});
	},
	fail() {
		beep({
			freq: 220,
			dur: .16,
			type: "sawtooth",
			gain: .1,
			slide: 110
		});
	},
	complete() {
		beep({
			freq: 392,
			dur: .12,
			type: "triangle",
			gain: .14
		});
		beep({
			freq: 523,
			dur: .12,
			type: "triangle",
			gain: .14,
			delay: .1
		});
		beep({
			freq: 659,
			dur: .18,
			type: "triangle",
			gain: .16,
			delay: .2
		});
	},
	levelup() {
		beep({
			freq: 440,
			dur: .1,
			type: "square",
			gain: .1
		});
		beep({
			freq: 554,
			dur: .1,
			type: "square",
			gain: .1,
			delay: .09
		});
		beep({
			freq: 659,
			dur: .1,
			type: "square",
			gain: .1,
			delay: .18
		});
		beep({
			freq: 880,
			dur: .2,
			type: "triangle",
			gain: .14,
			delay: .28
		});
	},
	unlockReward() {
		beep({
			freq: 330,
			dur: .16,
			type: "sine",
			gain: .14
		});
		beep({
			freq: 495,
			dur: .16,
			type: "sine",
			gain: .12,
			delay: .12
		});
		beep({
			freq: 660,
			dur: .28,
			type: "triangle",
			gain: .16,
			delay: .24
		});
	},
	go() {
		beep({
			freq: 880,
			dur: .14,
			type: "square",
			gain: .12
		});
	}
};
if (typeof window !== "undefined") {
	window.addEventListener("pointerdown", () => audio.unlock(), { once: true });
	window.addEventListener("keydown", () => audio.unlock(), { once: true });
	document.addEventListener("visibilitychange", () => {
		if (document.visibilityState === "visible") audio.unlock();
	});
}
function CodeEditor({ challenge, onPass, onFail, disabled }) {
	const [code, setCode] = (0, import_react.useState)(challenge.starter);
	const [feedback, setFeedback] = (0, import_react.useState)(null);
	const [attempts, setAttempts] = (0, import_react.useState)(0);
	const [hintN, setHintN] = (0, import_react.useState)(0);
	const [showSol, setShowSol] = (0, import_react.useState)(false);
	const [passed, setPassed] = (0, import_react.useState)(false);
	const ta = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setCode(challenge.starter);
		setFeedback(null);
		setAttempts(0);
		setHintN(0);
		setShowSol(false);
		setPassed(false);
	}, [challenge.id, challenge.starter]);
	function run() {
		if (disabled || passed) return;
		const { feedback: fb } = analyzeRun(code, challenge.expected);
		setFeedback(fb);
		setAttempts((n) => n + 1);
		if (fb.status === "success") {
			audio.success();
			setPassed(true);
			window.setTimeout(onPass, 550);
		} else {
			audio.fail();
			onFail?.();
		}
	}
	function onKey(e) {
		if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
			e.preventDefault();
			run();
			return;
		}
		if (e.key === "Tab") {
			e.preventDefault();
			const el = e.currentTarget;
			const start = el.selectionStart;
			const end = el.selectionEnd;
			const next = code.slice(0, start) + "    " + code.slice(end);
			setCode(next);
			requestAnimationFrame(() => {
				el.selectionStart = el.selectionEnd = start + 4;
			});
		}
	}
	const lines = Math.max(6, code.split("\n").length);
	const nums = Array.from({ length: lines }, (_, i) => i + 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-card)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
						children: challenge.concept
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 text-lg font-semibold leading-snug text-fg",
						children: challenge.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: challenge.prompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "mt-3 rounded-md bg-bg-elevated px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
								className: "cursor-pointer text-sm font-medium text-fg",
								children: "Python briefing"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: challenge.briefing
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-2 overflow-x-auto font-mono text-xs leading-relaxed text-accent",
								children: challenge.example
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("overflow-hidden rounded-xl bg-bg-elevated shadow-[var(--shadow-card)]", feedback?.line && feedback.status !== "success" && "ring-1 ring-danger/60"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-[11px] uppercase tracking-[0.12em] text-subtle",
						children: "mission.py"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-subtle",
						children: "Tab indents · Ctrl+Enter runs"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-36",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "select-none bg-bg py-3 pl-3 pr-2 font-mono text-xs leading-6 text-subtle tabular",
						children: nums.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("text-right", feedback?.line === n && "text-danger"),
							children: n
						}, n))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						ref: ta,
						value: code,
						onChange: (e) => setCode(e.target.value),
						onKeyDown: onKey,
						spellCheck: false,
						autoCapitalize: "off",
						autoCorrect: "off",
						disabled: disabled || passed,
						"aria-label": "Python editor",
						className: "min-h-36 w-full resize-y bg-transparent px-3 py-3 font-mono text-[16px] leading-6 text-fg outline-none md:text-sm"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: run,
					disabled: disabled || passed,
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 translate-x-px" }), passed ? "Passed" : "Run code"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					onClick: () => {
						audio.click();
						setCode(challenge.starter);
						setFeedback(null);
						setPassed(false);
					},
					disabled,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					disabled: hintN >= challenge.hints.length,
					onClick: () => {
						audio.click();
						setHintN((n) => Math.min(challenge.hints.length, n + 1));
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "size-4" }),
						"Hint ",
						hintN > 0 ? `${hintN}/${challenge.hints.length}` : ""
					]
				}), attempts >= 2 && !passed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => {
						audio.click();
						setShowSol(true);
					},
					children: "Show working code"
				})]
			}),
			hintN > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 rounded-lg bg-surface px-3 py-2 text-sm text-muted",
				children: challenge.hints.slice(0, hintN).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: h }, h))
			}),
			showSol && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "overflow-x-auto rounded-lg bg-surface-2 p-3 font-mono text-xs text-accent",
				children: challenge.solution
			}),
			feedback && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeedbackCard, { fb: feedback })
		]
	});
}
function FeedbackCard({ fb }) {
	const ok = fb.status === "success";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("animate-rise rounded-xl p-4 shadow-[var(--shadow-card)]", ok ? "bg-success/10" : "bg-surface"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5 text-success" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-5 text-warn" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-fg",
						children: fb.title
					}),
					fb.line ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto font-mono text-xs text-subtle",
						children: ["line ", fb.line]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-fg",
				children: fb.what
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-fg",
					children: "Why. "
				}), fb.why]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-fg",
					children: "Fix. "
				}), fb.fix]
			}),
			fb.example && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-3 overflow-x-auto rounded-md bg-bg p-3 font-mono text-xs text-accent",
				children: fb.example
			}),
			(fb.got !== void 0 || fb.expected !== void 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-2 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutBlock, {
					label: "Yours",
					value: formatOutput(fb.got ?? ""),
					bad: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutBlock, {
					label: "Expected",
					value: formatOutput(fb.expected ?? "")
				})]
			})
		]
	});
}
function OutBlock({ label, value, bad }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-bg p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.12em] text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: cn("mt-1 whitespace-pre-wrap font-mono text-xs", bad ? "text-danger" : "text-success"),
			children: value
		})]
	});
}
var LEVELS_PLUS = [
	{
		id: 26,
		title: "Remainder Seal",
		job: "Legend",
		difficulty: "Medium",
		description: "The % operator is leftover after division. Even numbers leave 0.",
		objective: "Print remainders and spot an even number.",
		rewardCoins: 2800,
		rewardXp: 900,
		unlockRewardId: "remainder-seal",
		unlockReward: "Remainder Seal",
		careerUnlock: "master",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Leftover, not the quotient",
				body: "17 % 5 is 2 because 5 fits into 17 three times and 2 is left. n % 2 == 0 means n is even. The % sign is not a percentage here — it is remainder.",
				example: "print(17 % 5)  # 2\nprint(8 % 2)   # 0"
			},
			{
				type: "choice",
				concept: "even test",
				question: "Which check is True when n is even?",
				options: [
					{
						id: "a",
						label: "n % 2 == 1",
						correct: false,
						explain: "A remainder of 1 means odd: 7 % 2 is 1."
					},
					{
						id: "b",
						label: "n % 2 == 0",
						correct: true,
						explain: "Even numbers divide by 2 with nothing left."
					},
					{
						id: "c",
						label: "n / 2 == 0",
						correct: false,
						explain: "Division gives a size, not a leftover. 8 / 2 is 4, not 0."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l26-mod",
					title: "Leftover",
					concept: "% remainder",
					prompt: "Print 17 % 5, then print 8 % 2, each on its own line.",
					briefing: "Do not quote the numbers. % is math.",
					example: "print(17 % 5)",
					starter: "",
					expected: "2\n0\n",
					solution: "print(17 % 5)\nprint(8 % 2)",
					hints: [
						"print(17 % 5)",
						"print(8 % 2)",
						"Two print calls."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l26-even",
					title: "Parity stamp",
					concept: "if + %",
					prompt: "n is 14. If n is even print EVEN, otherwise print ODD.",
					briefing: "if n % 2 == 0:",
					example: "if n % 2 == 0:\n    print(\"EVEN\")",
					starter: "n = 14\n",
					expected: "EVEN\n",
					solution: "n = 14\nif n % 2 == 0:\n    print(\"EVEN\")\nelse:\n    print(\"ODD\")",
					hints: [
						"if n % 2 == 0:",
						"print(\"EVEN\")",
						"else: print(\"ODD\")"
					]
				}
			}
		]
	},
	{
		id: 27,
		title: "Power Cell",
		job: "Legend",
		difficulty: "Medium",
		description: "** raises a number. // divides and throws away the decimal.",
		objective: "Print a square and an integer division.",
		rewardCoins: 2900,
		rewardXp: 950,
		unlockRewardId: "power-cell",
		unlockReward: "Power Cell",
		careerUnlock: "master",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Two division signs",
				body: "2 ** 5 is 32. 7 / 2 is 3.5. 7 // 2 is 3 — the floor. Use // when you want a whole number of groups.",
				example: "print(2 ** 5)\nprint(7 // 2)"
			},
			{
				type: "code",
				challenge: {
					id: "l27-pow",
					title: "Square",
					concept: "**",
					prompt: "Print 6 raised to the power of 2 using **.",
					briefing: "6 ** 2 is 36, not 12.",
					example: "print(6 ** 2)",
					starter: "",
					expected: "36\n",
					solution: "print(6 ** 2)",
					hints: [
						"Use ** not *",
						"print(6 ** 2)",
						"The answer is 36."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l27-floor",
					title: "Whole groups",
					concept: "//",
					prompt: "Print 17 // 5. That is how many full groups of 5 fit into 17.",
					briefing: "// drops the leftover. 17 // 5 is 3, not 3.4.",
					example: "print(17 // 5)",
					starter: "",
					expected: "3\n",
					solution: "print(17 // 5)",
					hints: [
						"Use // not /",
						"print(17 // 5)",
						"The leftover 2 is discarded."
					]
				}
			}
		]
	},
	{
		id: 28,
		title: "Repeat Tape",
		job: "Legend",
		difficulty: "Easy / Medium",
		description: "A string times an integer repeats the text.",
		objective: "Print a repeated signal and a dashed rule.",
		rewardCoins: 3e3,
		rewardXp: 1e3,
		unlockRewardId: "repeat-tape",
		unlockReward: "Repeat Tape",
		careerUnlock: "master",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Text × number",
				body: "\"go\" * 3 is gogogo. The number must be an integer. A space string times 4 is four spaces. This is how you draw a rule without typing it by hand.",
				example: "print(\"go\" * 3)\nprint(\"-\" * 5)"
			},
			{
				type: "code",
				challenge: {
					id: "l28-go",
					title: "Call three times",
					concept: "str * int",
					prompt: "Print go repeated exactly three times, no spaces: gogogo.",
					briefing: "\"go\" * 3",
					example: "print(\"go\" * 3)",
					starter: "",
					expected: "gogogo\n",
					solution: "print(\"go\" * 3)",
					hints: [
						"\"go\" * 3",
						"No extra spaces.",
						"Wrap in print."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l28-rule",
					title: "Rule line",
					concept: "str * int",
					prompt: "Print a line of exactly 8 dashes using *.",
					briefing: "\"-\" * 8",
					example: "print(\"-\" * 8)",
					starter: "",
					expected: "--------\n",
					solution: "print(\"-\" * 8)",
					hints: [
						"\"-\" * 8",
						"Eight dashes, no spaces.",
						"print that."
					]
				}
			}
		]
	},
	{
		id: 29,
		title: "Member Pass",
		job: "Legend",
		difficulty: "Medium",
		description: "in asks whether something lives inside a string, list, or dict.",
		objective: "Test membership and print True or False.",
		rewardCoins: 3100,
		rewardXp: 1050,
		unlockRewardId: "member-pass",
		unlockReward: "Member Pass",
		careerUnlock: "legend",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Present or absent",
				body: "\"th\" in \"Python\" is True. 9 in [1, 2, 3] is False. \"name\" in user checks keys, not values. not in is the opposite.",
				example: "print(\"th\" in \"Python\")\nprint(9 not in [1, 2, 3])"
			},
			{
				type: "choice",
				concept: "in on dict",
				question: "For user = {\"name\": \"Ada\"}, what does \"Ada\" in user check?",
				options: [
					{
						id: "a",
						label: "Whether Ada is a value",
						correct: false,
						explain: "in on a dict checks keys only. The key is name, the value is Ada."
					},
					{
						id: "b",
						label: "Whether Ada is a key",
						correct: true,
						explain: "\"Ada\" in user is False because the key is \"name\"."
					},
					{
						id: "c",
						label: "Whether the dict is named Ada",
						correct: false,
						explain: "The dict is named user. in looks inside it."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l29-str",
					title: "Substring",
					concept: "in str",
					prompt: "Print whether th is inside the string Python.",
					briefing: "print(\"th\" in \"Python\") shows True.",
					example: "print(\"th\" in \"Python\")",
					starter: "",
					expected: "True\n",
					solution: "print(\"th\" in \"Python\")",
					hints: [
						"\"th\" in \"Python\"",
						"Print the comparison.",
						"True has a capital T."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l29-list",
					title: "Missing seat",
					concept: "not in",
					prompt: "Print whether 9 is not in the list [1, 2, 3].",
					briefing: "9 not in [1, 2, 3] is True.",
					example: "print(9 not in [1, 2, 3])",
					starter: "",
					expected: "True\n",
					solution: "print(9 not in [1, 2, 3])",
					hints: [
						"Use not in",
						"print(9 not in [1, 2, 3])",
						"True — 9 is missing."
					]
				}
			}
		]
	},
	{
		id: 30,
		title: "Chain Gate",
		job: "Oracle",
		difficulty: "Medium",
		description: "Python lets you write 1 < n < 10 the way math class does.",
		objective: "Print chained comparisons.",
		rewardCoins: 3200,
		rewardXp: 1100,
		unlockRewardId: "chain-gate",
		unlockReward: "Chain Gate",
		careerUnlock: "legend",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Both sides at once",
				body: "1 < n < 10 is True only if n is greater than 1 and less than 10. You do not need and. Both comparisons must hold.",
				example: "n = 7\nprint(1 < n < 10)"
			},
			{
				type: "code",
				challenge: {
					id: "l30-in",
					title: "Inside the band",
					concept: "chained compare",
					prompt: "n is 7. Print the result of 1 < n < 10.",
					briefing: "7 is between 1 and 10, so True.",
					example: "print(1 < n < 10)",
					starter: "n = 7\n",
					expected: "True\n",
					solution: "n = 7\nprint(1 < n < 10)",
					hints: [
						"print(1 < n < 10)",
						"No and needed.",
						"True."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l30-out",
					title: "Outside",
					concept: "chained compare",
					prompt: "n is 10. Print 1 < n < 10. Think carefully: is 10 less than 10?",
					briefing: "The right side is strict. 10 < 10 is False, so the chain is False.",
					example: "print(1 < n < 10)",
					starter: "n = 10\n",
					expected: "False\n",
					solution: "n = 10\nprint(1 < n < 10)",
					hints: [
						"10 is not less than 10.",
						"print(1 < n < 10)",
						"False."
					]
				}
			}
		]
	},
	{
		id: 31,
		title: "None Watch",
		job: "Oracle",
		difficulty: "Medium",
		description: "None is a real value that means “nothing here”.",
		objective: "Print None and branch when a box is empty.",
		rewardCoins: 3300,
		rewardXp: 1150,
		unlockRewardId: "none-watch",
		unlockReward: "None Watch",
		careerUnlock: "legend",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Capital N",
				body: "None is a keyword, not a string. print(None) shows None. if x is None is the usual test, but == None also works here. Do not quote it.",
				example: "x = None\nprint(x)"
			},
			{
				type: "code",
				challenge: {
					id: "l31-print",
					title: "Empty box",
					concept: "None",
					prompt: "Assign x = None, then print x.",
					briefing: "No quotes around None.",
					example: "x = None\nprint(x)",
					starter: "",
					expected: "None\n",
					solution: "x = None\nprint(x)",
					hints: [
						"x = None",
						"No quotes.",
						"print(x)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l31-if",
					title: "Missing file",
					concept: "None branch",
					prompt: "note is None. If note equals None print MISSING, otherwise print note.",
					briefing: "if note == None:",
					example: "if note == None:\n    print(\"MISSING\")",
					starter: "note = None\n",
					expected: "MISSING\n",
					solution: "note = None\nif note == None:\n    print(\"MISSING\")\nelse:\n    print(note)",
					hints: [
						"if note == None:",
						"print(\"MISSING\")",
						"else: print(note)"
					]
				}
			}
		]
	},
	{
		id: 32,
		title: "Truth Lens",
		job: "Oracle",
		difficulty: "Medium / Hard",
		description: "Empty lists and empty strings are False in an if.",
		objective: "Branch on emptiness.",
		rewardCoins: 3400,
		rewardXp: 1200,
		unlockRewardId: "truth-lens",
		unlockReward: "Truth Lens",
		careerUnlock: "legend",
		chapter: "algorithms",
		steps: [
			{
				type: "brief",
				title: "Empty is False",
				body: "if box: is False when box is []. if text: is False when text is \"\". Non-empty values are True. This saves you writing len(box) > 0.",
				example: "if box:\n    print(\"full\")\nelse:\n    print(\"empty\")"
			},
			{
				type: "choice",
				concept: "truthiness",
				question: "What does if \"\": print(\"yes\") do?",
				options: [
					{
						id: "a",
						label: "Prints yes",
						correct: false,
						explain: "An empty string is False, so the block is skipped."
					},
					{
						id: "b",
						label: "Prints nothing",
						correct: true,
						explain: "Empty string is False. The print never runs."
					},
					{
						id: "c",
						label: "Crashes",
						correct: false,
						explain: "Empty strings are legal. They are just False in a condition."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l32-list",
					title: "Empty crate",
					concept: "list truthiness",
					prompt: "box is []. If box is non-empty print full, otherwise print empty.",
					briefing: "if box: else.",
					example: "if box:\n    print(\"full\")\nelse:\n    print(\"empty\")",
					starter: "box = []\n",
					expected: "empty\n",
					solution: "box = []\nif box:\n    print(\"full\")\nelse:\n    print(\"empty\")",
					hints: [
						"if box:",
						"else: print(\"empty\")",
						"[] is False."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l32-str",
					title: "Named",
					concept: "str truthiness",
					prompt: "name is Ada. If name is non-empty print READY, otherwise print WAIT.",
					briefing: "A non-empty string is True.",
					example: "if name:\n    print(\"READY\")",
					starter: "name = \"Ada\"\n",
					expected: "READY\n",
					solution: "name = \"Ada\"\nif name:\n    print(\"READY\")\nelse:\n    print(\"WAIT\")",
					hints: [
						"if name:",
						"print(\"READY\")",
						"Ada is non-empty."
					]
				}
			}
		]
	},
	{
		id: 33,
		title: "Swap File",
		job: "Sage",
		difficulty: "Medium",
		description: "replace rewrites text. find returns an index or -1.",
		objective: "Rewrite a callsign and locate a letter.",
		rewardCoins: 3500,
		rewardXp: 1250,
		unlockRewardId: "swap-file",
		unlockReward: "Swap File",
		careerUnlock: "oracle",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "New string, old unchanged",
				body: "text.replace(\"a\", \"o\") returns a new string. find returns the first index, or -1 if missing. Remember the parentheses on methods.",
				example: "print(\"cat\".replace(\"a\", \"o\"))\nprint(\"Python\".find(\"t\"))"
			},
			{
				type: "code",
				challenge: {
					id: "l33-replace",
					title: "Rewrite",
					concept: "replace",
					prompt: "Print cat with a replaced by o, so the output is cot.",
					briefing: "\"cat\".replace(\"a\", \"o\")",
					example: "print(\"cat\".replace(\"a\", \"o\"))",
					starter: "",
					expected: "cot\n",
					solution: "print(\"cat\".replace(\"a\", \"o\"))",
					hints: [
						"replace(\"a\", \"o\")",
						"Call it on \"cat\".",
						"Print the result."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l33-find",
					title: "First t",
					concept: "find",
					prompt: "Print the index of the first t in Python using find.",
					briefing: "P=0, y=1, t=2. find returns 2.",
					example: "print(\"Python\".find(\"t\"))",
					starter: "",
					expected: "2\n",
					solution: "print(\"Python\".find(\"t\"))",
					hints: [
						"\"Python\".find(\"t\")",
						"Indexes start at 0.",
						"The first t is 2."
					]
				}
			}
		]
	},
	{
		id: 34,
		title: "Prefix Badge",
		job: "Sage",
		difficulty: "Medium",
		description: "startswith and endswith check the edges of a string.",
		objective: "Print True/False for a prefix and a suffix.",
		rewardCoins: 3600,
		rewardXp: 1300,
		unlockRewardId: "prefix-badge",
		unlockReward: "Prefix Badge",
		careerUnlock: "oracle",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "Edges only",
				body: "\"hello\".startswith(\"he\") is True. \"hello\".endswith(\"HE\") is False — capitals matter. These methods return booleans, so you can print them or use them in if.",
				example: "print(\"hello\".startswith(\"he\"))\nprint(\"file.py\".endswith(\".py\"))"
			},
			{
				type: "code",
				challenge: {
					id: "l34-start",
					title: "Opens with",
					concept: "startswith",
					prompt: "Print whether hello starts with he.",
					briefing: "startswith returns True or False.",
					example: "print(\"hello\".startswith(\"he\"))",
					starter: "",
					expected: "True\n",
					solution: "print(\"hello\".startswith(\"he\"))",
					hints: [
						"\"hello\".startswith(\"he\")",
						"Print it.",
						"True."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l34-end",
					title: "Python file",
					concept: "endswith",
					prompt: "name is mission.py. Print whether it ends with .py.",
					briefing: "The dot is part of the suffix string.",
					example: "print(name.endswith(\".py\"))",
					starter: "name = \"mission.py\"\n",
					expected: "True\n",
					solution: "name = \"mission.py\"\nprint(name.endswith(\".py\"))",
					hints: [
						"name.endswith(\".py\")",
						"Include the dot.",
						"Print the boolean."
					]
				}
			}
		]
	},
	{
		id: 35,
		title: "Digit Gate",
		job: "Sage",
		difficulty: "Medium",
		description: "isdigit and isalpha classify a whole string.",
		objective: "Print whether tokens are digits or letters.",
		rewardCoins: 3700,
		rewardXp: 1350,
		unlockRewardId: "digit-gate",
		unlockReward: "Digit Gate",
		careerUnlock: "oracle",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "The whole string",
				body: "\"42\".isdigit() is True. \"4a\".isdigit() is False — every character must be a digit. isalpha is the letter version. Empty strings are False.",
				example: "print(\"42\".isdigit())\nprint(\"Ada\".isalpha())"
			},
			{
				type: "code",
				challenge: {
					id: "l35-digit",
					title: "Numeric token",
					concept: "isdigit",
					prompt: "Print whether 42 (as a string) is all digits, then whether 4a is all digits.",
					briefing: "Two lines: True then False.",
					example: "print(\"42\".isdigit())\nprint(\"4a\".isdigit())",
					starter: "",
					expected: "True\nFalse\n",
					solution: "print(\"42\".isdigit())\nprint(\"4a\".isdigit())",
					hints: [
						"\"42\".isdigit()",
						"\"4a\".isdigit()",
						"Two prints."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l35-alpha",
					title: "Letters only",
					concept: "isalpha",
					prompt: "Print whether Ada is all letters.",
					briefing: "isalpha() — parentheses required.",
					example: "print(\"Ada\".isalpha())",
					starter: "",
					expected: "True\n",
					solution: "print(\"Ada\".isalpha())",
					hints: [
						"\"Ada\".isalpha()",
						"Do not forget ().",
						"True."
					]
				}
			}
		]
	},
	{
		id: 36,
		title: "Pop Stack",
		job: "Director",
		difficulty: "Medium / Hard",
		description: "pop removes and returns. insert places an item at an index.",
		objective: "Pop the last seat, then insert at the front.",
		rewardCoins: 3800,
		rewardXp: 1400,
		unlockRewardId: "pop-stack",
		unlockReward: "Pop Stack",
		careerUnlock: "oracle",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "Take and place",
				body: "team.pop() removes the last item and returns it — you can print that return. insert(0, x) puts x at the front. Both change the list in place.",
				example: "print(team.pop())\nteam.insert(0, \"Ada\")"
			},
			{
				type: "code",
				challenge: {
					id: "l36-pop",
					title: "Last out",
					concept: "pop",
					prompt: "team is Ada, Lin, Kai. Pop the last name and print what pop returns. Then print the list.",
					briefing: "Two prints: Kai then the remaining list.",
					example: "print(team.pop())\nprint(team)",
					starter: "team = [\"Ada\", \"Lin\", \"Kai\"]\n",
					expected: "Kai\n['Ada', 'Lin']\n",
					solution: "team = [\"Ada\", \"Lin\", \"Kai\"]\nprint(team.pop())\nprint(team)",
					hints: [
						"print(team.pop())",
						"Then print(team)",
						"Kai comes off the end."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l36-insert",
					title: "Front of line",
					concept: "insert",
					prompt: "queue is Lin, Kai. Insert Ada at index 0, then print the list.",
					briefing: "queue.insert(0, \"Ada\")",
					example: "queue.insert(0, \"Ada\")\nprint(queue)",
					starter: "queue = [\"Lin\", \"Kai\"]\n",
					expected: "['Ada', 'Lin', 'Kai']\n",
					solution: "queue = [\"Lin\", \"Kai\"]\nqueue.insert(0, \"Ada\")\nprint(queue)",
					hints: [
						"insert(0, \"Ada\")",
						"Index 0 is the front.",
						"print(queue) after."
					]
				}
			}
		]
	},
	{
		id: 37,
		title: "Mutate Rack",
		job: "Director",
		difficulty: "Medium / Hard",
		description: "sort and reverse change the list. They return None.",
		objective: "Sort in place, then reverse in place.",
		rewardCoins: 3900,
		rewardXp: 1450,
		unlockRewardId: "mutate-rack",
		unlockReward: "Mutate Rack",
		careerUnlock: "sage",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "In place vs sorted",
				body: "nums.sort() changes nums and returns None. sorted(nums) returns a new list. reverse() flips the current order. Print the list after you mutate it, not the method call.",
				example: "nums.sort()\nprint(nums)"
			},
			{
				type: "choice",
				concept: "sort return",
				question: "What does print(nums.sort()) show?",
				options: [
					{
						id: "a",
						label: "The sorted list",
						correct: false,
						explain: "sort returns None. Print nums afterwards."
					},
					{
						id: "b",
						label: "None",
						correct: true,
						explain: "Mutating methods return None. The list changed silently."
					},
					{
						id: "c",
						label: "An error",
						correct: false,
						explain: "It is legal — just not useful to print."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l37-sort",
					title: "Order in place",
					concept: "sort",
					prompt: "nums is [5, 1, 4]. Sort it in place, then print nums.",
					briefing: "nums.sort() then print(nums).",
					example: "nums.sort()\nprint(nums)",
					starter: "nums = [5, 1, 4]\n",
					expected: "[1, 4, 5]\n",
					solution: "nums = [5, 1, 4]\nnums.sort()\nprint(nums)",
					hints: [
						"nums.sort()",
						"Do not print the call.",
						"print(nums)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l37-rev",
					title: "Flip",
					concept: "reverse",
					prompt: "items is [1, 2, 3]. Reverse it in place, then print the list.",
					briefing: "items.reverse()",
					example: "items.reverse()\nprint(items)",
					starter: "items = [1, 2, 3]\n",
					expected: "[3, 2, 1]\n",
					solution: "items = [1, 2, 3]\nitems.reverse()\nprint(items)",
					hints: [
						"items.reverse()",
						"Then print(items)",
						"[3, 2, 1]"
					]
				}
			}
		]
	},
	{
		id: 38,
		title: "Count Desk",
		job: "Director",
		difficulty: "Medium",
		description: "count tells you how many times a value appears.",
		objective: "Count in a list and in a string.",
		rewardCoins: 4e3,
		rewardXp: 1500,
		unlockRewardId: "count-desk",
		unlockReward: "Count Desk",
		careerUnlock: "sage",
		chapter: "fluency",
		steps: [
			{
				type: "brief",
				title: "How many",
				body: "[1, 2, 1, 1].count(1) is 3. \"banana\".count(\"a\") is 3. Missing values count as 0, they do not crash.",
				example: "print(nums.count(1))\nprint(\"banana\".count(\"a\"))"
			},
			{
				type: "code",
				challenge: {
					id: "l38-list",
					title: "Ones",
					concept: "list.count",
					prompt: "nums is [1, 2, 1, 1]. Print how many times 1 appears.",
					briefing: "nums.count(1)",
					example: "print(nums.count(1))",
					starter: "nums = [1, 2, 1, 1]\n",
					expected: "3\n",
					solution: "nums = [1, 2, 1, 1]\nprint(nums.count(1))",
					hints: [
						"nums.count(1)",
						"Print that.",
						"The answer is 3."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l38-str",
					title: "Letter a",
					concept: "str.count",
					prompt: "Print how many times a appears in banana.",
					briefing: "\"banana\".count(\"a\")",
					example: "print(\"banana\".count(\"a\"))",
					starter: "",
					expected: "3\n",
					solution: "print(\"banana\".count(\"a\"))",
					hints: [
						"\"banana\".count(\"a\")",
						"Three a's.",
						"Print the number."
					]
				}
			}
		]
	},
	{
		id: 39,
		title: "Enum Walk",
		job: "Sage",
		difficulty: "Hard",
		description: "enumerate gives you the index and the item together.",
		objective: "Print each index, then each item.",
		rewardCoins: 4200,
		rewardXp: 1600,
		unlockRewardId: "enum-walk",
		unlockReward: "Enum Walk",
		careerUnlock: "sage",
		chapter: "fluency",
		steps: [{
			type: "brief",
			title: "Two names on the for line",
			body: "for i, x in enumerate(items): unpacks each pair. i is 0, 1, 2… x is the value. You need both names, a comma, and enumerate around the list.",
			example: "for i, x in enumerate([\"a\", \"b\"]):\n    print(i)\n    print(x)"
		}, {
			type: "code",
			challenge: {
				id: "l39-enum",
				title: "Numbered seats",
				concept: "enumerate",
				prompt: "Loop enumerate([\"a\", \"b\"]) as i, x. Print i then x, each on its own line.",
				briefing: "Four lines: 0, a, 1, b.",
				example: "for i, x in enumerate([\"a\", \"b\"]):\n    print(i)\n    print(x)",
				starter: "",
				expected: "0\na\n1\nb\n",
				solution: "for i, x in enumerate([\"a\", \"b\"]):\n    print(i)\n    print(x)",
				hints: [
					"for i, x in enumerate([\"a\", \"b\"]):",
					"print(i)",
					"print(x)"
				]
			}
		}]
	},
	{
		id: 40,
		title: "Pair Unpack",
		job: "Director",
		difficulty: "Hard",
		description: "items() yields (key, value) pairs you can unpack.",
		objective: "Walk a dict printing each key then each value.",
		rewardCoins: 4300,
		rewardXp: 1650,
		unlockRewardId: "pair-unpack",
		unlockReward: "Pair Unpack",
		careerUnlock: "sage",
		chapter: "fluency",
		steps: [{
			type: "brief",
			title: "Two names, one pair",
			body: "for k, v in scores.items(): sets k to the key and v to the value. Insertion order is Ada then Kai.",
			example: "for k, v in scores.items():\n    print(k)\n    print(v)"
		}, {
			type: "code",
			challenge: {
				id: "l40-items",
				title: "Open the pairs",
				concept: "dict.items",
				prompt: "scores maps Ada to 90 and Kai to 70. Unpack items as k, v. Print k then v, each on its own line.",
				briefing: "Four lines: Ada, 90, Kai, 70.",
				example: "for k, v in scores.items():\n    print(k)\n    print(v)",
				starter: "scores = {\"Ada\": 90, \"Kai\": 70}\n",
				expected: "Ada\n90\nKai\n70\n",
				solution: "scores = {\"Ada\": 90, \"Kai\": 70}\nfor k, v in scores.items():\n    print(k)\n    print(v)",
				hints: [
					"for k, v in scores.items():",
					"print(k)",
					"print(v)"
				]
			}
		}]
	},
	{
		id: 41,
		title: "Grid Key",
		job: "Director",
		difficulty: "Hard",
		description: "A list of lists is a grid. Two indexes: row, then column.",
		objective: "Read a cell, then overwrite one.",
		rewardCoins: 4400,
		rewardXp: 1700,
		unlockRewardId: "grid-key",
		unlockReward: "Grid Key",
		careerUnlock: "director",
		chapter: "studio",
		steps: [
			{
				type: "brief",
				title: "Row then column",
				body: "grid[1][0] is row 1, column 0. Both indexes start at 0. You can assign grid[0][1] = 9 to replace a cell.",
				example: "grid = [[1, 2], [3, 4]]\nprint(grid[1][0])"
			},
			{
				type: "code",
				challenge: {
					id: "l41-read",
					title: "Lower left",
					concept: "nested list",
					prompt: "grid is [[1, 2], [3, 4]]. Print the value at row 1, column 0.",
					briefing: "That cell is 3.",
					example: "print(grid[1][0])",
					starter: "grid = [[1, 2], [3, 4]]\n",
					expected: "3\n",
					solution: "grid = [[1, 2], [3, 4]]\nprint(grid[1][0])",
					hints: [
						"grid[1][0]",
						"Row 1 is [3, 4].",
						"Column 0 is 3."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l41-write",
					title: "Overwrite a cell",
					concept: "nested assign",
					prompt: "Set grid[0][1] to 9, then print the whole grid.",
					briefing: "grid[0][1] = 9 mutates the inner list.",
					example: "grid[0][1] = 9\nprint(grid)",
					starter: "grid = [[1, 2], [3, 4]]\n",
					expected: "[[1, 9], [3, 4]]\n",
					solution: "grid = [[1, 2], [3, 4]]\ngrid[0][1] = 9\nprint(grid)",
					hints: [
						"grid[0][1] = 9",
						"print(grid)",
						"The 2 becomes 9."
					]
				}
			}
		]
	},
	{
		id: 42,
		title: "Nested Vault",
		job: "Director",
		difficulty: "Hard",
		description: "A dictionary can hold another dictionary as a value.",
		objective: "Read a nested field, then update one.",
		rewardCoins: 4500,
		rewardXp: 1750,
		unlockRewardId: "nested-vault",
		unlockReward: "Nested Vault",
		careerUnlock: "director",
		chapter: "studio",
		steps: [
			{
				type: "brief",
				title: "Two keys in a row",
				body: "desk[\"Ada\"][\"role\"] walks into Ada's record, then reads role. You can assign desk[\"Ada\"][\"role\"] = \"lead\" to update.",
				example: "print(desk[\"Ada\"][\"role\"])"
			},
			{
				type: "code",
				challenge: {
					id: "l42-read",
					title: "Inner field",
					concept: "nested dict",
					prompt: "Print Ada's role from the nested desk record.",
					briefing: "desk[\"Ada\"][\"role\"]",
					example: "print(desk[\"Ada\"][\"role\"])",
					starter: "desk = {\"Ada\": {\"role\": \"lead\", \"score\": 90}, \"Lin\": {\"role\": \"dev\", \"score\": 70}}\n",
					expected: "lead\n",
					solution: "desk = {\"Ada\": {\"role\": \"lead\", \"score\": 90}, \"Lin\": {\"role\": \"dev\", \"score\": 70}}\nprint(desk[\"Ada\"][\"role\"])",
					hints: [
						"desk[\"Ada\"]",
						"then [\"role\"]",
						"print that."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l42-write",
					title: "Promote Ada",
					concept: "nested assign",
					prompt: "Set Ada's role to director, then print that role.",
					briefing: "desk[\"Ada\"][\"role\"] = \"director\"",
					example: "desk[\"Ada\"][\"role\"] = \"director\"\nprint(desk[\"Ada\"][\"role\"])",
					starter: "desk = {\"Ada\": {\"role\": \"lead\", \"score\": 90}}\n",
					expected: "director\n",
					solution: "desk = {\"Ada\": {\"role\": \"lead\", \"score\": 90}}\ndesk[\"Ada\"][\"role\"] = \"director\"\nprint(desk[\"Ada\"][\"role\"])",
					hints: [
						"desk[\"Ada\"][\"role\"] = \"director\"",
						"Then print it.",
						"Match lowercase director."
					]
				}
			}
		]
	},
	{
		id: 43,
		title: "Step Rail",
		job: "Grandmaster",
		difficulty: "Medium / Hard",
		description: "range can take a step so it skips numbers.",
		objective: "Print even numbers using range with a step.",
		rewardCoins: 4600,
		rewardXp: 1800,
		unlockRewardId: "step-rail",
		unlockReward: "Step Rail",
		careerUnlock: "director",
		chapter: "studio",
		timeLimitSec: 70,
		steps: [
			{
				type: "brief",
				title: "Three arguments",
				body: "range(start, stop, step). range(0, 8, 2) is 0, 2, 4, 6 — stop is still excluded. Negative steps count down.",
				example: "for i in range(0, 8, 2):\n    print(i)"
			},
			{
				type: "code",
				challenge: {
					id: "l43-evens",
					title: "Skip by two",
					concept: "range step",
					prompt: "Print 0, 2, 4, 6 using range with a step of 2. Stop before 8.",
					briefing: "range(0, 8, 2)",
					example: "for i in range(0, 8, 2):\n    print(i)",
					starter: "",
					expected: "0\n2\n4\n6\n",
					solution: "for i in range(0, 8, 2):\n    print(i)",
					hints: [
						"range(0, 8, 2)",
						"Stop is 8, last printed is 6.",
						"for i in ...: print(i)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l43-down",
					title: "Count down",
					concept: "negative step",
					prompt: "Print 5, 4, 3, 2, 1 using range with a negative step. Stop before 0.",
					briefing: "range(5, 0, -1)",
					example: "for i in range(5, 0, -1):\n    print(i)",
					starter: "",
					expected: "5\n4\n3\n2\n1\n",
					solution: "for i in range(5, 0, -1):\n    print(i)",
					hints: [
						"range(5, 0, -1)",
						"0 is the stop, not printed.",
						"print(i) in the loop."
					]
				}
			}
		]
	},
	{
		id: 44,
		title: "Mirror Glass",
		job: "Grandmaster",
		difficulty: "Medium / Hard",
		description: "[::-1] reverses a string or a list.",
		objective: "Mirror a word and a list.",
		rewardCoins: 4700,
		rewardXp: 1850,
		unlockRewardId: "mirror-glass",
		unlockReward: "Mirror Glass",
		careerUnlock: "director",
		chapter: "studio",
		steps: [
			{
				type: "brief",
				title: "Step of -1",
				body: "\"Python\"[::-1] is nohtyP. [1, 2, 3][::-1] is [3, 2, 1]. The empty start and end mean “the whole thing”, walking backwards.",
				example: "print(\"Python\"[::-1])\nprint([1, 2, 3][::-1])"
			},
			{
				type: "code",
				challenge: {
					id: "l44-str",
					title: "Mirror the name",
					concept: "reverse slice",
					prompt: "Print Python reversed with a slice.",
					briefing: "[::-1] on the string.",
					example: "print(\"Python\"[::-1])",
					starter: "",
					expected: "nohtyP\n",
					solution: "print(\"Python\"[::-1])",
					hints: [
						"\"Python\"[::-1]",
						"Capitals stay on the same letters.",
						"P ends up last."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l44-list",
					title: "Flip the list",
					concept: "reverse slice",
					prompt: "Print [1, 2, 3] reversed with a slice. Do not use reverse().",
					briefing: "[1, 2, 3][::-1] returns a new list.",
					example: "print([1, 2, 3][::-1])",
					starter: "",
					expected: "[3, 2, 1]\n",
					solution: "print([1, 2, 3][::-1])",
					hints: [
						"[::-1]",
						"Print the slice.",
						"[3, 2, 1]"
					]
				}
			}
		]
	},
	{
		id: 45,
		title: "Accum Forge",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "Start with empty text. Add a piece each time the loop runs.",
		objective: "Build a joined string without using join().",
		rewardCoins: 4800,
		rewardXp: 1900,
		unlockRewardId: "accum-forge",
		unlockReward: "Accum Forge",
		careerUnlock: "director",
		chapter: "studio",
		steps: [{
			type: "brief",
			title: "The running box",
			body: "out = \"\" then out = out + x builds a longer string. A space goes in as its own piece if you want gaps. Print once after the loop.",
			example: "out = \"\"\nfor w in words:\n    out = out + w\nprint(out)"
		}, {
			type: "code",
			challenge: {
				id: "l45-glue",
				title: "Smash together",
				concept: "accumulator",
				prompt: "words is go, team. Start out as empty. Add each word onto out. Print out once after the loop. Result: goteam",
				briefing: "No spaces. Concatenate in the loop, print after.",
				example: "out = \"\"\nfor w in words:\n    out = out + w\nprint(out)",
				starter: "words = [\"go\", \"team\"]\n",
				expected: "goteam\n",
				solution: "words = [\"go\", \"team\"]\nout = \"\"\nfor w in words:\n    out = out + w\nprint(out)",
				hints: [
					"out = \"\"",
					"out = out + w",
					"print(out) after the loop"
				]
			}
		}]
	},
	{
		id: 46,
		title: "Helper Link",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "One function can call another. Small tools stack.",
		objective: "Write double, then twice, and print twice(5).",
		rewardCoins: 5e3,
		rewardXp: 2e3,
		unlockRewardId: "helper-link",
		unlockReward: "Helper Link",
		careerUnlock: "grandmaster",
		chapter: "studio",
		steps: [{
			type: "brief",
			title: "Call down the stack",
			body: "twice(n) can return double(n) + double(n), or simply 2 * double(n). Define double first so twice can see it.",
			example: "def double(n):\n    return n * 2\ndef twice(n):\n    return double(n) + double(n)"
		}, {
			type: "code",
			challenge: {
				id: "l46-link",
				title: "Stacked tools",
				concept: "function calls function",
				prompt: "Write double(n) that returns n * 2. Write twice(n) that returns double(n) + double(n). Print twice(5).",
				briefing: "5 doubled is 10. 10 + 10 is 20.",
				example: "def double(n):\n    return n * 2",
				starter: "def double(n):\n    return n\n",
				expected: "20\n",
				solution: "def double(n):\n    return n * 2\ndef twice(n):\n    return double(n) + double(n)\nprint(twice(5))",
				hints: [
					"return n * 2",
					"twice returns double(n) + double(n)",
					"print(twice(5))"
				]
			}
		}]
	},
	{
		id: 47,
		title: "Studio Report",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "A function reads a roster and writes one labeled line.",
		objective: "Write line(name, score) and print two reports.",
		rewardCoins: 5200,
		rewardXp: 2100,
		unlockRewardId: "studio-report",
		unlockReward: "Studio Report",
		careerUnlock: "grandmaster",
		chapter: "studio",
		steps: [{
			type: "brief",
			title: "One shape, many calls",
			body: "line(name, score) returns name + \": \" + str(score). Convert the number. Call it twice to print two people.",
			example: "def line(name, score):\n    return name + \": \" + str(score)"
		}, {
			type: "code",
			challenge: {
				id: "l47-line",
				title: "Two badges",
				concept: "format helper",
				prompt: "Write line(name, score) that returns name, then \": \", then the score as text. Print line(\"Ada\", 90) and line(\"Kai\", 70).",
				briefing: "Two lines of output. Space after the colon.",
				example: "print(line(\"Ada\", 90))",
				starter: "def line(name, score):\n    return name\n",
				expected: "Ada: 90\nKai: 70\n",
				solution: "def line(name, score):\n    return name + \": \" + str(score)\nprint(line(\"Ada\", 90))\nprint(line(\"Kai\", 70))",
				hints: [
					"str(score)",
					"\": \" has a colon and a space",
					"Print both calls."
				]
			}
		}]
	},
	{
		id: 48,
		title: "Even Filter",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "Walk a list. Print only the even numbers.",
		objective: "Filter with % before the clock hits zero.",
		rewardCoins: 5400,
		rewardXp: 2200,
		unlockRewardId: "even-filter",
		unlockReward: "Even Filter",
		careerUnlock: "grandmaster",
		chapter: "studio",
		timeLimitSec: 80,
		steps: [{
			type: "brief",
			title: "Keep the evens",
			body: "for n in nums: if n % 2 == 0: print(n). Indent twice. Odds are skipped, not deleted.",
			example: "for n in nums:\n    if n % 2 == 0:\n        print(n)"
		}, {
			type: "code",
			challenge: {
				id: "l48-even",
				title: "Evens only",
				concept: "filter loop",
				prompt: "nums is [1, 4, 7, 8, 3, 10]. Print only the even numbers, each on its own line, in order.",
				briefing: "4, 8, 10.",
				example: "for n in nums:\n    if n % 2 == 0:\n        print(n)",
				starter: "nums = [1, 4, 7, 8, 3, 10]\n",
				expected: "4\n8\n10\n",
				solution: "nums = [1, 4, 7, 8, 3, 10]\nfor n in nums:\n    if n % 2 == 0:\n        print(n)",
				hints: [
					"for n in nums:",
					"if n % 2 == 0:",
					"print(n)"
				]
			}
		}]
	},
	{
		id: 49,
		title: "Default Key",
		job: "Grandmaster",
		difficulty: "Hard",
		description: "get(key, fallback) returns the fallback instead of crashing.",
		objective: "Look up a missing city with a default.",
		rewardCoins: 5600,
		rewardXp: 2300,
		unlockRewardId: "default-key",
		unlockReward: "Default Key",
		careerUnlock: "grandmaster",
		chapter: "studio",
		steps: [{
			type: "brief",
			title: "The second argument",
			body: "user.get(\"city\", \"unknown\") returns unknown when city is missing. user[\"city\"] would raise KeyError. Use get when the key might not exist.",
			example: "print(user.get(\"city\", \"unknown\"))"
		}, {
			type: "code",
			challenge: {
				id: "l49-get",
				title: "Fallback city",
				concept: "get default",
				prompt: "user has a name but no city. Print user.get(\"city\", \"unknown\"), then print user.get(\"name\", \"unknown\").",
				briefing: "Missing city → unknown. Present name → Ada.",
				example: "print(user.get(\"city\", \"unknown\"))",
				starter: "user = {\"name\": \"Ada\"}\n",
				expected: "unknown\nAda\n",
				solution: "user = {\"name\": \"Ada\"}\nprint(user.get(\"city\", \"unknown\"))\nprint(user.get(\"name\", \"unknown\"))",
				hints: [
					"get(\"city\", \"unknown\")",
					"get(\"name\", \"unknown\")",
					"Two prints."
				]
			}
		}]
	},
	{
		id: 50,
		title: "Grandmaster Championship",
		job: "Grandmaster",
		difficulty: "Expert",
		description: "Final championship. Helpers, filters, nested records, and a written report — under the clock.",
		objective: "Clear every stage. Claim the Grandmaster Crown.",
		rewardCoins: 12e3,
		rewardXp: 4e3,
		unlockRewardId: "grandmaster-crown",
		unlockReward: "Grandmaster Crown",
		careerUnlock: "grandmaster",
		chapter: "studio",
		timeLimitSec: 200,
		championship: true,
		finale: true,
		steps: [
			{
				type: "brief",
				title: "The whole career",
				body: "Stage 1: a helper that classifies. Stage 2: walk nested scores. Stage 3: write a labeled report from a list. Same laws: colons, indents, quotes, print.",
				example: "def stamp(n):\n    if n % 2 == 0:\n        return \"EVEN\"\n    return \"ODD\""
			},
			{
				type: "code",
				challenge: {
					id: "l50-stamp",
					title: "Stage 1 — Stamp",
					concept: "function + %",
					prompt: "Write stamp(n) that returns EVEN if n is even, else ODD. Print stamp(8) then stamp(7).",
					briefing: "Two lines: EVEN then ODD.",
					example: "print(stamp(8))\nprint(stamp(7))",
					starter: "def stamp(n):\n    return n\n",
					expected: "EVEN\nODD\n",
					solution: "def stamp(n):\n    if n % 2 == 0:\n        return \"EVEN\"\n    return \"ODD\"\nprint(stamp(8))\nprint(stamp(7))",
					hints: [
						"if n % 2 == 0: return \"EVEN\"",
						"return \"ODD\"",
						"Print both calls."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l50-nested",
					title: "Stage 2 — Nested scores",
					concept: "nested dict + if",
					prompt: "desk maps names to records with a score. Print each name whose score is at least 80, in dictionary order.",
					briefing: "Ada 90 and Kai 88 pass. Lin 70 does not. Read desk[name][\"score\"].",
					example: "for name in desk:\n    if desk[name][\"score\"] >= 80:\n        print(name)",
					starter: "desk = {\"Ada\": {\"score\": 90}, \"Lin\": {\"score\": 70}, \"Kai\": {\"score\": 88}}\n",
					expected: "Ada\nKai\n",
					solution: "desk = {\"Ada\": {\"score\": 90}, \"Lin\": {\"score\": 70}, \"Kai\": {\"score\": 88}}\nfor name in desk:\n    if desk[name][\"score\"] >= 80:\n        print(name)",
					hints: [
						"for name in desk:",
						"if desk[name][\"score\"] >= 80:",
						"print(name)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l50-report",
					title: "Stage 3 — Final report",
					concept: "helpers + builtins",
					prompt: "Write report(nums) that returns max= then the max, then a space, then even= then how many even numbers. Print report([1, 4, 8, 3]).",
					briefing: "max is 8. Evens are 4 and 8, so even=2. Shape: max=8 even=2",
					example: "return \"max=\" + str(max(nums)) + \" even=\" + str(c)",
					starter: "def report(nums):\n    return \"\"\n",
					expected: "max=8 even=2\n",
					solution: "def report(nums):\n    c = 0\n    for n in nums:\n        if n % 2 == 0:\n            c += 1\n    return \"max=\" + str(max(nums)) + \" even=\" + str(c)\nprint(report([1, 4, 8, 3]))",
					hints: [
						"Count evens with % 2 == 0",
						"str(max(nums)) and str(c)",
						"print(report([1, 4, 8, 3]))"
					]
				}
			}
		]
	}
];
var LEVELS = [...[
	{
		id: 1,
		title: "Rookie Orientation",
		job: "Trainee",
		difficulty: "Easy",
		description: "Learn how a mission works, then write your first Python line.",
		objective: "Wait for the signal, then print a greeting.",
		rewardCoins: 500,
		rewardXp: 100,
		unlockRewardId: "trainee-badge",
		unlockReward: "Trainee Badge",
		careerUnlock: "trainee",
		chapter: "foundations",
		steps: [
			{
				type: "brief",
				title: "How missions work",
				body: "Each mission has a goal, a Python briefing, and a reward. Follow the steps. If your code is wrong, Jarvis explains the mistake and the fix — not just “error”."
			},
			{
				type: "reaction",
				title: "Step 1 — Wait for the signal",
				body: "Stay ready. When GO appears, tap the action button. Too early fails the check."
			},
			{
				type: "brief",
				title: "Step 2 — Python talks with print()",
				body: "print() is a function. A function is a tool you call with parentheses. The text inside quotes is a string — characters Python should treat as words, not as a name.",
				example: "print(\"Hello\")\n# The screen shows: Hello"
			},
			{
				type: "code",
				challenge: {
					id: "l1-hello",
					title: "Step 3 — Your first program",
					concept: "print() and strings",
					prompt: "Print exactly this greeting, including the comma and capital letters:",
					briefing: "Quotes wrap the message so Python does not look for a variable named Hello. print() then shows the message. The quotes themselves do not appear on the screen.",
					example: "print(\"Hello, Jarvis\")",
					starter: "# Type your line below.\n",
					expected: "Hello, Jarvis\n",
					solution: "print(\"Hello, Jarvis\")",
					hints: [
						"Use print( ) with parentheses.",
						"Put Hello, Jarvis inside quotes.",
						"Match capitals: Hello, Jarvis"
					]
				}
			}
		]
	},
	{
		id: 2,
		title: "First Assignment",
		job: "Junior Associate",
		difficulty: "Easy / Medium",
		description: "Choose the valid Python, then store values in variables.",
		objective: "Pass the decision cards and print a calculated result.",
		rewardCoins: 900,
		rewardXp: 150,
		unlockRewardId: "junior-desk",
		unlockReward: "Junior Desk",
		careerUnlock: "junior",
		chapter: "foundations",
		steps: [
			{
				type: "brief",
				title: "Variables store values",
				body: "A variable is a labeled box. name = \"Ada\" puts the string Ada in the box called name. After that, print(name) shows Ada — no quotes — because you printed the box, not the word name.",
				example: "name = \"Ada\"\nprint(name)\n# Ada"
			},
			{
				type: "choice",
				concept: "Assignment vs text",
				question: "Which line correctly stores the text Ada in a variable?",
				options: [
					{
						id: "a",
						label: "name = Ada",
						correct: false,
						explain: "Ada without quotes is treated as another variable. Python will look for a box named Ada and fail."
					},
					{
						id: "b",
						label: "name = \"Ada\"",
						correct: true,
						explain: "Quotes make Ada a string. The box name now holds that text."
					},
					{
						id: "c",
						label: "name == \"Ada\"",
						correct: false,
						explain: "== asks a yes/no question. It does not store anything. = stores. == compares."
					}
				]
			},
			{
				type: "choice",
				concept: "What print shows",
				question: "What does print(3 + 2) show?",
				options: [
					{
						id: "a",
						label: "3 + 2",
						correct: false,
						explain: "Without quotes, 3 + 2 is math. Python adds first, then prints the result."
					},
					{
						id: "b",
						label: "5",
						correct: true,
						explain: "Numbers without quotes are numbers. + adds them. print shows 5."
					},
					{
						id: "c",
						label: "\"32\"",
						correct: false,
						explain: "Sticking 3 and 2 together happens with strings: print(\"3\" + \"2\") would show 32."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l2-vars",
					title: "Store and print",
					concept: "variables",
					prompt: "Create a variable called city with the text London, then print the variable (not the word in quotes).",
					briefing: "Assign with =. Print the name with no quotes around the name.",
					example: "city = \"London\"\nprint(city)",
					starter: "city = \"\"\n",
					expected: "London\n",
					solution: "city = \"London\"\nprint(city)",
					hints: [
						"Put London inside quotes on the right of =.",
						"Then print(city) — city has no quotes.",
						"If you print(\"city\") you will see the word city, not London."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l2-sum",
					title: "Payroll math",
					concept: "numbers",
					prompt: "base is 40. bonus is 15. Print the sum of base and bonus as a number.",
					briefing: "Numbers have no quotes. + adds them. print(base + bonus) calculates, then shows the result.",
					example: "print(40 + 15)",
					starter: "base = 40\nbonus = 15\n",
					expected: "55\n",
					solution: "base = 40\nbonus = 15\nprint(base + bonus)",
					hints: [
						"Do not quote the numbers.",
						"print(base + bonus)",
						"The screen should show 55 with no extra text."
					]
				}
			}
		]
	},
	{
		id: 3,
		title: "Speed Mission",
		job: "Specialist",
		difficulty: "Medium",
		description: "Write correct conditions before the clock hits zero.",
		objective: "Finish every task before time runs out.",
		rewardCoins: 1500,
		rewardXp: 250,
		unlockRewardId: "specialist-outfit",
		unlockReward: "Specialist Outfit",
		careerUnlock: "specialist",
		chapter: "foundations",
		timeLimitSec: 75,
		steps: [
			{
				type: "brief",
				title: "if / else decides",
				body: "An if line asks a yes/no question. If the answer is True, Python runs the indented block. else runs when the answer is False. The if line must end with a colon, and the next line must be indented.",
				example: "if score >= 70:\n    print(\"PASS\")\nelse:\n    print(\"RETRY\")"
			},
			{
				type: "code",
				challenge: {
					id: "l3-if",
					title: "Gate check",
					concept: "if / else",
					prompt: "score is 82. If score is at least 70, print PASS. Otherwise print RETRY.",
					briefing: ">= means greater than or equal. PASS and RETRY are strings — wrap them in quotes. Indent the print lines.",
					example: "if score >= 70:\n    print(\"PASS\")",
					starter: "score = 82\n",
					expected: "PASS\n",
					solution: "score = 82\nif score >= 70:\n    print(\"PASS\")\nelse:\n    print(\"RETRY\")",
					hints: [
						"End the if line with a colon.",
						"Indent print with 4 spaces.",
						"print(\"PASS\") with quotes."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l3-compare",
					title: "True or False",
					concept: "comparisons",
					prompt: "Print the result of checking whether 9 is less than 4. It should print False.",
					briefing: "Comparisons produce True or False. print(9 < 4) shows False because 9 is not less than 4. Do not quote True/False — they are boolean values, not text.",
					example: "print(9 < 4)",
					starter: "",
					expected: "False\n",
					solution: "print(9 < 4)",
					hints: [
						"Use the < operator.",
						"print(9 < 4)",
						"False has a capital F — Python will print that if you compare correctly."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l3-branch",
					title: "Access level",
					concept: "if / else",
					prompt: "role is guest. If role equals admin, print OPEN. Otherwise print LOCKED.",
					briefing: "== compares two values. Strings must match exactly. guest is not admin, so the else branch should run.",
					example: "if role == \"admin\":\n    print(\"OPEN\")\nelse:\n    print(\"LOCKED\")",
					starter: "role = \"guest\"\n",
					expected: "LOCKED\n",
					solution: "role = \"guest\"\nif role == \"admin\":\n    print(\"OPEN\")\nelse:\n    print(\"LOCKED\")",
					hints: [
						"Compare with == not =.",
						"else: then indented print(\"LOCKED\")",
						"guest is not admin, so LOCKED is correct."
					]
				}
			}
		]
	},
	{
		id: 4,
		title: "Executive Trial",
		job: "Manager",
		difficulty: "Hard",
		description: "Complete three list-and-loop objectives in order.",
		objective: "Build a list, walk it, then report its size.",
		rewardCoins: 2500,
		rewardXp: 400,
		unlockRewardId: "executive-office",
		unlockReward: "Executive Office",
		careerUnlock: "manager",
		chapter: "foundations",
		steps: [
			{
				type: "brief",
				title: "Lists and for-loops",
				body: "A list holds several values in order, inside square brackets. for item in list: runs the indented block once per value. len(list) counts how many items. Indexes start at 0 — the first item is items[0].",
				example: "items = [\"plan\", \"code\", \"test\"]\nfor item in items:\n    print(item)"
			},
			{
				type: "code",
				challenge: {
					id: "l4-list",
					title: "Objective 1 — The roster",
					concept: "lists",
					prompt: "Create a list called team with three strings: Ada, Lin, Kai. Print the list.",
					briefing: "Strings in a list still need quotes. print(team) shows the whole list with brackets and quotes — that is normal.",
					example: "team = [\"Ada\", \"Lin\", \"Kai\"]\nprint(team)",
					starter: "team = []\n",
					expected: "['Ada', 'Lin', 'Kai']\n",
					solution: "team = [\"Ada\", \"Lin\", \"Kai\"]\nprint(team)",
					hints: [
						"Three quoted names inside [ ].",
						"Separate them with commas.",
						"print(team) after you build it."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l4-loop",
					title: "Objective 2 — Walk the list",
					concept: "for loops",
					prompt: "Loop through tasks and print each item on its own line.",
					briefing: "for t in tasks: then indent print(t). The loop variable t becomes each item in turn. Do not print the whole list.",
					example: "for t in tasks:\n    print(t)",
					starter: "tasks = [\"plan\", \"code\", \"test\"]\n",
					expected: "plan\ncode\ntest\n",
					solution: "tasks = [\"plan\", \"code\", \"test\"]\nfor t in tasks:\n    print(t)",
					hints: [
						"for t in tasks:",
						"Indent print(t) with 4 spaces.",
						"You should see three lines, one word each."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l4-len",
					title: "Objective 3 — Headcount",
					concept: "len()",
					prompt: "Print how many items are in rooms using len().",
					briefing: "len(rooms) returns a number. print(len(rooms)) shows that number. Do not write 3 by hand — use len so the answer stays correct if the list changes.",
					example: "print(len(rooms))",
					starter: "rooms = [\"ops\", \"lab\", \"brief\", \"vault\"]\n",
					expected: "4\n",
					solution: "rooms = [\"ops\", \"lab\", \"brief\", \"vault\"]\nprint(len(rooms))",
					hints: [
						"len(rooms) counts items.",
						"print(len(rooms))",
						"The answer is 4."
					]
				}
			}
		]
	},
	{
		id: 5,
		title: "Elite Championship",
		job: "Elite Professional",
		difficulty: "Hard",
		description: "Combine functions, loops, and conditions. Championship scoring is live.",
		objective: "Clear every stage before time expires.",
		rewardCoins: 5e3,
		rewardXp: 750,
		unlockRewardId: "m8-apex",
		unlockReward: "M8 Apex",
		careerUnlock: "elite",
		chapter: "foundations",
		timeLimitSec: 120,
		championship: true,
		steps: [
			{
				type: "brief",
				title: "Functions package skill",
				body: "def name(args): creates a reusable tool. return sends a value back to the caller. print(greet(\"Elite\")) first runs greet, then prints whatever greet returned.",
				example: "def greet(name):\n    return \"Ready, \" + name\nprint(greet(\"Elite\"))"
			},
			{
				type: "code",
				challenge: {
					id: "l5-fn",
					title: "Stage 1 — Briefing call",
					concept: "functions + return",
					prompt: "Write greet(name) so it returns Ready, plus a space, plus name. Then print greet(\"Elite\").",
					briefing: "return does not print. print is separate. Join strings with +.",
					example: "def greet(name):\n    return \"Ready, \" + name",
					starter: "def greet(name):\n    return name\n",
					expected: "Ready, Elite\n",
					solution: "def greet(name):\n    return \"Ready, \" + name\nprint(greet(\"Elite\"))",
					hints: [
						"return \"Ready, \" + name",
						"Remember the comma and space after Ready.",
						"Call print(greet(\"Elite\")) under the function."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l5-filter",
					title: "Stage 2 — Clearance filter",
					concept: "loop + if",
					prompt: "scores holds exam results. Print only the scores that are at least 70, each on its own line.",
					briefing: "Loop every score. Inside the loop, if score >= 70, print it. Indent twice: once for the for, once for the if.",
					example: "for s in scores:\n    if s >= 70:\n        print(s)",
					starter: "scores = [55, 90, 70, 41, 88]\n",
					expected: "90\n70\n88\n",
					solution: "scores = [55, 90, 70, 41, 88]\nfor s in scores:\n    if s >= 70:\n        print(s)",
					hints: [
						"for s in scores:",
						"if s >= 70:",
						"print(s) indented under the if."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l5-total",
					title: "Stage 3 — Final tally",
					concept: "functions + loops",
					prompt: "Write total(nums) that adds every number in the list and returns the sum. Print total([10, 20, 30]).",
					briefing: "Start a box at 0. Loop, add each number, return the box. You may also use sum(nums).",
					example: "def total(nums):\n    s = 0\n    for n in nums:\n        s += n\n    return s",
					starter: "def total(nums):\n    return 0\n",
					expected: "60\n",
					solution: "def total(nums):\n    s = 0\n    for n in nums:\n        s += n\n    return s\nprint(total([10, 20, 30]))",
					hints: [
						"s = 0 then for n in nums: s += n",
						"return s",
						"print(total([10, 20, 30]))"
					]
				}
			}
		]
	},
	{
		id: 6,
		title: "String Lab",
		job: "Senior Engineer",
		difficulty: "Easy / Medium",
		description: "Join text together. Turn numbers into text with str().",
		objective: "Concatenate names, then build a labeled desk number.",
		rewardCoins: 1100,
		rewardXp: 300,
		unlockRewardId: "string-keys",
		unlockReward: "String Keys",
		careerUnlock: "elite",
		chapter: "strings",
		steps: [
			{
				type: "brief",
				title: "Strings glue with +",
				body: "+ on two strings pastes them. It does not add a space unless you put one in. Numbers cannot join text until you wrap them in str().",
				example: "print(\"Ada\" + \" \" + \"Lovelace\")\nprint(\"Desk \" + str(7))"
			},
			{
				type: "choice",
				concept: "str() vs quotes",
				question: "How do you turn the number 7 into the text \"7\"?",
				options: [
					{
						id: "a",
						label: "int(7)",
						correct: false,
						explain: "int() turns values into numbers. 7 is already a number."
					},
					{
						id: "b",
						label: "str(7)",
						correct: true,
						explain: "str() makes a string from a number so it can join other text."
					},
					{
						id: "c",
						label: "print(7)",
						correct: false,
						explain: "print shows 7 on the screen, but the value is still a number — you cannot add it to a string."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l6-concat",
					title: "Nameplate",
					concept: "string +",
					prompt: "first is Ada. last is Lovelace. Print the full name with one space in the middle.",
					briefing: "Join with +. Put a space string between the two names.",
					example: "print(first + \" \" + last)",
					starter: "first = \"Ada\"\nlast = \"Lovelace\"\n",
					expected: "Ada Lovelace\n",
					solution: "first = \"Ada\"\nlast = \"Lovelace\"\nprint(first + \" \" + last)",
					hints: [
						"Use + between the pieces.",
						"The space is its own string: \" \"",
						"print(first + \" \" + last)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l6-str",
					title: "Desk label",
					concept: "str()",
					prompt: "n is 7. Print Desk 7 using the variable n — do not type the digit 7 inside the string.",
					briefing: "Python refuses \"Desk \" + n because one side is text and the other is a number. Convert with str(n).",
					example: "print(\"Desk \" + str(n))",
					starter: "n = 7\n",
					expected: "Desk 7\n",
					solution: "n = 7\nprint(\"Desk \" + str(n))",
					hints: [
						"str(n) turns 7 into \"7\".",
						"\"Desk \" has a trailing space.",
						"print(\"Desk \" + str(n))"
					]
				}
			}
		]
	},
	{
		id: 7,
		title: "Case File",
		job: "Senior Engineer",
		difficulty: "Easy / Medium",
		description: "Change letter case and trim leftover spaces.",
		objective: "Use upper, lower, and strip.",
		rewardCoins: 1200,
		rewardXp: 350,
		unlockRewardId: "case-file",
		unlockReward: "Case File",
		careerUnlock: "senior",
		chapter: "strings",
		steps: [
			{
				type: "brief",
				title: "Methods sit after a dot",
				body: "text.upper() is a method — a function that belongs to a value. The empty () still matter. Forgetting them is a common miss. strip() removes spaces from both ends, not from the middle.",
				example: "print(\"jarvis\".upper())\nprint(\"  Ada  \".strip())"
			},
			{
				type: "choice",
				concept: "methods need ()",
				question: "What does print(\"Hi\".lower()) show?",
				options: [
					{
						id: "a",
						label: "Hi",
						correct: false,
						explain: "lower() changes every letter. H becomes h."
					},
					{
						id: "b",
						label: "hi",
						correct: true,
						explain: "lower() returns a new string with all lowercase letters."
					},
					{
						id: "c",
						label: "HI",
						correct: false,
						explain: "That would be upper(), the opposite method."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l7-upper",
					title: "Loud callsign",
					concept: "upper()",
					prompt: "Print jarvis in all capitals using a string method.",
					briefing: "Call upper on the string. Parentheses are required.",
					example: "print(\"jarvis\".upper())",
					starter: "",
					expected: "JARVIS\n",
					solution: "print(\"jarvis\".upper())",
					hints: [
						"\"jarvis\".upper()",
						"Do not forget ().",
						"Wrap the call in print."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l7-strip",
					title: "Clean badge",
					concept: "strip()",
					prompt: "name has extra spaces. Print the cleaned name with no leading or trailing spaces.",
					briefing: "strip() returns a new string. It does not change name unless you assign it.",
					example: "print(name.strip())",
					starter: "name = \"  Ada  \"\n",
					expected: "Ada\n",
					solution: "name = \"  Ada  \"\nprint(name.strip())",
					hints: [
						"name.strip()",
						"Print the result of strip, not name itself.",
						"The output is Ada with no spaces."
					]
				}
			}
		]
	},
	{
		id: 8,
		title: "Character Lens",
		job: "Staff Engineer",
		difficulty: "Medium",
		description: "Read one character at a time. Indexes start at zero.",
		objective: "Print the first letter, the last letter, and a string length.",
		rewardCoins: 1300,
		rewardXp: 400,
		unlockRewardId: "char-lens",
		unlockReward: "Character Lens",
		careerUnlock: "senior",
		chapter: "strings",
		steps: [
			{
				type: "brief",
				title: "Indexes start at 0",
				body: "word[0] is the first character. word[-1] is the last. len(word) counts characters, including spaces.",
				example: "word = \"Python\"\nprint(word[0])  # P\nprint(word[-1]) # n"
			},
			{
				type: "choice",
				concept: "zero-based index",
				question: "In the string \"code\", which index is the letter d?",
				options: [
					{
						id: "a",
						label: "1",
						correct: false,
						explain: "Index 1 is o. Counting starts at 0: c=0, o=1, d=2, e=3."
					},
					{
						id: "b",
						label: "2",
						correct: true,
						explain: "c=0, o=1, d=2. The third letter lives at index 2."
					},
					{
						id: "c",
						label: "3",
						correct: false,
						explain: "Index 3 is e, the last letter."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l8-first-last",
					title: "Bookends",
					concept: "string index",
					prompt: "word is Python. Print the first character, then the last character, each on its own line.",
					briefing: "Use [0] and [-1]. Each print makes a new line.",
					example: "print(word[0])\nprint(word[-1])",
					starter: "word = \"Python\"\n",
					expected: "P\nn\n",
					solution: "word = \"Python\"\nprint(word[0])\nprint(word[-1])",
					hints: [
						"First letter: word[0]",
						"Last letter: word[-1]",
						"Two print calls."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l8-len",
					title: "Letter count",
					concept: "len(str)",
					prompt: "Print how many characters are in the string career using len().",
					briefing: "len works on strings the same way it works on lists.",
					example: "print(len(\"career\"))",
					starter: "",
					expected: "6\n",
					solution: "print(len(\"career\"))",
					hints: [
						"len(\"career\")",
						"Wrap it in print.",
						"The answer is 6."
					]
				}
			}
		]
	},
	{
		id: 9,
		title: "Logic Core",
		job: "Staff Engineer",
		difficulty: "Medium",
		description: "Combine True and False with and, or, and not.",
		objective: "Print boolean results from comparisons and logic.",
		rewardCoins: 1400,
		rewardXp: 450,
		unlockRewardId: "logic-core",
		unlockReward: "Logic Core",
		careerUnlock: "staff",
		chapter: "logic",
		steps: [
			{
				type: "brief",
				title: "and / or / not",
				body: "and is True only if both sides are True. or is True if at least one side is True. not flips True to False. Comparisons like >= produce booleans you can combine.",
				example: "print(True and False)  # False\nprint(age >= 18 and age < 65)"
			},
			{
				type: "choice",
				concept: "not",
				question: "What does print(not True) show?",
				options: [
					{
						id: "a",
						label: "True",
						correct: false,
						explain: "not flips the value. The opposite of True is False."
					},
					{
						id: "b",
						label: "False",
						correct: true,
						explain: "not True is False. not False is True."
					},
					{
						id: "c",
						label: "not True",
						correct: false,
						explain: "Python evaluates the expression, then prints the boolean result."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l9-and",
					title: "Both gates",
					concept: "and",
					prompt: "Print the result of True and False.",
					briefing: "Do not quote True or False. They are keywords.",
					example: "print(True and False)",
					starter: "",
					expected: "False\n",
					solution: "print(True and False)",
					hints: [
						"True and False — no quotes.",
						"and needs both sides True to be True.",
						"The output is False."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l9-range",
					title: "Working age",
					concept: "combined compare",
					prompt: "age is 20. Print whether age is at least 18 and also less than 65.",
					briefing: "Chain with and. Python will print True or False.",
					example: "print(age >= 18 and age < 65)",
					starter: "age = 20\n",
					expected: "True\n",
					solution: "age = 20\nprint(age >= 18 and age < 65)",
					hints: [
						"age >= 18",
						"and age < 65",
						"Print the whole comparison."
					]
				}
			}
		]
	},
	{
		id: 10,
		title: "Branch Map",
		job: "Lead Engineer",
		difficulty: "Medium / Hard",
		description: "elif picks the first matching branch. The clock is live.",
		objective: "Grade a score and classify a temperature before time runs out.",
		rewardCoins: 1600,
		rewardXp: 500,
		unlockRewardId: "branch-map",
		unlockReward: "Branch Map",
		careerUnlock: "staff",
		chapter: "logic",
		timeLimitSec: 90,
		steps: [
			{
				type: "brief",
				title: "elif is the next door",
				body: "Python checks if, then each elif, then else. The first True branch runs. Later branches are skipped even if they would also be True. Order matters.",
				example: "if score >= 90:\n    print(\"A\")\nelif score >= 70:\n    print(\"B\")\nelse:\n    print(\"C\")"
			},
			{
				type: "code",
				challenge: {
					id: "l10-grade",
					title: "Letter grade",
					concept: "elif",
					prompt: "score is 91. If it is at least 90 print A. Else if it is at least 70 print B. Otherwise print C.",
					briefing: "91 matches the first branch. Put colons on every header. Indent each print.",
					example: "if score >= 90:\n    print(\"A\")",
					starter: "score = 91\n",
					expected: "A\n",
					solution: "score = 91\nif score >= 90:\n    print(\"A\")\nelif score >= 70:\n    print(\"B\")\nelse:\n    print(\"C\")",
					hints: [
						"if score >= 90:",
						"elif score >= 70:",
						"else: print(\"C\")"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l10-temp",
					title: "Climate check",
					concept: "elif",
					prompt: "temp is 12. If temp is under 10 print COLD. Else if temp is under 25 print OK. Otherwise print HOT.",
					briefing: "12 is not < 10, but it is < 25, so OK.",
					example: "if temp < 10:\n    print(\"COLD\")",
					starter: "temp = 12\n",
					expected: "OK\n",
					solution: "temp = 12\nif temp < 10:\n    print(\"COLD\")\nelif temp < 25:\n    print(\"OK\")\nelse:\n    print(\"HOT\")",
					hints: [
						"if temp < 10:",
						"elif temp < 25:",
						"12 is OK, not COLD."
					]
				}
			}
		]
	},
	{
		id: 11,
		title: "While Engine",
		job: "Lead Engineer",
		difficulty: "Medium",
		description: "A while loop repeats until its condition becomes False.",
		objective: "Count up, then count down. Always change the loop variable.",
		rewardCoins: 1700,
		rewardXp: 550,
		unlockRewardId: "while-engine",
		unlockReward: "While Engine",
		careerUnlock: "lead",
		chapter: "loops",
		steps: [
			{
				type: "brief",
				title: "while needs an exit",
				body: "while condition: repeats the indented block as long as the condition is True. If you forget to change the variable, the loop never ends — Jarvis will stop it and tell you.",
				example: "i = 1\nwhile i <= 3:\n    print(i)\n    i += 1"
			},
			{
				type: "choice",
				concept: "infinite loops",
				question: "Why must you change i inside while i <= 3?",
				options: [
					{
						id: "a",
						label: "So the condition eventually becomes False",
						correct: true,
						explain: "If i stays 1 forever, i <= 3 stays True and the loop never stops."
					},
					{
						id: "b",
						label: "Python requires += on every line",
						correct: false,
						explain: "+= is just one way to change a number. The requirement is that the condition can become False."
					},
					{
						id: "c",
						label: "print() only works after +=",
						correct: false,
						explain: "print works any time. The increment is about ending the loop, not about printing."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l11-up",
					title: "Count up",
					concept: "while",
					prompt: "Start i at 1. While i is at most 3, print i, then add 1.",
					briefing: "The increment belongs inside the loop, indented.",
					example: "while i <= 3:\n    print(i)\n    i += 1",
					starter: "i = 1\n",
					expected: "1\n2\n3\n",
					solution: "i = 1\nwhile i <= 3:\n    print(i)\n    i += 1",
					hints: [
						"while i <= 3:",
						"print(i) then i += 1",
						"Both lines indented."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l11-down",
					title: "Countdown",
					concept: "while",
					prompt: "n starts at 5. While n is greater than 0, print n, then subtract 1.",
					briefing: "n -= 1 is the same as n = n - 1. Stop when n is 0 so 0 is not printed.",
					example: "while n > 0:\n    print(n)\n    n -= 1",
					starter: "n = 5\n",
					expected: "5\n4\n3\n2\n1\n",
					solution: "n = 5\nwhile n > 0:\n    print(n)\n    n -= 1",
					hints: [
						"while n > 0:",
						"print(n)",
						"n -= 1"
					]
				}
			}
		]
	},
	{
		id: 12,
		title: "Range Rail",
		job: "Principal Engineer",
		difficulty: "Medium",
		description: "range() builds the numbers a for-loop walks.",
		objective: "Print range(4) and range(2, 6).",
		rewardCoins: 1800,
		rewardXp: 600,
		unlockRewardId: "range-rail",
		unlockReward: "Range Rail",
		careerUnlock: "lead",
		chapter: "loops",
		steps: [
			{
				type: "brief",
				title: "range stops before the end",
				body: "range(4) is 0, 1, 2, 3 — it does not include 4. range(2, 6) starts at 2 and stops before 6. You almost always use range inside a for loop.",
				example: "for i in range(4):\n    print(i)"
			},
			{
				type: "choice",
				concept: "range stop",
				question: "Which numbers does range(3) produce?",
				options: [
					{
						id: "a",
						label: "1, 2, 3",
						correct: false,
						explain: "range starts at 0 unless you say otherwise. It never includes the stop value."
					},
					{
						id: "b",
						label: "0, 1, 2",
						correct: true,
						explain: "Start 0, stop before 3."
					},
					{
						id: "c",
						label: "0, 1, 2, 3",
						correct: false,
						explain: "That would be range(4). The 3 is the stop, not a value."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l12-range",
					title: "Zero to three",
					concept: "range",
					prompt: "Loop with range(4) and print each number on its own line.",
					briefing: "for i in range(4): then print(i).",
					example: "for i in range(4):\n    print(i)",
					starter: "",
					expected: "0\n1\n2\n3\n",
					solution: "for i in range(4):\n    print(i)",
					hints: [
						"for i in range(4):",
						"Indent print(i).",
						"Four lines: 0 through 3."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l12-span",
					title: "Two to five",
					concept: "range(start, stop)",
					prompt: "Print every integer from 2 up to but not including 6.",
					briefing: "range(2, 6) does that in one call.",
					example: "for i in range(2, 6):\n    print(i)",
					starter: "",
					expected: "2\n3\n4\n5\n",
					solution: "for i in range(2, 6):\n    print(i)",
					hints: [
						"range(2, 6)",
						"Stop is 6, last printed is 5.",
						"for i in range(2, 6): print(i)"
					]
				}
			}
		]
	},
	{
		id: 13,
		title: "Nest Grid",
		job: "Principal Engineer",
		difficulty: "Hard",
		description: "A loop inside a loop. The inner one finishes every time the outer ticks.",
		objective: "Print a multiplication grid before the timer ends.",
		rewardCoins: 2e3,
		rewardXp: 650,
		unlockRewardId: "nest-grid",
		unlockReward: "Nest Grid",
		careerUnlock: "principal",
		chapter: "loops",
		timeLimitSec: 80,
		steps: [
			{
				type: "brief",
				title: "Inner loop runs fully",
				body: "For each value of x, y walks its whole list. Four prints from two lists of two. Indent the inner for one extra level.",
				example: "for x in [1, 2]:\n    for y in [3, 4]:\n        print(x * y)"
			},
			{
				type: "code",
				challenge: {
					id: "l13-grid",
					title: "Product grid",
					concept: "nested for",
					prompt: "x walks [1, 2]. For each x, y walks [3, 4]. Print x * y each time.",
					briefing: "Four lines: 3, 4, then 6, 8.",
					example: "for x in [1, 2]:\n    for y in [3, 4]:\n        print(x * y)",
					starter: "",
					expected: "3\n4\n6\n8\n",
					solution: "for x in [1, 2]:\n    for y in [3, 4]:\n        print(x * y)",
					hints: [
						"for x in [1, 2]:",
						"    for y in [3, 4]:",
						"        print(x * y)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l13-filter",
					title: "High water",
					concept: "for + if",
					prompt: "nums is [3, 10, 7, 2]. Print only the numbers greater than 5, each on its own line.",
					briefing: "Loop, then if n > 5: print(n).",
					example: "for n in nums:\n    if n > 5:\n        print(n)",
					starter: "nums = [3, 10, 7, 2]\n",
					expected: "10\n7\n",
					solution: "nums = [3, 10, 7, 2]\nfor n in nums:\n    if n > 5:\n        print(n)",
					hints: [
						"for n in nums:",
						"if n > 5:",
						"print(n) under the if."
					]
				}
			}
		]
	},
	{
		id: 14,
		title: "Index Desk",
		job: "Principal Engineer",
		difficulty: "Medium",
		description: "Read and replace a list item by position.",
		objective: "Print index 1, then overwrite index 0.",
		rewardCoins: 2100,
		rewardXp: 700,
		unlockRewardId: "index-badge",
		unlockReward: "Index Badge",
		careerUnlock: "principal",
		chapter: "structures",
		steps: [
			{
				type: "brief",
				title: "Replace, don't append",
				body: "nums[1] reads the second item. nums[0] = 99 replaces the first. You can only assign to an index that already exists — use append to grow the list.",
				example: "nums = [10, 20, 30]\nprint(nums[1])\nnums[0] = 99"
			},
			{
				type: "code",
				challenge: {
					id: "l14-read",
					title: "Second seat",
					concept: "list index",
					prompt: "nums is [10, 20, 30]. Print the item at index 1.",
					briefing: "Index 1 is the second value because counting starts at 0.",
					example: "print(nums[1])",
					starter: "nums = [10, 20, 30]\n",
					expected: "20\n",
					solution: "nums = [10, 20, 30]\nprint(nums[1])",
					hints: [
						"nums[1]",
						"That is 20, not 10.",
						"print(nums[1])"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l14-write",
					title: "Overwrite",
					concept: "item assignment",
					prompt: "Set the first item of nums to 99, then print the whole list.",
					briefing: "nums[0] = 99 mutates the list in place.",
					example: "nums[0] = 99\nprint(nums)",
					starter: "nums = [10, 20, 30]\n",
					expected: "[99, 20, 30]\n",
					solution: "nums = [10, 20, 30]\nnums[0] = 99\nprint(nums)",
					hints: [
						"nums[0] = 99",
						"print(nums) after the assignment.",
						"Brackets in the output are normal."
					]
				}
			}
		]
	},
	{
		id: 15,
		title: "Append Bay",
		job: "Architect",
		difficulty: "Medium",
		description: "Grow a list with append. The method itself returns None.",
		objective: "Add a teammate, then count the box.",
		rewardCoins: 2200,
		rewardXp: 800,
		unlockRewardId: "append-bay",
		unlockReward: "Append Bay",
		careerUnlock: "principal",
		chapter: "structures",
		steps: [
			{
				type: "brief",
				title: "append mutates",
				body: "team.append(\"Lin\") adds Lin to the end. The call returns None — so print(team.append(\"Lin\")) would show None. Print the list after you append.",
				example: "team = [\"Ada\"]\nteam.append(\"Lin\")\nprint(team)"
			},
			{
				type: "choice",
				concept: "append return",
				question: "What does print(team.append(\"Lin\")) show?",
				options: [
					{
						id: "a",
						label: "Lin",
						correct: false,
						explain: "append does not return the new item. It returns None."
					},
					{
						id: "b",
						label: "None",
						correct: true,
						explain: "Most mutating list methods return None. Print the list afterwards if you want to see it."
					},
					{
						id: "c",
						label: "['Ada', 'Lin']",
						correct: false,
						explain: "That is what print(team) shows after append, not what append itself returns."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l15-append",
					title: "Hire Lin",
					concept: "append",
					prompt: "team starts as [\"Ada\"]. Append Lin, then print the list.",
					briefing: "Two steps: append, then print(team).",
					example: "team.append(\"Lin\")\nprint(team)",
					starter: "team = [\"Ada\"]\n",
					expected: "['Ada', 'Lin']\n",
					solution: "team = [\"Ada\"]\nteam.append(\"Lin\")\nprint(team)",
					hints: [
						"team.append(\"Lin\")",
						"Then print(team)",
						"Do not print the append call itself."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l15-grow",
					title: "Load the box",
					concept: "append + len",
					prompt: "box starts empty. Append 1, then append 2, then print how many items are in box.",
					briefing: "Two appends, then print(len(box)).",
					example: "box.append(1)\nbox.append(2)\nprint(len(box))",
					starter: "box = []\n",
					expected: "2\n",
					solution: "box = []\nbox.append(1)\nbox.append(2)\nprint(len(box))",
					hints: [
						"box.append(1)",
						"box.append(2)",
						"print(len(box))"
					]
				}
			}
		]
	},
	{
		id: 16,
		title: "Slice Glass",
		job: "Architect",
		difficulty: "Medium / Hard",
		description: "A slice is a window: start included, end excluded.",
		objective: "Slice a list and a string.",
		rewardCoins: 2300,
		rewardXp: 850,
		unlockRewardId: "slice-glass",
		unlockReward: "Slice Glass",
		careerUnlock: "architect",
		chapter: "structures",
		steps: [
			{
				type: "brief",
				title: "start:end",
				body: "items[1:3] takes indexes 1 and 2 — it stops before 3. Leaving the start empty means 0. Leaving the end empty means “to the last item”. Slicing a string returns a smaller string.",
				example: "letters = [\"a\", \"b\", \"c\", \"d\"]\nprint(letters[1:3])  # ['b', 'c']\nprint(\"Python\"[0:3])  # Pyt"
			},
			{
				type: "choice",
				concept: "half-open slice",
				question: "What does \"code\"[:2] produce?",
				options: [
					{
						id: "a",
						label: "cod",
						correct: false,
						explain: "[:2] is indexes 0 and 1, so co — it stops before 2."
					},
					{
						id: "b",
						label: "co",
						correct: true,
						explain: "Empty start means 0. End 2 is excluded. c=0, o=1."
					},
					{
						id: "c",
						label: "code",
						correct: false,
						explain: "That would be the whole string, slice [:] or [0:4]."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l16-list",
					title: "Middle pair",
					concept: "list slice",
					prompt: "letters is a, b, c, d. Print the slice from index 1 up to (not including) 3.",
					briefing: "letters[1:3] → b and c.",
					example: "print(letters[1:3])",
					starter: "letters = [\"a\", \"b\", \"c\", \"d\"]\n",
					expected: "['b', 'c']\n",
					solution: "letters = [\"a\", \"b\", \"c\", \"d\"]\nprint(letters[1:3])",
					hints: [
						"letters[1:3]",
						"End 3 is not included.",
						"print the slice."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l16-str",
					title: "Prefix",
					concept: "string slice",
					prompt: "Print the first three characters of Python using a slice.",
					briefing: "[0:3] on a string returns a string, not a list.",
					example: "print(\"Python\"[0:3])",
					starter: "",
					expected: "Pyt\n",
					solution: "print(\"Python\"[0:3])",
					hints: [
						"\"Python\"[0:3]",
						"P=0, y=1, t=2.",
						"Output is Pyt with no quotes."
					]
				}
			}
		]
	},
	{
		id: 17,
		title: "Break Seal",
		job: "Architect",
		difficulty: "Hard",
		description: "break leaves the loop. continue skips one round.",
		objective: "Stop at 9. Skip even numbers.",
		rewardCoins: 2400,
		rewardXp: 900,
		unlockRewardId: "break-seal",
		unlockReward: "Break Seal",
		careerUnlock: "architect",
		chapter: "structures",
		steps: [
			{
				type: "brief",
				title: "Two exits",
				body: "break jumps out of the nearest loop immediately. continue jumps to the next item and skips the rest of this round. % is remainder — n % 2 == 0 means n is even.",
				example: "for n in nums:\n    if n == 9:\n        break\n    print(n)"
			},
			{
				type: "code",
				challenge: {
					id: "l17-break",
					title: "Stop at nine",
					concept: "break",
					prompt: "Loop [1, 2, 9, 4]. Print each number, but break when you see 9 so 9 and 4 are not printed.",
					briefing: "Check for 9 first, then print. Order matters.",
					example: "if n == 9:\n    break\nprint(n)",
					starter: "",
					expected: "1\n2\n",
					solution: "for n in [1, 2, 9, 4]:\n    if n == 9:\n        break\n    print(n)",
					hints: [
						"for n in [1, 2, 9, 4]:",
						"if n == 9: break",
						"print(n) after the if, same indent as the if."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l17-continue",
					title: "Odds only",
					concept: "continue",
					prompt: "Loop 1, 2, 3, 4. Skip even numbers with continue. Print the odd ones.",
					briefing: "if n % 2 == 0: continue. Then print(n).",
					example: "if n % 2 == 0:\n    continue\nprint(n)",
					starter: "",
					expected: "1\n3\n",
					solution: "for n in [1, 2, 3, 4]:\n    if n % 2 == 0:\n        continue\n    print(n)",
					hints: [
						"for n in [1, 2, 3, 4]:",
						"if n % 2 == 0: continue",
						"print(n)"
					]
				}
			}
		]
	},
	{
		id: 18,
		title: "Record Vault",
		job: "Distinguished Engineer",
		difficulty: "Medium / Hard",
		description: "A dictionary maps a key to a value. Look up with [key].",
		objective: "Read a name, then promote a role.",
		rewardCoins: 2600,
		rewardXp: 1e3,
		unlockRewardId: "record-vault",
		unlockReward: "Record Vault",
		careerUnlock: "architect",
		chapter: "structures",
		steps: [
			{
				type: "brief",
				title: "Keys, not indexes",
				body: "A dict uses curly braces and colons: {\"name\": \"Ada\"}. Read with user[\"name\"]. Assign user[\"role\"] = \"architect\" to add or replace a key. Keys are usually strings.",
				example: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\nprint(user[\"name\"])"
			},
			{
				type: "choice",
				concept: "dict syntax",
				question: "Which line creates a dictionary?",
				options: [
					{
						id: "a",
						label: "user = [\"name\", \"Ada\"]",
						correct: false,
						explain: "Square brackets make a list, not a mapping."
					},
					{
						id: "b",
						label: "user = {\"name\": \"Ada\"}",
						correct: true,
						explain: "Curly braces, quoted key, colon, value."
					},
					{
						id: "c",
						label: "user = (\"name\": \"Ada\")",
						correct: false,
						explain: "Parentheses group expressions. They do not make a dict."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l18-read",
					title: "Look up",
					concept: "dict index",
					prompt: "user has name Ada and role lead. Print the name.",
					briefing: "user[\"name\"] — the key is a string, so it needs quotes.",
					example: "print(user[\"name\"])",
					starter: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\n",
					expected: "Ada\n",
					solution: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\nprint(user[\"name\"])",
					hints: [
						"user[\"name\"]",
						"Quotes around the key.",
						"print that lookup."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l18-write",
					title: "Promote",
					concept: "dict assign",
					prompt: "Change user role to architect, then print the role.",
					briefing: "user[\"role\"] = \"architect\" writes the key.",
					example: "user[\"role\"] = \"architect\"\nprint(user[\"role\"])",
					starter: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\n",
					expected: "architect\n",
					solution: "user = {\"name\": \"Ada\", \"role\": \"lead\"}\nuser[\"role\"] = \"architect\"\nprint(user[\"role\"])",
					hints: [
						"user[\"role\"] = \"architect\"",
						"Then print(user[\"role\"])",
						"Match the lowercase spelling."
					]
				}
			}
		]
	},
	{
		id: 19,
		title: "Key Walk",
		job: "Distinguished Engineer",
		difficulty: "Hard",
		description: "for k in dict walks keys. .get returns None instead of crashing.",
		objective: "Count keys, walk them, and safely look up a missing field.",
		rewardCoins: 2800,
		rewardXp: 1100,
		unlockRewardId: "key-walk",
		unlockReward: "Key Walk",
		careerUnlock: "distinguished",
		chapter: "structures",
		steps: [
			{
				type: "brief",
				title: "Missing keys",
				body: "user[\"art\"] raises KeyError if art is not there. user.get(\"art\") returns None instead. for k in scores walks the keys in insertion order. len(scores) counts keys.",
				example: "print(scores.get(\"art\"))\nfor k in scores:\n    print(k)"
			},
			{
				type: "code",
				challenge: {
					id: "l19-len-get",
					title: "Safe lookup",
					concept: "len + get",
					prompt: "Print how many keys scores has, then print scores.get(\"art\") — that key is missing.",
					briefing: "Missing get returns None, which print shows as None.",
					example: "print(len(scores))\nprint(scores.get(\"art\"))",
					starter: "scores = {\"math\": 90, \"code\": 80}\n",
					expected: "2\nNone\n",
					solution: "scores = {\"math\": 90, \"code\": 80}\nprint(len(scores))\nprint(scores.get(\"art\"))",
					hints: [
						"print(len(scores))",
						"print(scores.get(\"art\"))",
						"None has a capital N."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l19-keys",
					title: "Walk keys",
					concept: "for in dict",
					prompt: "Loop through scores and print each key on its own line.",
					briefing: "for k in scores: prints math then code — insertion order.",
					example: "for k in scores:\n    print(k)",
					starter: "scores = {\"math\": 90, \"code\": 80}\n",
					expected: "math\ncode\n",
					solution: "scores = {\"math\": 90, \"code\": 80}\nfor k in scores:\n    print(k)",
					hints: [
						"for k in scores:",
						"print(k)",
						"Do not print the values in this task."
					]
				}
			}
		]
	},
	{
		id: 20,
		title: "Roster Intel",
		job: "Fellow",
		difficulty: "Hard",
		description: "Filter a dictionary of people by their scores.",
		objective: "Print names whose score is at least 80.",
		rewardCoins: 3e3,
		rewardXp: 1200,
		unlockRewardId: "roster-intel",
		unlockReward: "Roster Intel",
		careerUnlock: "distinguished",
		chapter: "structures",
		steps: [
			{
				type: "brief",
				title: "Key then value",
				body: "for name in team: gives keys. team[name] is the score. Combine with if to keep a shortlist. This is how live rosters are queried.",
				example: "for name in team:\n    if team[name] >= 80:\n        print(name)"
			},
			{
				type: "choice",
				concept: "in on dict",
				question: "What does \"Lin\" in team check?",
				options: [
					{
						id: "a",
						label: "Whether any score equals the text Lin",
						correct: false,
						explain: "in on a dict checks keys, not values."
					},
					{
						id: "b",
						label: "Whether Lin is a key in the dictionary",
						correct: true,
						explain: "\"Lin\" in team is True if that name exists as a key."
					},
					{
						id: "c",
						label: "Whether the dict is named Lin",
						correct: false,
						explain: "The dict is named team. in looks inside it."
					}
				]
			},
			{
				type: "code",
				challenge: {
					id: "l20-filter",
					title: "Clearance list",
					concept: "dict + if",
					prompt: "team maps names to scores. Print every name whose score is at least 80, each on its own line, in dictionary order.",
					briefing: "Ada 90 and Kai 88 pass. Lin 70 does not.",
					example: "for name in team:\n    if team[name] >= 80:\n        print(name)",
					starter: "team = {\"Ada\": 90, \"Lin\": 70, \"Kai\": 88}\n",
					expected: "Ada\nKai\n",
					solution: "team = {\"Ada\": 90, \"Lin\": 70, \"Kai\": 88}\nfor name in team:\n    if team[name] >= 80:\n        print(name)",
					hints: [
						"for name in team:",
						"if team[name] >= 80:",
						"print(name)"
					]
				}
			}
		]
	},
	{
		id: 21,
		title: "Dual Params",
		job: "Fellow",
		difficulty: "Medium / Hard",
		description: "A function can take more than one input.",
		objective: "Build a tag and compute an area.",
		rewardCoins: 3200,
		rewardXp: 1300,
		unlockRewardId: "dual-params",
		unlockReward: "Dual Params",
		careerUnlock: "distinguished",
		chapter: "mastery",
		steps: [
			{
				type: "brief",
				title: "Order of arguments",
				body: "def tag(role, name): has two parameters. tag(\"Lead\", \"Ada\") sends Lead into role and Ada into name — order matches. return sends a value back; print is still separate.",
				example: "def tag(role, name):\n    return role + \": \" + name\nprint(tag(\"Lead\", \"Ada\"))"
			},
			{
				type: "code",
				challenge: {
					id: "l21-tag",
					title: "Name tag",
					concept: "two parameters",
					prompt: "Write tag(role, name) so it returns role, then \": \", then name. Print tag(\"Lead\", \"Ada\").",
					briefing: "Join three strings. Remember the colon and space.",
					example: "return role + \": \" + name",
					starter: "def tag(role, name):\n    return name\n",
					expected: "Lead: Ada\n",
					solution: "def tag(role, name):\n    return role + \": \" + name\nprint(tag(\"Lead\", \"Ada\"))",
					hints: [
						"return role + \": \" + name",
						"Colon then space inside the string.",
						"print(tag(\"Lead\", \"Ada\"))"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l21-area",
					title: "Floor plan",
					concept: "two parameters",
					prompt: "Write area(w, h) that returns w times h. Print area(4, 5).",
					briefing: "Numbers multiply with *. Return the product, then print the call.",
					example: "def area(w, h):\n    return w * h",
					starter: "def area(w, h):\n    return 0\n",
					expected: "20\n",
					solution: "def area(w, h):\n    return w * h\nprint(area(4, 5))",
					hints: [
						"return w * h",
						"print(area(4, 5))",
						"The answer is 20."
					]
				}
			}
		]
	},
	{
		id: 22,
		title: "Return Path",
		job: "Fellow",
		difficulty: "Hard",
		description: "A function can return from more than one branch.",
		objective: "Grade two scores with one function.",
		rewardCoins: 3400,
		rewardXp: 1400,
		unlockRewardId: "return-path",
		unlockReward: "Return Path",
		careerUnlock: "fellow",
		chapter: "mastery",
		steps: [{
			type: "brief",
			title: "return exits immediately",
			body: "When a function hits return, it stops. You can return from the if branch and from the else branch. Call the function twice to test both paths.",
			example: "def grade(n):\n    if n >= 70:\n        return \"PASS\"\n    return \"RETRY\""
		}, {
			type: "code",
			challenge: {
				id: "l22-grade",
				title: "Two calls",
				concept: "return branches",
				prompt: "Write grade(n) that returns PASS if n is at least 70, otherwise RETRY. Print grade(70) and grade(40), each on its own line.",
				briefing: "Two print calls after the function. 70 is PASS. 40 is RETRY.",
				example: "print(grade(70))\nprint(grade(40))",
				starter: "def grade(n):\n    return \"RETRY\"\n",
				expected: "PASS\nRETRY\n",
				solution: "def grade(n):\n    if n >= 70:\n        return \"PASS\"\n    return \"RETRY\"\nprint(grade(70))\nprint(grade(40))",
				hints: [
					"if n >= 70: return \"PASS\"",
					"return \"RETRY\" after the if",
					"Print both calls."
				]
			}
		}]
	},
	{
		id: 23,
		title: "Join Forge",
		job: "Python Master",
		difficulty: "Hard",
		description: "split turns text into a list. join turns a list into text.",
		objective: "Join with dashes. Split on commas.",
		rewardCoins: 3600,
		rewardXp: 1600,
		unlockRewardId: "join-forge",
		unlockReward: "Join Forge",
		careerUnlock: "fellow",
		chapter: "mastery",
		steps: [
			{
				type: "brief",
				title: "The separator is on the left",
				body: "\"-\".join(parts) puts a dash between each string in the list. text.split(\",\") cuts on commas and returns a list. join fails if a list item is a number — convert with str first in real work.",
				example: "print(\"-\".join([\"plan\", \"code\", \"ship\"]))\nprint(\"a,b,c\".split(\",\"))"
			},
			{
				type: "code",
				challenge: {
					id: "l23-join",
					title: "Pipeline",
					concept: "join",
					prompt: "parts is plan, code, ship. Print them joined with dashes, no extra spaces.",
					briefing: "The string before the dot is the glue.",
					example: "print(\"-\".join(parts))",
					starter: "parts = [\"plan\", \"code\", \"ship\"]\n",
					expected: "plan-code-ship\n",
					solution: "parts = [\"plan\", \"code\", \"ship\"]\nprint(\"-\".join(parts))",
					hints: [
						"\"-\".join(parts)",
						"Print that call.",
						"No spaces around the dashes."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l23-split",
					title: "Cut the csv",
					concept: "split",
					prompt: "text is a,b,c. Split on the comma and print the list.",
					briefing: "split returns a list of strings. print shows brackets and quotes.",
					example: "print(text.split(\",\"))",
					starter: "text = \"a,b,c\"\n",
					expected: "['a', 'b', 'c']\n",
					solution: "text = \"a,b,c\"\nprint(text.split(\",\"))",
					hints: [
						"text.split(\",\")",
						"The separator is a comma string.",
						"print the result."
					]
				}
			}
		]
	},
	{
		id: 24,
		title: "Sort Engine",
		job: "Python Master",
		difficulty: "Hard",
		description: "sorted returns a new list. min, max, and your own mean.",
		objective: "Order a list, then write a mean function using //.",
		rewardCoins: 4e3,
		rewardXp: 1800,
		unlockRewardId: "sort-engine",
		unlockReward: "Sort Engine",
		careerUnlock: "fellow",
		chapter: "mastery",
		steps: [
			{
				type: "brief",
				title: "sorted vs sort",
				body: "sorted(nums) returns a new ordered list and leaves nums alone. nums.sort() changes nums and returns None. // is integer division — 60 // 3 is 20, not 20.0.",
				example: "print(sorted([5, 1, 4]))\nprint(sum(xs) // len(xs))"
			},
			{
				type: "code",
				challenge: {
					id: "l24-sorted",
					title: "In order",
					concept: "sorted + min/max",
					prompt: "nums is [5, 1, 4]. Print the sorted list, then the max, then the min, each on its own line.",
					briefing: "sorted, max, and min are built-in functions — not methods on this task.",
					example: "print(sorted(nums))\nprint(max(nums))\nprint(min(nums))",
					starter: "nums = [5, 1, 4]\n",
					expected: "[1, 4, 5]\n5\n1\n",
					solution: "nums = [5, 1, 4]\nprint(sorted(nums))\nprint(max(nums))\nprint(min(nums))",
					hints: [
						"print(sorted(nums))",
						"print(max(nums))",
						"print(min(nums))"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l24-mean",
					title: "Integer mean",
					concept: "functions + //",
					prompt: "Write mean(xs) that returns the integer average: sum divided by length using //. Print mean([10, 20, 30]).",
					briefing: "sum(xs) // len(xs). Integer division drops the decimal.",
					example: "def mean(xs):\n    return sum(xs) // len(xs)",
					starter: "def mean(xs):\n    return 0\n",
					expected: "20\n",
					solution: "def mean(xs):\n    return sum(xs) // len(xs)\nprint(mean([10, 20, 30]))",
					hints: [
						"return sum(xs) // len(xs)",
						"Use // not /",
						"print(mean([10, 20, 30]))"
					]
				}
			}
		]
	},
	{
		id: 25,
		title: "Python Mastery",
		job: "Python Master",
		difficulty: "Expert",
		description: "Mid-course championship. Functions, dictionaries, and a written report — under the clock.",
		objective: "Clear every stage. Claim the Master's Apex. Then the advanced tracks open.",
		rewardCoins: 8e3,
		rewardXp: 2500,
		unlockRewardId: "master-apex",
		unlockReward: "Master's Apex",
		careerUnlock: "master",
		chapter: "mastery",
		timeLimitSec: 180,
		championship: true,
		steps: [
			{
				type: "brief",
				title: "Everything you learned",
				body: "Stage 1 packages a decision in a function. Stage 2 filters a live roster. Stage 3 writes a text report from numbers. Same rules as always: colons, indents, quotes, and print.",
				example: "def label(score):\n    if score >= 70:\n        return \"PASS\"\n    return \"RETRY\""
			},
			{
				type: "code",
				challenge: {
					id: "l25-label",
					title: "Stage 1 — Stamp",
					concept: "functions + if",
					prompt: "Write label(score) that returns PASS if score is at least 70, else RETRY. Print label(88) then label(40).",
					briefing: "Two returns. Two calls. Two lines of output.",
					example: "print(label(88))\nprint(label(40))",
					starter: "def label(score):\n    return score\n",
					expected: "PASS\nRETRY\n",
					solution: "def label(score):\n    if score >= 70:\n        return \"PASS\"\n    return \"RETRY\"\nprint(label(88))\nprint(label(40))",
					hints: [
						"if score >= 70: return \"PASS\"",
						"return \"RETRY\"",
						"Print both calls."
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l25-roster",
					title: "Stage 2 — Shortlist",
					concept: "dict filter",
					prompt: "scores maps names to exam results. Print names with a score of at least 70, each on its own line, in dictionary order.",
					briefing: "Ada 90 and Kai 70 pass. Lin 55 does not.",
					example: "for name in scores:\n    if scores[name] >= 70:\n        print(name)",
					starter: "scores = {\"Ada\": 90, \"Lin\": 55, \"Kai\": 70}\n",
					expected: "Ada\nKai\n",
					solution: "scores = {\"Ada\": 90, \"Lin\": 55, \"Kai\": 70}\nfor name in scores:\n    if scores[name] >= 70:\n        print(name)",
					hints: [
						"for name in scores:",
						"if scores[name] >= 70:",
						"print(name)"
					]
				}
			},
			{
				type: "code",
				challenge: {
					id: "l25-report",
					title: "Stage 3 — Report",
					concept: "str + builtins",
					prompt: "Write report(nums) that returns the text sum= then the sum, then a space, then n= then the length. Print report([10, 20, 30]).",
					briefing: "Join strings with +. Convert numbers with str(). Example shape: sum=60 n=3",
					example: "return \"sum=\" + str(sum(nums)) + \" n=\" + str(len(nums))",
					starter: "def report(nums):\n    return \"\"\n",
					expected: "sum=60 n=3\n",
					solution: "def report(nums):\n    return \"sum=\" + str(sum(nums)) + \" n=\" + str(len(nums))\nprint(report([10, 20, 30]))",
					hints: [
						"str(sum(nums)) and str(len(nums))",
						"Space before n=",
						"print(report([10, 20, 30]))"
					]
				}
			}
		]
	}
], ...LEVELS_PLUS];
var CHAPTERS = [
	{
		id: "foundations",
		title: "Track 1 · Foundations",
		blurb: "Print, store, decide, loop, ship a function."
	},
	{
		id: "strings",
		title: "Track 2 · Strings",
		blurb: "Text, case, characters, and joining words."
	},
	{
		id: "logic",
		title: "Track 3 · Logic",
		blurb: "Booleans, comparisons, and branching paths."
	},
	{
		id: "loops",
		title: "Track 4 · Loops",
		blurb: "while, range, nested repetition."
	},
	{
		id: "structures",
		title: "Track 5 · Data",
		blurb: "Indexes, slices, dictionaries, live records."
	},
	{
		id: "mastery",
		title: "Track 6 · Mastery",
		blurb: "Functions, reports, and the mid-course championship."
	},
	{
		id: "algorithms",
		title: "Track 7 · Algorithms",
		blurb: "Remainders, membership, reverse, and counting tricks."
	},
	{
		id: "fluency",
		title: "Track 8 · Fluency",
		blurb: "Methods, unpacking, nested data, and range steps."
	},
	{
		id: "studio",
		title: "Track 9 · Studio",
		blurb: "Helpers, reports, and the Grandmaster championship."
	}
];
var CAREERS = [
	{
		id: "rookie",
		title: "Rookie",
		rank: 0,
		blurb: "You just walked in. Learn how Python talks."
	},
	{
		id: "trainee",
		title: "Trainee",
		rank: 1,
		blurb: "Hired. You can print and store values."
	},
	{
		id: "junior",
		title: "Junior Associate",
		rank: 2,
		blurb: "You make decisions with data."
	},
	{
		id: "specialist",
		title: "Specialist",
		rank: 3,
		blurb: "You write conditions under pressure."
	},
	{
		id: "manager",
		title: "Manager",
		rank: 4,
		blurb: "You command lists and loops."
	},
	{
		id: "elite",
		title: "Elite Professional",
		rank: 5,
		blurb: "You ship functions. Mid-career championship cleared."
	},
	{
		id: "senior",
		title: "Senior Engineer",
		rank: 6,
		blurb: "Strings and text pipelines are second nature."
	},
	{
		id: "staff",
		title: "Staff Engineer",
		rank: 7,
		blurb: "You design branching logic that holds."
	},
	{
		id: "lead",
		title: "Lead Engineer",
		rank: 8,
		blurb: "You keep loops honest under a clock."
	},
	{
		id: "principal",
		title: "Principal Engineer",
		rank: 9,
		blurb: "Lists, indexes, and slices live in your hands."
	},
	{
		id: "architect",
		title: "Architect",
		rank: 10,
		blurb: "You model records with dictionaries."
	},
	{
		id: "distinguished",
		title: "Distinguished Engineer",
		rank: 11,
		blurb: "You query nested data without flinching."
	},
	{
		id: "fellow",
		title: "Fellow",
		rank: 12,
		blurb: "You compose functions into tools."
	},
	{
		id: "master",
		title: "Python Master",
		rank: 13,
		blurb: "Mid-course crown. The next tracks go deeper."
	},
	{
		id: "legend",
		title: "Legend",
		rank: 14,
		blurb: "You see patterns in operators and membership."
	},
	{
		id: "oracle",
		title: "Oracle",
		rank: 15,
		blurb: "String and list methods answer on command."
	},
	{
		id: "sage",
		title: "Sage",
		rank: 16,
		blurb: "You unpack pairs and walk nested structure."
	},
	{
		id: "director",
		title: "Director",
		rank: 17,
		blurb: "You compose helpers into a studio pipeline."
	},
	{
		id: "grandmaster",
		title: "Grandmaster",
		rank: 18,
		blurb: "Full Python career cleared. You teach the language by writing it."
	}
];
var REWARDS = [
	{
		id: "trainee-badge",
		name: "Trainee Badge",
		levelId: 1,
		blurb: "Proof you shipped your first program."
	},
	{
		id: "junior-desk",
		name: "Junior Desk",
		levelId: 2,
		blurb: "A real workstation. Variables live here."
	},
	{
		id: "specialist-outfit",
		name: "Specialist Outfit",
		levelId: 3,
		blurb: "Kit for timed missions."
	},
	{
		id: "executive-office",
		name: "Executive Office",
		levelId: 4,
		blurb: "Corner office. Lists on the glass."
	},
	{
		id: "m8-apex",
		name: "M8 Apex",
		levelId: 5,
		blurb: "In-game championship grand tourer. Not a real-world prize.",
		featured: true
	},
	{
		id: "string-keys",
		name: "String Keys",
		levelId: 6,
		blurb: "Access badge for the text lab."
	},
	{
		id: "case-file",
		name: "Case File",
		levelId: 7,
		blurb: "upper, lower, and strip — filed."
	},
	{
		id: "char-lens",
		name: "Character Lens",
		levelId: 8,
		blurb: "See every letter. Indexes start at 0."
	},
	{
		id: "logic-core",
		name: "Logic Core",
		levelId: 9,
		blurb: "True, False, and, or, not."
	},
	{
		id: "branch-map",
		name: "Branch Map",
		levelId: 10,
		blurb: "elif chains under a ticking clock."
	},
	{
		id: "while-engine",
		name: "While Engine",
		levelId: 11,
		blurb: "Loops that know when to stop."
	},
	{
		id: "range-rail",
		name: "Range Rail",
		levelId: 12,
		blurb: "0, 1, 2… counted without a handwritten list."
	},
	{
		id: "nest-grid",
		name: "Nest Grid",
		levelId: 13,
		blurb: "Loops inside loops. A grid of answers."
	},
	{
		id: "index-badge",
		name: "Index Badge",
		levelId: 14,
		blurb: "Replace the item at a position."
	},
	{
		id: "append-bay",
		name: "Append Bay",
		levelId: 15,
		blurb: "Grow a list. append returns None."
	},
	{
		id: "slice-glass",
		name: "Slice Glass",
		levelId: 16,
		blurb: "Take a window: start:end."
	},
	{
		id: "break-seal",
		name: "Break Seal",
		levelId: 17,
		blurb: "Leave a loop early. Skip with continue."
	},
	{
		id: "record-vault",
		name: "Record Vault",
		levelId: 18,
		blurb: "Key → value. Your first dictionary."
	},
	{
		id: "key-walk",
		name: "Key Walk",
		levelId: 19,
		blurb: "Walk keys. .get never explodes."
	},
	{
		id: "roster-intel",
		name: "Roster Intel",
		levelId: 20,
		blurb: "Filter a living record of people."
	},
	{
		id: "dual-params",
		name: "Dual Params",
		levelId: 21,
		blurb: "Functions that take more than one input."
	},
	{
		id: "return-path",
		name: "Return Path",
		levelId: 22,
		blurb: "Two returns. One function. Clean exits."
	},
	{
		id: "join-forge",
		name: "Join Forge",
		levelId: 23,
		blurb: "split and join — text as structure."
	},
	{
		id: "sort-engine",
		name: "Sort Engine",
		levelId: 24,
		blurb: "Order, min, max, and a mean you wrote."
	},
	{
		id: "master-apex",
		name: "Master's Apex",
		levelId: 25,
		blurb: "In-game mastery crown. Not a real-world prize.",
		featured: true
	},
	{
		id: "remainder-seal",
		name: "Remainder Seal",
		levelId: 26,
		blurb: "% tells you what is left after dividing."
	},
	{
		id: "power-cell",
		name: "Power Cell",
		levelId: 27,
		blurb: "** raises. // divides and drops the decimal."
	},
	{
		id: "repeat-tape",
		name: "Repeat Tape",
		levelId: 28,
		blurb: "A string times a number repeats the signal."
	},
	{
		id: "member-pass",
		name: "Member Pass",
		levelId: 29,
		blurb: "in and not in — present or absent."
	},
	{
		id: "chain-gate",
		name: "Chain Gate",
		levelId: 30,
		blurb: "1 < x < 10 reads like math class."
	},
	{
		id: "none-watch",
		name: "None Watch",
		levelId: 31,
		blurb: "None is the value that means no value."
	},
	{
		id: "truth-lens",
		name: "Truth Lens",
		levelId: 32,
		blurb: "Empty lists and empty strings are False."
	},
	{
		id: "swap-file",
		name: "Swap File",
		levelId: 33,
		blurb: "replace rewrites. find locates."
	},
	{
		id: "prefix-badge",
		name: "Prefix Badge",
		levelId: 34,
		blurb: "startswith and endswith check the edges."
	},
	{
		id: "digit-gate",
		name: "Digit Gate",
		levelId: 35,
		blurb: "isdigit and isalpha classify characters."
	},
	{
		id: "pop-stack",
		name: "Pop Stack",
		levelId: 36,
		blurb: "pop takes the last. insert places anywhere."
	},
	{
		id: "mutate-rack",
		name: "Mutate Rack",
		levelId: 37,
		blurb: "sort and reverse change the list in place."
	},
	{
		id: "count-desk",
		name: "Count Desk",
		levelId: 38,
		blurb: "count tells you how many times it appears."
	},
	{
		id: "enum-walk",
		name: "Enum Walk",
		levelId: 39,
		blurb: "enumerate hands you the index and the item."
	},
	{
		id: "pair-unpack",
		name: "Pair Unpack",
		levelId: 40,
		blurb: "for k, v in items() — two names, one pair."
	},
	{
		id: "grid-key",
		name: "Grid Key",
		levelId: 41,
		blurb: "grid[row][col] — a list inside a list."
	},
	{
		id: "nested-vault",
		name: "Nested Vault",
		levelId: 42,
		blurb: "A dictionary that holds dictionaries."
	},
	{
		id: "step-rail",
		name: "Step Rail",
		levelId: 43,
		blurb: "range can skip: 0, 2, 4, 6."
	},
	{
		id: "mirror-glass",
		name: "Mirror Glass",
		levelId: 44,
		blurb: "[::-1] reverses a string or a list."
	},
	{
		id: "accum-forge",
		name: "Accum Forge",
		levelId: 45,
		blurb: "Build a string one piece at a time."
	},
	{
		id: "helper-link",
		name: "Helper Link",
		levelId: 46,
		blurb: "One function calls another."
	},
	{
		id: "studio-report",
		name: "Studio Report",
		levelId: 47,
		blurb: "A function that reads a roster and writes a line."
	},
	{
		id: "even-filter",
		name: "Even Filter",
		levelId: 48,
		blurb: "Keep the evens. Discard the odds."
	},
	{
		id: "default-key",
		name: "Default Key",
		levelId: 49,
		blurb: "get(key, fallback) never crashes."
	},
	{
		id: "grandmaster-crown",
		name: "Grandmaster Crown",
		levelId: 50,
		blurb: "In-game career finale. Not a real-world prize.",
		featured: true
	}
];
function careerById(id) {
	return CAREERS.find((c) => c.id === id) ?? CAREERS[0];
}
function nextCareer(id) {
	const cur = careerById(id);
	return CAREERS.find((c) => c.rank === cur.rank + 1) ?? null;
}
function rewardById(id) {
	return REWARDS.find((r) => r.id === id);
}
/** Cumulative XP required to sit at a player level. Level 1 starts at 0. */
var XP_THRESHOLDS = [
	0,
	100,
	250,
	500,
	900,
	1650,
	2500,
	3600,
	5e3,
	6800,
	9e3,
	11600,
	14800,
	18600,
	23e3,
	28e3,
	34e3,
	41e3
];
function playerLevelFromXp(xp) {
	let level = 1;
	for (let i = 1; i < XP_THRESHOLDS.length; i++) if (xp >= XP_THRESHOLDS[i]) level = i + 1;
	else break;
	const last = XP_THRESHOLDS[XP_THRESHOLDS.length - 1];
	if (xp >= last) level = XP_THRESHOLDS.length + Math.floor((xp - last) / 1200);
	return level;
}
function xpProgress(xp) {
	const level = playerLevelFromXp(xp);
	const lastIdx = XP_THRESHOLDS.length - 1;
	if (level <= lastIdx) {
		const start = XP_THRESHOLDS[level - 1] ?? 0;
		const next = XP_THRESHOLDS[level] ?? start + 1e3;
		const current = xp - start;
		const needed = next - start;
		return {
			level,
			current,
			needed,
			ratio: needed === 0 ? 1 : Math.min(1, current / needed)
		};
	}
	const into = (xp - XP_THRESHOLDS[lastIdx]) % 1200;
	return {
		level,
		current: into,
		needed: 1200,
		ratio: into / 1200
	};
}
function levelById(id) {
	return LEVELS.find((l) => l.id === id);
}
function nextLevelId(completed) {
	for (const l of LEVELS) if (!completed.includes(l.id)) return l.id;
	return LEVELS[LEVELS.length - 1].id;
}
function isLevelUnlocked(id, completed) {
	if (id <= 1) return true;
	return completed.includes(id - 1);
}
function codeStepCount(level) {
	return level.steps.filter((s) => s.type === "code").length;
}
var KEY = "jarvis_career_save";
var defaults = () => ({
	version: 1,
	playerName: "Player",
	hasStarted: false,
	coins: 500,
	xp: 0,
	completedLevels: [],
	unlockedRewards: [],
	career: "rookie",
	highestLevel: 0,
	muted: false
});
function migrate(raw) {
	const base = defaults();
	if (!raw || typeof raw !== "object") return base;
	const s = raw;
	const completed = Array.isArray(s.completedLevels) ? s.completedLevels.filter((n) => typeof n === "number" && n >= 1 && n <= LEVELS.length) : [];
	const rewards = Array.isArray(s.unlockedRewards) ? s.unlockedRewards.filter((x) => typeof x === "string") : [];
	const career = CAREERS.some((c) => c.id === s.career) ? s.career : "rookie";
	return {
		...base,
		version: 1,
		playerName: typeof s.playerName === "string" && s.playerName.trim() ? s.playerName.trim().slice(0, 24) : "Player",
		hasStarted: Boolean(s.hasStarted),
		coins: Math.max(0, Math.floor(Number(s.coins) || 0)),
		xp: Math.max(0, Math.floor(Number(s.xp) || 0)),
		completedLevels: [...new Set(completed)],
		unlockedRewards: [...new Set(rewards)],
		career,
		highestLevel: Math.max(0, ...completed, Number(s.highestLevel) || 0),
		muted: Boolean(s.muted)
	};
}
var toastTimer;
function champClaim(p) {
	if (!p.firstClear) return null;
	if (levelById(p.levelId)?.championship) return {
		id: "claim",
		levelId: p.levelId
	};
	return null;
}
function nextAfterComplete(p) {
	if (p.nextLevel > p.prevLevel) return {
		id: "levelup",
		from: p.prevLevel,
		to: p.nextLevel
	};
	if (p.firstClear && p.nextCareer !== p.prevCareer) return {
		id: "hired",
		career: p.nextCareer
	};
	return champClaim(p) ?? { id: "home" };
}
function nextAfterLevelUp(p) {
	if (p.firstClear && p.nextCareer !== p.prevCareer) return {
		id: "hired",
		career: p.nextCareer
	};
	return champClaim(p) ?? { id: "home" };
}
function nextAfterHired(p) {
	return champClaim(p) ?? { id: "home" };
}
var useGame = create()(persist((set, get) => ({
	...defaults(),
	screen: { id: "welcome" },
	tab: "home",
	toast: null,
	hydrated: false,
	shakeLock: 0,
	pending: null,
	setHydrated: () => {
		const s = get();
		const onGate = s.screen.id === "boot" || s.screen.id === "welcome" || s.screen.id === "home";
		set({
			hydrated: true,
			screen: s.hasStarted ? onGate ? { id: "home" } : s.screen : { id: "welcome" },
			tab: onGate ? "home" : s.tab
		});
		audio.setMuted(s.muted);
	},
	startCareer: () => {
		audio.unlock();
		audio.success();
		set({
			hasStarted: true,
			screen: { id: "home" },
			tab: "home"
		});
	},
	setTab: (tab) => {
		audio.click();
		set({
			tab,
			screen: { id: tab }
		});
	},
	setName: (name) => {
		set({ playerName: name.trim().slice(0, 24) || "Player" });
	},
	toggleMute: () => {
		const muted = !get().muted;
		audio.setMuted(muted);
		if (!muted) audio.click();
		set({ muted });
	},
	tryPlay: () => {
		const { completedLevels } = get();
		const next = LEVELS.find((l) => !completedLevels.includes(l.id)) ?? LEVELS[LEVELS.length - 1];
		get().openLevel(next.id);
	},
	openLevel: (id) => {
		audio.unlock();
		const { completedLevels } = get();
		if (!isLevelUnlocked(id, completedLevels)) {
			audio.fail();
			set({ shakeLock: Date.now() });
			get().flash(`Complete Level ${id - 1} to unlock.`);
			return;
		}
		audio.click();
		set({
			screen: {
				id: "intro",
				levelId: id
			},
			tab: "home"
		});
	},
	beginMission: (id) => {
		audio.click();
		const { completedLevels } = get();
		if (!isLevelUnlocked(id, completedLevels)) {
			get().flash("That level is locked.");
			return;
		}
		set({ screen: {
			id: "play",
			levelId: id
		} });
	},
	abortMission: () => {
		audio.click();
		set({
			screen: { id: "home" },
			tab: "home"
		});
	},
	finishMission: (id, score) => {
		const level = levelById(id);
		if (!level) return;
		const s = get();
		const firstClear = !s.completedLevels.includes(id);
		const prevLevel = playerLevelFromXp(s.xp);
		const prevCareer = s.career;
		let coins = 0;
		let xp = 0;
		let career = s.career;
		let completedLevels = s.completedLevels;
		let unlockedRewards = s.unlockedRewards;
		let newXp = s.xp;
		let newCoins = s.coins;
		if (firstClear) {
			coins = level.rewardCoins;
			xp = level.rewardXp;
			newXp = s.xp + xp;
			newCoins = s.coins + coins;
			completedLevels = [...s.completedLevels, id];
			if (!unlockedRewards.includes(level.unlockRewardId)) unlockedRewards = [...unlockedRewards, level.unlockRewardId];
			career = level.careerUnlock;
		}
		const pending = {
			firstClear,
			levelId: id,
			prevLevel,
			nextLevel: playerLevelFromXp(newXp),
			prevCareer,
			nextCareer: career
		};
		audio.complete();
		set({
			coins: newCoins,
			xp: newXp,
			completedLevels,
			unlockedRewards,
			career,
			highestLevel: Math.max(s.highestLevel, id),
			pending,
			screen: {
				id: "complete",
				levelId: id,
				firstClear,
				coins,
				xp,
				score
			}
		});
	},
	continueFrom: () => {
		audio.click();
		const { screen, pending } = get();
		if (screen.id === "complete") {
			if (pending) {
				const next = nextAfterComplete(pending);
				if (next.id === "levelup") audio.levelup();
				if (next.id === "hired") audio.unlockReward();
				set({
					screen: next,
					tab: next.id === "home" ? "home" : get().tab
				});
				return;
			}
			set({
				screen: { id: "home" },
				tab: "home"
			});
			return;
		}
		if (screen.id === "levelup") {
			const next = pending ? nextAfterLevelUp(pending) : { id: "home" };
			if (next.id === "hired") audio.unlockReward();
			set({
				screen: next,
				tab: next.id === "home" ? "home" : get().tab
			});
			return;
		}
		if (screen.id === "hired") {
			const next = pending ? nextAfterHired(pending) : { id: "home" };
			set({
				screen: next,
				tab: next.id === "home" ? "home" : get().tab
			});
			return;
		}
		if (screen.id === "claimed") {
			set({
				screen: { id: "home" },
				tab: "home"
			});
			return;
		}
		set({
			screen: { id: "home" },
			tab: "home"
		});
	},
	claimFinal: () => {
		audio.unlockReward();
		set({ screen: { id: "claimed" } });
	},
	resetProgress: () => {
		const muted = get().muted;
		const playerName = get().playerName;
		set({
			...defaults(),
			muted,
			playerName,
			hasStarted: true,
			screen: { id: "home" },
			tab: "home",
			hydrated: true,
			pending: null
		});
		get().flash("Progress reset.");
	},
	flash: (msg) => {
		set({ toast: msg });
		if (toastTimer) clearTimeout(toastTimer);
		toastTimer = setTimeout(() => set({ toast: null }), 2200);
	}
}), {
	name: KEY,
	storage: createJSONStorage(() => {
		if (typeof window === "undefined") return {
			getItem: () => null,
			setItem: () => {},
			removeItem: () => {}
		};
		return localStorage;
	}),
	version: 1,
	partialize: (s) => ({
		version: s.version,
		playerName: s.playerName,
		hasStarted: s.hasStarted,
		coins: s.coins,
		xp: s.xp,
		completedLevels: s.completedLevels,
		unlockedRewards: s.unlockedRewards,
		career: s.career,
		highestLevel: s.highestLevel,
		muted: s.muted
	}),
	merge: (persisted, current) => ({
		...current,
		...migrate(persisted)
	}),
	skipHydration: true
}));
function MissionView({ levelId }) {
	const level = levelById(levelId);
	const abortMission = useGame((s) => s.abortMission);
	if (!level) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Unknown mission." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-4",
			onClick: abortMission,
			children: "Back"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionPlay, { level });
}
function MissionPlay({ level }) {
	const finishMission = useGame((s) => s.finishMission);
	const abortMission = useGame((s) => s.abortMission);
	const [step, setStep] = (0, import_react.useState)(0);
	const [failed, setFailed] = (0, import_react.useState)(false);
	const [mistakes, setMistakes] = (0, import_react.useState)(0);
	const [codeDone, setCodeDone] = (0, import_react.useState)(0);
	const [runId, setRunId] = (0, import_react.useState)(0);
	const startedAt = (0, import_react.useRef)(Date.now());
	const totalCode = codeStepCount(level);
	const current = level.steps[step];
	const timed = Boolean(level.timeLimitSec) && current?.type === "code";
	function next() {
		if (step + 1 >= level.steps.length) {
			const elapsed = (Date.now() - startedAt.current) / 1e3;
			const timeBonus = level.championship ? Math.max(0, 10 - Math.floor(elapsed / 12)) : 0;
			const score = level.championship ? Math.max(0, Math.min(100, codeDone * 30 + timeBonus - mistakes * 5)) : void 0;
			finishMission(level.id, score);
			return;
		}
		setStep((s) => s + 1);
	}
	function failTime() {
		audio.fail();
		setFailed(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-10 flex items-center gap-3 border-b border-border bg-bg/95 px-4 py-3 backdrop-blur-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "Abort mission",
						onClick: abortMission,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
							children: ["Level ", String(level.id).padStart(2, "0")]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-semibold",
							children: level.title
						})]
					}),
					level.timeLimitSec ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionTimer, {
						seconds: level.timeLimitSec,
						running: timed && !failed,
						onExpire: failTime,
						freeze: failed
					}, runId) : null
				]
			}),
			totalCode > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex gap-2 overflow-x-auto px-4 py-3",
				children: level.steps.filter((s) => s.type === "code").map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cn("flex items-center gap-2 rounded-full px-3 py-1 text-xs", i < codeDone ? "bg-success/15 text-success" : "bg-surface text-muted"),
					children: [i < codeDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }), s.challenge.title.split("—")[0]]
				}, s.challenge.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-xl flex-1 px-4 py-4 pb-10",
				children: failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FailCard, {
					championship: Boolean(level.championship),
					onRetry: () => {
						setFailed(false);
						setStep(level.steps.findIndex((s) => s.type === "code"));
						setCodeDone(0);
						setRunId((n) => n + 1);
						startedAt.current = Date.now();
					},
					onQuit: abortMission
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepView, {
					step: current,
					onNext: next,
					onCodePass: () => {
						setCodeDone((n) => n + 1);
						next();
					},
					onMistake: () => setMistakes((n) => n + 1)
				}, step)
			})
		]
	});
}
function StepView({ step, onNext, onCodePass, onMistake }) {
	if (step.type === "brief") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
				children: "Briefing"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-2xl font-semibold tracking-tight",
				children: step.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-[15px] leading-relaxed text-muted",
				children: step.body
			}),
			step.example && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-4 overflow-x-auto rounded-xl bg-surface-2 p-4 font-mono text-sm text-accent",
				children: step.example
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-8 w-full",
				size: "lg",
				onClick: onNext,
				children: "Continue"
			})
		]
	});
	if (step.type === "reaction") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactionStep, {
		title: step.title,
		body: step.body,
		onPass: onNext
	});
	if (step.type === "choice") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceStep, {
		step,
		onPass: onNext
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeEditor, {
		challenge: step.challenge,
		onPass: onCodePass,
		onFail: onMistake
	});
}
function ReactionStep({ title, body, onPass }) {
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [ms, setMs] = (0, import_react.useState)(0);
	const goAt = (0, import_react.useRef)(0);
	const timer = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		return () => window.clearTimeout(timer.current);
	}, []);
	function arm() {
		audio.click();
		setPhase("wait");
		const delay = 800 + Math.random() * 1600;
		goAt.current = Date.now() + delay;
		timer.current = window.setTimeout(() => {
			audio.go();
			setPhase("go");
			goAt.current = Date.now();
		}, delay);
	}
	function tap() {
		if (phase === "wait") {
			window.clearTimeout(timer.current);
			audio.fail();
			setPhase("early");
			return;
		}
		if (phase === "go") {
			const t = Date.now() - goAt.current;
			setMs(t);
			setPhase("done");
			audio.success();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-rise text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-10 flex size-56 items-center justify-center rounded-full bg-surface shadow-[var(--shadow-card)]",
				children: [
					phase === "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium text-muted",
						children: "Ready"
					}),
					phase === "wait" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium tracking-[0.2em] text-subtle",
						children: "WAIT"
					}),
					phase === "go" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-5xl font-semibold tracking-tight text-accent",
						style: { animation: "pulse-ring 0.9s ease-out" },
						children: "GO"
					}),
					phase === "early" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium text-danger",
						children: "Too soon"
					}),
					phase === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-3xl font-semibold tabular text-success",
						children: [ms, " ms"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: ms < 250 ? "Perfect" : ms < 400 ? "Great" : ms < 600 ? "Good" : "Cleared"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [
					phase === "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: arm,
						children: "Arm signal"
					}),
					(phase === "wait" || phase === "go") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "h-16 w-full text-lg",
						onClick: tap,
						variant: phase === "go" ? "primary" : "secondary",
						children: "Action"
					}),
					phase === "early" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: arm,
						children: "Try again"
					}),
					phase === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: onPass,
						children: "Continue"
					})
				]
			})
		]
	});
}
function ChoiceStep({ step, onPass }) {
	const [picked, setPicked] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
				children: step.concept
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-xl font-semibold leading-snug",
				children: step.question
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-col gap-2",
				children: step.options.map((opt) => {
					const shown = picked !== null;
					const isThis = picked?.id === opt.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: shown,
						onClick: () => {
							setPicked(opt);
							if (opt.correct) audio.success();
							else audio.fail();
						},
						className: cn("min-h-12 rounded-lg px-4 py-3 text-left font-mono text-sm shadow-[var(--shadow-card)] transition-transform active:scale-[0.98]", !shown && "bg-surface text-fg hover:shadow-[var(--shadow-card-hover)]", shown && opt.correct && "bg-success/15 text-success", shown && isThis && !opt.correct && "animate-shake bg-danger/15 text-danger", shown && !opt.correct && !isThis && "bg-surface text-subtle"),
						children: opt.label
					}, opt.id);
				})
			}),
			picked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-xl bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: picked.correct ? "Correct" : "Try again"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-muted",
						children: picked.explain
					}),
					!picked.correct && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: ["The right idea: ", step.options.find((o) => o.correct)?.explain]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4 w-full",
						onClick: () => {
							if (picked.correct) onPass();
							else setPicked(null);
						},
						children: picked.correct ? "Continue" : "Choose again"
					})
				]
			})
		]
	});
}
function MissionTimer({ seconds, running, onExpire, freeze }) {
	const [left, setLeft] = (0, import_react.useState)(seconds);
	const origin = (0, import_react.useRef)(null);
	const expired = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!running || freeze) return;
		if (origin.current === null) origin.current = Date.now();
		let raf = 0;
		const tick = () => {
			const elapsed = (Date.now() - origin.current) / 1e3;
			const remain = Math.max(0, seconds - elapsed);
			setLeft(remain);
			if (remain <= 0 && !expired.current) {
				expired.current = true;
				onExpire();
				return;
			}
			raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [
		running,
		freeze,
		seconds,
		onExpire
	]);
	(0, import_react.useEffect)(() => {
		origin.current = Date.now();
		expired.current = false;
		setLeft(seconds);
	}, [seconds]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-1.5 rounded-full bg-surface px-3 py-1.5 font-mono text-sm tabular", left <= 10 && "text-danger"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-4" }), Math.ceil(left)]
	});
}
function FailCard({ championship, onRetry, onQuit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "animate-rise rounded-xl bg-surface p-6 text-center shadow-[var(--shadow-card)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-danger",
				children: "Time"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-2xl font-semibold",
				children: championship ? "Championship timed out" : "Mission failed"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "The clock hit zero. Progress in this attempt is not saved. Retry the timed tasks."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					onClick: onRetry,
					children: "Retry"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onQuit,
					children: "Return home"
				})]
			})
		]
	});
}
function LevelIntro({ levelId }) {
	const level = levelById(levelId);
	const beginMission = useGame((s) => s.beginMission);
	const abortMission = useGame((s) => s.abortMission);
	const completed = useGame((s) => s.completedLevels);
	if (!level) return null;
	const practice = completed.includes(level.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "flex items-center gap-3 px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": "Back",
				onClick: abortMission,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-xl flex-1 px-5 pb-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
					children: ["Level ", String(level.id).padStart(2, "0")]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl font-semibold tracking-tight",
					children: level.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: level.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-8 space-y-3 rounded-xl bg-surface p-5 shadow-[var(--shadow-card)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Difficulty",
							v: level.difficulty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Objective",
							v: level.objective
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Reward",
							v: `+${level.rewardCoins.toLocaleString()} coins  ·  +${level.rewardXp} XP`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Unlock",
							v: level.unlockReward
						}),
						practice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Status",
							v: "Practice — rewards already claimed"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "mt-8 w-full",
					onClick: () => beginMission(level.id),
					children: "Start mission"
				})
			]
		})]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs uppercase tracking-[0.12em] text-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "max-w-[60%] text-right text-sm font-medium",
			children: v
		})]
	});
}
function AppHeader() {
	const playerName = useGame((s) => s.playerName);
	const xp = useGame((s) => s.xp);
	const coins = useGame((s) => s.coins);
	const muted = useGame((s) => s.muted);
	const toggleMute = useGame((s) => s.toggleMute);
	const prog = xpProgress(xp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-20 border-b border-border bg-bg/95 px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))] backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-xl items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-[11px] font-medium uppercase tracking-[0.16em] text-subtle",
						children: playerName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-lg font-semibold tabular leading-tight",
						children: ["LV ", String(prog.level).padStart(2, "0")]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md bg-surface px-3 py-1.5 text-right shadow-[var(--shadow-card)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] uppercase tracking-[0.14em] text-subtle",
						children: "Coins"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm tabular text-accent",
						children: coins.toLocaleString()
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: toggleMute,
					"aria-label": muted ? "Unmute" : "Mute",
					className: "flex size-11 items-center justify-center rounded-md text-muted hover:text-fg",
					children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
				})
			]
		})
	});
}
function XpBar({ compact }) {
	const prog = xpProgress(useGame((s) => s.xp));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1.5 flex items-baseline justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
			children: "XP"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-mono text-xs tabular text-muted",
			children: [
				prog.current,
				" / ",
				prog.needed
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 overflow-hidden rounded-full bg-surface-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative h-full rounded-full bg-accent transition-[width] duration-500 ease-[var(--ease-out)]",
			style: { width: `${Math.max(4, prog.ratio * 100)}%` },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-0 overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute inset-y-0 w-8 bg-fg/25",
					style: { animation: "bar-shine 1.8s ease-in-out infinite" }
				})
			})
		})
	})] });
}
var TABS = [
	{
		id: "home",
		label: "Home",
		icon: House
	},
	{
		id: "career",
		label: "Career",
		icon: Briefcase
	},
	{
		id: "rewards",
		label: "Rewards",
		icon: Gift
	},
	{
		id: "profile",
		label: "Profile",
		icon: User
	}
];
function BottomNav() {
	const tab = useGame((s) => s.tab);
	const setTab = useGame((s) => s.setTab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "sticky bottom-0 z-20 border-t border-border bg-bg-elevated/95 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mx-auto grid max-w-xl grid-cols-4",
			children: TABS.map((t) => {
				const Icon = t.icon;
				const on = tab === t.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab(t.id),
					className: cn("flex h-14 w-full flex-col items-center justify-center gap-0.5 text-[11px] font-medium", on ? "text-accent" : "text-subtle hover:text-muted"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: on ? 2.4 : 2
					}), t.label]
				}) }, t.id);
			})
		})
	});
}
function ToastHost() {
	const toast = useGame((s) => s.toast);
	if (!toast) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 top-16 z-40 flex justify-center px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "animate-rise rounded-full bg-surface-2 px-4 py-2 text-sm text-fg shadow-[var(--shadow-card)]",
			children: toast
		})
	});
}
function Shell({ children }) {
	const title = careerById(useGame((s) => s.career)).title;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full max-w-xl flex-1 px-4 pb-6 pt-4",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "sr-only",
				children: ["Current career ", title]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToastHost, {})
		]
	});
}
function CarMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 120 48",
		className,
		"aria-hidden": "true",
		fill: "none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 32h84c2 0 6-2 8-6 1-3-1-6-4-7l-14-4-8-9H42L28 19H14c-4 0-8 3-8 7v4c0 1 1 2 3 2h9",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "34",
				cy: "34",
				r: "7",
				stroke: "currentColor",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "86",
				cy: "34",
				r: "7",
				stroke: "currentColor",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M44 20h28l6 8H36l8-8z",
				stroke: "currentColor",
				strokeWidth: "2"
			})
		]
	});
}
function HomeScreen() {
	const career = useGame((s) => s.career);
	const completed = useGame((s) => s.completedLevels);
	const tryPlay = useGame((s) => s.tryPlay);
	const openLevel = useGame((s) => s.openLevel);
	const cur = careerById(career);
	const nxt = nextCareer(career);
	const nextId = nextLevelId(completed);
	const nextLv = LEVELS.find((l) => l.id === nextId);
	const allDone = completed.length >= LEVELS.length;
	const reward = nextLv.unlockReward;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "animate-rise rounded-3xl bg-surface p-5 shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-subtle",
					children: "Current career"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-semibold tracking-tight",
					children: cur.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: nxt ? `Next job · ${nxt.title}` : "Peak rank reached"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(XpBar, {})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "lg",
			className: "mt-5 h-14 w-full text-lg",
			onClick: tryPlay,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5 translate-x-px" }), allDone ? "Replay last mission" : "Play"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => openLevel(nextLv.id),
			className: "mt-4 flex w-full items-center justify-between rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-card)] active:scale-[0.99]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
					children: allDone ? "Last reward" : "Next reward"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 font-semibold",
					children: reward
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: allDone ? "Championship cleared" : `${nextLv.title} · +${nextLv.rewardCoins.toLocaleString()} coins`
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5 text-subtle" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 flex flex-col gap-6",
			children: CHAPTERS.map((ch) => {
				const rows = LEVELS.filter((lv) => lv.chapter === ch.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
						children: ch.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs text-muted",
						children: ch.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: rows.map((lv) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionRow, {
							level: lv,
							locked: !isLevelUnlocked(lv.id, completed),
							done: completed.includes(lv.id),
							current: !completed.includes(lv.id) && isLevelUnlocked(lv.id, completed),
							onOpen: () => openLevel(lv.id)
						}, lv.id))
					})
				] }, ch.id);
			})
		})
	] });
}
function MissionRow({ level, locked, done, current, onOpen }) {
	const shakeLock = useGame((s) => s.shakeLock);
	const [shake, setShake] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (locked && shakeLock) {
			setShake(true);
			const t = window.setTimeout(() => setShake(false), 320);
			return () => window.clearTimeout(t);
		}
	}, [shakeLock, locked]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onOpen,
		className: cn("flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left shadow-[var(--shadow-card)] active:scale-[0.99]", current ? "bg-surface-2" : "bg-surface", locked && "opacity-70", shake && "animate-shake"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("flex size-10 items-center justify-center rounded-md font-mono text-sm", done && "bg-success/15 text-success", current && "bg-accent/15 text-accent", locked && "bg-bg-elevated text-subtle", !done && !current && !locked && "bg-bg-elevated text-muted"),
				children: locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }) : done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : String(level.id).padStart(2, "0")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate font-medium",
					children: level.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted",
					children: locked ? `Complete Level ${level.id - 1} to unlock` : `${level.difficulty} · ${level.job}`
				})]
			}),
			current && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] font-medium uppercase tracking-[0.12em] text-accent",
				children: "Next"
			})
		]
	}) });
}
function CareerScreen() {
	const career = useGame((s) => s.career);
	const openLevel = useGame((s) => s.openLevel);
	const cur = careerById(career);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight",
			children: "Career path"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Complete missions to get hired and promoted."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-6",
			children: CAREERS.map((c, i) => {
				const state = c.rank < cur.rank ? "done" : c.rank === cur.rank ? "now" : "lock";
				const linked = LEVELS.find((l) => l.careerUnlock === c.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative flex gap-4 pb-6 last:pb-0",
					children: [
						i < CAREERS.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute left-[15px] top-8 h-[calc(100%-12px)] w-px", state === "done" ? "bg-accent" : "bg-border") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("relative z-[1] mt-0.5 flex size-8 items-center justify-center rounded-full", state === "done" && "bg-accent text-accent-fg", state === "now" && "bg-accent/20 text-accent ring-2 ring-accent", state === "lock" && "bg-surface text-subtle"),
							children: state === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : state === "lock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: state === "lock" || c.id === "rookie",
							onClick: () => linked && openLevel(linked.id),
							className: "min-w-0 flex-1 rounded-xl bg-surface px-4 py-3 text-left shadow-[var(--shadow-card)] disabled:opacity-60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: c.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-sm text-muted",
									children: c.blurb
								}),
								state === "now" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[11px] font-medium uppercase tracking-[0.14em] text-accent",
									children: "Current"
								})
							]
						})
					]
				}, c.id);
			})
		})
	] });
}
function RewardsScreen() {
	const unlocked = useGame((s) => s.unlockedRewards);
	const openLevel = useGame((s) => s.openLevel);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight",
			children: "Rewards"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "Milestones unlock as you clear missions."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 flex flex-col gap-3",
			children: REWARDS.map((r) => {
				const on = unlocked.includes(r.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => openLevel(r.levelId),
					className: cn("flex w-full items-center gap-4 rounded-xl px-4 py-4 text-left shadow-[var(--shadow-card)]", r.featured ? "bg-surface-2" : "bg-surface", !on && "opacity-75"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("flex size-12 items-center justify-center rounded-md", on ? "bg-accent/15 text-accent" : "bg-bg-elevated text-subtle"),
						children: r.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarMark, { className: "size-7" }) : on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: r.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted",
								children: [
									"Level ",
									r.levelId,
									" · ",
									r.blurb
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-1 block text-[11px] font-medium uppercase tracking-[0.12em]", on ? "text-success" : "text-subtle"),
								children: on ? "Unlocked" : "Locked"
							})
						]
					})]
				}) }, r.id);
			})
		})
	] });
}
function ProfileScreen() {
	const name = useGame((s) => s.playerName);
	const setName = useGame((s) => s.setName);
	const career = useGame((s) => s.career);
	const xp = useGame((s) => s.xp);
	const coins = useGame((s) => s.coins);
	const completed = useGame((s) => s.completedLevels);
	const rewards = useGame((s) => s.unlockedRewards);
	const highest = useGame((s) => s.highestLevel);
	const resetProgress = useGame((s) => s.resetProgress);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(name);
	const prog = xpProgress(xp);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-semibold tracking-tight",
			children: "Profile"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-5 block text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
			children: ["Player", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: draft,
				maxLength: 24,
				onChange: (e) => setDraft(e.target.value),
				onBlur: () => setName(draft),
				className: "mt-1 h-12 w-full rounded-md bg-surface px-3 text-base text-fg shadow-[var(--shadow-card)] outline-none focus:shadow-[var(--shadow-card-hover)]"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "mt-6 divide-y divide-border rounded-xl bg-surface px-4 shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Career",
					v: careerById(career).title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Level",
					v: String(prog.level).padStart(2, "0")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "XP",
					v: `${prog.current} / ${prog.needed}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Coins",
					v: coins.toLocaleString()
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Completed",
					v: `${completed.length} / ${LEVELS.length}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Highest level",
					v: String(highest)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Rewards",
					v: `${rewards.length} / ${REWARDS.length}`
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 rounded-xl bg-surface p-4 shadow-[var(--shadow-card)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Reset test progress"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "This erases local prototype progress on this device."
				}),
				!confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					className: "mt-4 w-full",
					onClick: () => setConfirm(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset test progress"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Reset all progress?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							className: "flex-1",
							onClick: () => setConfirm(false),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							className: "flex-1",
							onClick: () => {
								setConfirm(false);
								resetProgress();
								audio.fail();
							},
							children: "Reset"
						})]
					})]
				})
			]
		})
	] });
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-sm text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-mono text-sm tabular",
			children: v
		})]
	});
}
function WelcomeScreen() {
	const startCareer = useGame((s) => s.startCareer);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh flex-col bg-bg px-6 pb-10 pt-[max(3rem,env(safe-area-inset-top))] text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-1 flex-col justify-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-accent",
					children: "Python career"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-4xl font-semibold tracking-tight",
					children: "Jarvis Career"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-[28ch] text-lg leading-relaxed text-muted",
					children: "Build your career. Complete missions. Earn rewards. Rise to Grandmaster."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-8 space-y-3 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 text-accent" }), "50 playable Python missions"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 text-accent" }), "Mistakes explained, with the fix"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 text-accent" }), "XP, coins, promotions, local save"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "mt-10 h-14 w-full text-lg",
					onClick: startCareer,
					children: "Start career"
				})
			]
		})
	});
}
function CompleteScreen() {
	const screen = useGame((s) => s.screen);
	const continueFrom = useGame((s) => s.continueFrom);
	const career = useGame((s) => s.career);
	if (screen.id !== "complete") return null;
	const level = LEVELS.find((l) => l.id === screen.levelId);
	if (!level) return null;
	const champ = level.championship;
	const finale = Boolean(level.finale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
			children: champ ? finale ? "Mastery complete" : "Championship complete" : "Level complete"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto mt-5 flex size-16 items-center justify-center rounded-full bg-success/15 text-success",
			children: champ ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-8" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-8" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-4 text-3xl font-semibold tracking-tight",
			children: level.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: ["Level ", String(level.id).padStart(2, "0")]
		}),
		screen.score !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 font-mono text-2xl tabular text-accent",
			children: [screen.score, " pts"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 rounded-xl bg-surface p-4 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
				children: "Rewards"
			}), screen.firstClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 font-mono text-lg tabular text-accent",
					children: [
						"+",
						screen.coins.toLocaleString(),
						" coins"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-lg tabular text-accent",
					children: [
						"+",
						screen.xp,
						" XP"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: ["Unlocked · ", level.unlockReward]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: ["Career · ", careerById(career).title]
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Practice run. Rewards were already claimed."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-8 w-full",
			onClick: continueFrom,
			children: "Continue"
		})
	] });
}
function LevelUpScreen() {
	const screen = useGame((s) => s.screen);
	const continueFrom = useGame((s) => s.continueFrom);
	if (screen.id !== "levelup") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
			children: "Level up"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
			className: "mt-4 text-4xl font-semibold tracking-tight",
			children: [
				"LV ",
				String(screen.from).padStart(2, "0"),
				" → LV ",
				String(screen.to).padStart(2, "0")
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-muted",
			children: "Your player level increased. XP carries into the next bar."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-10 w-full",
			onClick: continueFrom,
			children: "Continue"
		})
	] });
}
function HiredScreen() {
	const screen = useGame((s) => s.screen);
	const continueFrom = useGame((s) => s.continueFrom);
	if (screen.id !== "hired") return null;
	const c = careerById(screen.career);
	const hired = screen.career === "trainee";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
			children: hired ? "Congratulations" : "Promotion unlocked"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-4 text-3xl font-semibold tracking-tight",
			children: hired ? "You've been hired" : c.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-2xl font-medium text-accent",
			children: hired ? c.title : "New title confirmed"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-muted",
			children: hired ? "Your career has officially started." : c.blurb
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-10 w-full",
			onClick: continueFrom,
			children: "Continue"
		})
	] });
}
function ClaimScreen() {
	const screen = useGame((s) => s.screen);
	const claimFinal = useGame((s) => s.claimFinal);
	const levelId = screen.id === "claim" ? screen.levelId : 5;
	const level = LEVELS.find((l) => l.id === levelId);
	const reward = level ? rewardById(level.unlockRewardId) : void 0;
	const isCar = reward?.id === "m8-apex";
	const finale = Boolean(level?.finale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.16em] text-accent",
			children: finale ? "Python mastery complete" : "Elite championship complete"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 text-3xl font-semibold tracking-tight",
			children: "You did it"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-muted",
			children: ["Career · ", level ? careerById(level.careerUnlock).title : "Elite Professional"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-8 w-full max-w-xs rounded-xl bg-surface-2 p-6",
			children: [
				isCar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarMark, { className: "mx-auto h-16 w-full text-accent" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "mx-auto size-16 text-accent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg font-semibold",
					children: reward?.name ?? level?.unlockReward
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: reward?.blurb ?? "In-game bonus. Not a real-world prize."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-[11px] uppercase tracking-[0.14em] text-subtle",
			children: "Milestone reward"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-6 w-full",
			onClick: claimFinal,
			children: "Claim reward"
		})
	] });
}
function ClaimedScreen() {
	const continueFrom = useGame((s) => s.continueFrom);
	const pending = useGame((s) => s.pending);
	const level = pending ? LEVELS.find((l) => l.id === pending.levelId) : void 0;
	const reward = level ? rewardById(level.unlockRewardId) : rewardById("m8-apex");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex size-16 items-center justify-center rounded-full bg-success/15 text-success",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-8" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-4 text-3xl font-semibold tracking-tight",
			children: reward?.name ?? "Reward"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-success",
			children: "Unlocked"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-sm text-muted",
			children: ["Added to your in-game collection. ", reward?.id === "m8-apex" ? "A garage can show it in a later update — no driving sim in this prototype." : "Wear it on the Rewards tab. It is an in-game unlock, not a real-world prize."]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			className: "mt-10 w-full",
			onClick: continueFrom,
			children: "Continue"
		})
	] });
}
function Overlay({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center bg-bg px-6 py-10 text-center text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "animate-rise w-full max-w-md",
			children
		})
	});
}
function GameApp() {
	const screen = useGame((s) => s.screen);
	const setHydrated = useGame((s) => s.setHydrated);
	(0, import_react.useEffect)(() => {
		let alive = true;
		const finish = () => {
			if (alive) setHydrated();
		};
		try {
			Promise.resolve(useGame.persist.rehydrate()).then(finish, finish);
		} catch {
			finish();
		}
		const t = window.setTimeout(finish, 80);
		return () => {
			alive = false;
			window.clearTimeout(t);
		};
	}, [setHydrated]);
	(0, import_react.useEffect)(() => {
		const flush = () => {
			try {
				useGame.persist.rehydrate();
			} catch {}
		};
		const onHide = () => {
			if (document.visibilityState === "hidden") flush();
		};
		document.addEventListener("visibilitychange", onHide);
		window.addEventListener("pagehide", flush);
		return () => {
			document.removeEventListener("visibilitychange", onHide);
			window.removeEventListener("pagehide", flush);
		};
	}, []);
	if (screen.id === "boot" || screen.id === "welcome") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomeScreen, {});
	if (screen.id === "home") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {});
	if (screen.id === "career") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CareerScreen, {});
	if (screen.id === "rewards") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RewardsScreen, {});
	if (screen.id === "profile") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileScreen, {});
	if (screen.id === "intro") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelIntro, { levelId: screen.levelId });
	if (screen.id === "play") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissionView, { levelId: screen.levelId });
	if (screen.id === "complete") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompleteScreen, {});
	if (screen.id === "levelup") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelUpScreen, {});
	if (screen.id === "hired") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HiredScreen, {});
	if (screen.id === "claim") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimScreen, {});
	if (screen.id === "claimed") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaimedScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
